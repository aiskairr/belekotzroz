import { createServer } from 'node:http';
import { appendFile, mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { readFileSync } from 'node:fs';
import { createHmac, randomBytes, randomUUID, scryptSync, timingSafeEqual } from 'node:crypto';
import { extname, join, normalize, posix as posixPath } from 'node:path';
import { fileURLToPath } from 'node:url';
import { tmpdir } from 'node:os';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const __dirname = fileURLToPath(new URL('.', import.meta.url));
const publicDir = join(__dirname, 'public');
const dataDir = join(__dirname, 'data');
const auditLogPath = join(dataDir, 'audit-log.jsonl');
const attendanceStoresPath = join(dataDir, 'attendance-stores.json');
const attendanceRecordsPath = join(dataDir, 'attendance-records.json');
const attendanceEventsPath = join(dataDir, 'attendance-events.json');
const attendanceSchedulePath = join(dataDir, 'attendance-schedule.json');
const execFileAsync = promisify(execFile);

loadDotEnv();
loadDotEnv(join(__dirname, 'loyalty-lab/.env'));

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const MOYSKLAD_BASE_URL = 'https://api.moysklad.ru/api/remap/1.2';
const MOYSKLAD_TIMEOUT_MS = 15000;
const loyaltyAccrualPercent = Number(process.env.LOYALTY_ACCRUAL_PERCENT || process.env.LOYALTY_DEFAULT_PERCENT || 3);
const loyaltyMaxRedeemPercent = Number(process.env.LOYALTY_MAX_REDEEM_PERCENT || 30);

const paymentRateRules = {
  'M+': {
    3: 0.05,
    6: 0.10,
    12: 0.20
  },
  'O!': {
    3: 0.06,
    6: 0.12,
    12: 0.24
  },
  'Банк Азии': {
    3: 0.04,
    6: 0.09,
    12: 0.19
  },
  Zero: {
    3: 0,
    6: 0,
    12: 0
  },
  Наличными: {
    1: 0
  },
  Долг: {
    1: 0
  }
};

const contentTypes = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml'
};

const recentOrders = new Map();
let telegramReceiptChatId = process.env.TELEGRAM_RECEIPT_CHAT_ID || '';
const productStockCache = new Map();
const productCostCache = new Map();
const moySkladProductSearchCache = new Map();
const moySkladPriceTypesCache = new Map();
const moySkladPriceTypesInflight = new Map();
const reconciliationDebtorsCache = new Map();
let whatsappCustomersCache = { value: null, createdAt: 0 };
const payrollReportCache = new Map();
const salesReportCache = new Map();
const salesReportInflight = new Map();
let currenciesCache = { value: [], createdAt: 0 };
let currenciesInflight = null;
let reportCurrencyExpandSupported = true;
const staticAssetHashCache = new Map();
const reportCookieName = 'mysrs_report_session';
const crmCookieName = 'mysrs_crm_session_v2';
const moySkladBranchLabels = { ayu: 'Аю-Гранд', besh: 'Беш-Сары' };
const PRICE_FORMULA_TEMPLATE_START = '[ORDO_PRICE_TEMPLATE]';
const PRICE_FORMULA_TEMPLATE_END = '[/ORDO_PRICE_TEMPLATE]';
const PAYROLL_CONFIG_START = '[ORDO_PAYROLL]';
const PAYROLL_CONFIG_END = '[/ORDO_PAYROLL]';
const PRODUCT_SEARCH_LIMIT = Math.max(6, Math.min(30, Number(process.env.MOYSKLAD_PRODUCT_SEARCH_LIMIT || 12)));
const PRODUCT_SEARCH_CACHE_TTL_MS = 120_000;
const PRODUCT_PRICE_TYPES_CACHE_TTL_MS = 600_000;
const RECONCILIATION_CACHE_TTL_MS = 180_000;
const RECONCILIATION_DOCUMENT_LIMIT = Math.max(200, Math.min(5000, Number(process.env.RECONCILIATION_DOCUMENT_LIMIT || 2000)));
const WHATSAPP_CUSTOMERS_CACHE_TTL_MS = 300_000;
const WHATSAPP_CUSTOMERS_LIMIT = Math.max(200, Math.min(5000, Number(process.env.WHATSAPP_CUSTOMERS_LIMIT || 2000)));
const ATTENDANCE_DEFAULT_RADIUS_METERS = 10;
const ATTENDANCE_MIN_SCAN_INTERVAL_MS = 30_000;
const categorySaleBonusRules = [
  { name: 'Встраиваемые варочные панели', amount: 300, match: /встраиваем.*вароч|варочн.*панел/ },
  { name: 'Встраиваемые духовые шкафы', amount: 400, match: /встраиваем.*духов|духов.*шкаф/ },
  { name: 'Встраиваемые микроволновые печи', amount: 300, match: /встраиваем.*микровол/ },
  { name: 'Встраиваемые посудомоечные машины', amount: 500, match: /встраиваем.*посудомо/ },
  { name: 'Встраиваемые холодильники', amount: 500, match: /встраиваем.*холодиль/ },
  { name: 'Кухонные вытяжки', amount: 300, match: /кухонн.*вытяж|вытяжк/ },
  { name: 'Настольные плиты', amount: 200, match: /настольн.*плит/ },
  { name: 'Газовые и электрические плиты', amount: 400, match: /газов.*плит|электрическ.*плит/ },
  { name: 'Морозильники', amount: 500, match: /морозиль/ },
  { name: 'Посудомоечные машины', amount: 500, match: /посудомо/ },
  { name: 'Холодильники', amount: 500, match: /холодиль/ },
  { name: 'Аэрогрили', amount: 200, match: /аэрогрил/ },
  { name: 'Блендеры и чопперы', amount: 200, match: /блендер|чоппер/ },
  { name: 'Вафельницы', amount: 200, match: /вафельниц/ },
  { name: 'Духовые мини-печи', amount: 300, match: /мини.*печ|духов.*мини/ },
  { name: 'Кофемашины и кофемолки', amount: 200, match: /кофемаш|кофемол/ },
  { name: 'Микроволновые печи', amount: 300, match: /микровол/ },
  { name: 'Миксеры', amount: 200, match: /миксер/ },
  { name: 'Мультиварки', amount: 300, match: /мультиварк/ },
  { name: 'Мясорубки', amount: 300, match: /мясоруб/ },
  { name: 'Посуда', amount: 200, match: /посуда|кастрюл|сковород/ },
  { name: 'Соковыжималки', amount: 200, match: /соковыжим/ },
  { name: 'Хлебопечи', amount: 200, match: /хлебопеч/ },
  { name: 'Электрические чайники и термопоты', amount: 200, match: /чайник|термопот/ },
  { name: 'Гладильные доски', amount: 150, match: /гладильн.*доск/ },
  { name: 'Отпариватели', amount: 200, match: /отпарив/ },
  { name: 'Полуавтоматические стиральные машины', amount: 300, match: /полуавтомат.*стирал/ },
  { name: 'Пылесосы', amount: 300, match: /пылесос/ },
  { name: 'Стиральные машины', amount: 500, match: /стиральн.*маш/ },
  { name: 'Сушилки для белья', amount: 150, match: /сушилк.*бель/ },
  { name: 'Сушильные машины', amount: 500, match: /сушильн.*маш/ },
  { name: 'Утюги', amount: 200, match: /утюг/ },
  { name: 'Вентиляторы', amount: 200, match: /вентилятор/ },
  { name: 'Водонагреватели', amount: 300, match: /водонагрев/ },
  { name: 'Кондиционеры', amount: 500, match: /кондиционер/ },
  { name: 'Обогреватели', amount: 200, match: /обогрев/ },
  { name: 'Очистители воздуха', amount: 200, match: /очистител.*возду/ },
  { name: 'Увлажнители', amount: 200, match: /увлажнител/ },
  { name: 'Аудиотехника', amount: 300, match: /аудиотех|аудиосистем|колонк/ },
  { name: 'Кронштейны', amount: 50, match: /кронштейн/ },
  { name: 'Телевизоры', amount: 500, match: /телевизор/ },
  { name: 'Весы', amount: 200, match: /весы/ },
  { name: 'Массажеры', amount: 200, match: /массаж/ },
  { name: 'Плойки и утюжки для волос', amount: 200, match: /плойк|утюж.*волос/ },
  { name: 'Триммеры и машинки для волос', amount: 200, match: /триммер|машинк.*волос/ },
  { name: 'Фены', amount: 200, match: /фен/ },
  { name: 'Электрические зубные щетки', amount: 200, match: /зубн.*щет/ }
];

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url || '/', `http://${req.headers.host}`);

    if (req.method === 'GET' && url.pathname === '/api/status') {
      sendJson(res, 200, { ok: true, service: 'mysrs-backend' });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/crm/session') {
      const user = getCrmUser(req);
      if (user) await autoCloseAttendanceShifts();
      sendJson(res, 200, { user, attendance: user ? await getAttendanceGate(user) : null });
      return;
    }

    const gateUser = getCrmUser(req);
    if (url.pathname.startsWith('/api/') && gateUser && await shouldBlockByAttendanceGate(url.pathname, gateUser)) {
      throw httpError(428, 'Перед работой в системе нужно отсканировать QR на рабочей точке и отметить приход.', {
        attendanceRequired: true,
        attendanceUrl: '/attendance.html'
      });
    }

    if (req.method === 'GET' && url.pathname === '/api/crm/ui-settings') {
      const user = requireAnyAuthenticatedUser(req);
      sendJson(res, 200, { settings: await getCrmUiSettings(user) });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/crm/moysklad-monitor') {
      requireCrmRole(req, ['admin', 'owner']);
      sendJson(res, 200, { stats: getMoySkladMonitorStats() });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/bot/products') {
      requireBotApiKey(req);
      const search = (url.searchParams.get('search') || '').trim();
      const limit = Math.max(1, Math.min(10, Number(url.searchParams.get('limit')) || 5));
      if (search.length < 2) {
        sendJson(res, 200, { products: [] });
        return;
      }
      const products = await getMoySkladProducts(search, process.env.MOYSKLAD_STORE_HREF || '', {
        branchName: url.searchParams.get('branchName') || ''
      });
      sendJson(res, 200, { products: products.slice(0, limit) });
      return;
    }

    if (req.method === 'PUT' && url.pathname === '/api/crm/ui-settings') {
      const user = requireAnyAuthenticatedUser(req);
      const settings = await updateCrmUiSettings(user, await readJson(req));
      sendJson(res, 200, { settings });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/customs-calculator/history') {
      const user = requireAccountingAuth(req);
      sendJson(res, 200, { rows: await getCustomsCalculatorHistory(user) });
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/customs-calculator/history') {
      const user = requireAccountingAuth(req);
      const row = await saveCustomsCalculatorHistory(user, await readJson(req));
      sendJson(res, 201, { row });
      return;
    }

    if (req.method === 'DELETE' && url.pathname === '/api/customs-calculator/history') {
      const user = requireAccountingAuth(req);
      sendJson(res, 200, { deleted: await deleteCustomsCalculatorHistory(user) });
      return;
    }

    const customsHistoryMatch = url.pathname.match(/^\/api\/customs-calculator\/history\/([0-9a-f-]{36})$/i);
    if (customsHistoryMatch && req.method === 'GET') {
      const user = requireAccountingAuth(req);
      sendJson(res, 200, { row: await getCustomsCalculatorHistoryItem(customsHistoryMatch[1], user) });
      return;
    }
    if (customsHistoryMatch && req.method === 'DELETE') {
      const user = requireAccountingAuth(req);
      sendJson(res, 200, { deleted: await deleteCustomsCalculatorHistoryItem(customsHistoryMatch[1], user) });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/crm/login-users') {
      const users = await getCrmLoginUsers();
      sendJson(res, 200, { users });
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/crm/login') {
      const body = await readJson(req);
      const user = await authenticateCrmUser(body.login, body.password);
      if (!user) throw httpError(401, 'Неверный логин или пароль.');
      setCrmSession(res, user);
      await writeAudit({ user, action: 'login', entity: 'session', description: 'Вход в CRM' });
      sendJson(res, 200, { user, attendance: await getAttendanceGate(user) });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/crm/users') {
      requireCrmPermission(req, 'users');
      sendJson(res, 200, { users: await getManagedCrmUsers() });
      return;
    }

    const crmUserMatch = url.pathname.match(/^\/api\/crm\/users\/([0-9a-f-]{36})$/i);
    if (crmUserMatch && req.method === 'PUT') {
      const actor = requireCrmPermission(req, 'users');
      const user = await updateManagedCrmUser(crmUserMatch[1], await readJson(req), actor);
      await writeAudit({ actor, user: actor, action: 'crm.user.update', entity: 'crm_user', entityId: user.id, description: `Доступ сотрудника изменен: ${user.name}` });
      sendJson(res, 200, { user });
      return;
    }

    if (crmUserMatch && req.method === 'DELETE') {
      const actor = requireCrmPermission(req, 'users');
      const user = await deleteManagedCrmUser(crmUserMatch[1], actor);
      await writeAudit({ actor, user: actor, action: 'crm.user.delete', entity: 'crm_user', entityId: user.id, description: `Сотрудник удален из CRM: ${user.name}` });
      sendJson(res, 200, { user });
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/crm/logout') {
      const user = getCrmUser(req);
      clearCrmSession(res);
      if (user) await writeAudit({ user, action: 'logout', entity: 'session', description: 'Выход из CRM' });
      sendJson(res, 200, { ok: true });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/audit') {
      requireCrmPermission(req, 'audit');
      const rows = await readAuditLog(Math.min(500, Math.max(1, Number(url.searchParams.get('limit')) || 200)));
      sendJson(res, 200, { rows });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/expenses') {
      requireCrmPermission(req, 'expenses');
      const expenses = await getExpenses({
        dateFrom: url.searchParams.get('dateFrom') || '',
        dateTo: url.searchParams.get('dateTo') || '',
        category: url.searchParams.get('category') || ''
      });
      sendJson(res, 200, { expenses });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/reconciliation/debtors') {
      requireCrmPermission(req, 'reconciliation');
      const report = await getReconciliationDebtors({
        search: url.searchParams.get('search') || '',
        customerType: url.searchParams.get('customerType') || '',
        limit: url.searchParams.get('limit') || '',
        offset: url.searchParams.get('offset') || ''
      });
      sendJson(res, 200, report);
      return;
    }

    const reconciliationDebtorMatch = url.pathname.match(/^\/api\/reconciliation\/debtors\/([0-9a-f-]{36})$/i);
    if (reconciliationDebtorMatch && req.method === 'GET') {
      requireCrmPermission(req, 'reconciliation');
      const details = await getReconciliationDebtorDetails(reconciliationDebtorMatch[1]);
      sendJson(res, 200, details);
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/whatsapp/customers') {
      requireCrmPermission(req, 'whatsappBroadcast');
      const customers = await getWhatsappCustomers({
        search: url.searchParams.get('search') || '',
        customerType: url.searchParams.get('customerType') || '',
        limit: url.searchParams.get('limit') || ''
      });
      sendJson(res, 200, customers);
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/attendance/status') {
      const user = requireCrmPermission(req, 'attendance');
      await autoCloseAttendanceShifts();
      sendJson(res, 200, await getAttendanceStatus(user));
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/attendance/scan') {
      const user = requireCrmPermission(req, 'attendance');
      const result = await scanAttendanceQr(user, await readJson(req), req);
      await writeAudit({
        user,
        action: result.action === 'check_out' ? 'attendance.check_out' : 'attendance.check_in',
        entity: 'attendance_record',
        entityId: result.record?.id || '',
        description: `${result.action === 'check_out' ? 'Уход' : 'Приход'}: ${result.store?.name || ''}`,
        details: { distanceMeters: result.distanceMeters, storeId: result.store?.id || '' }
      });
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/attendance/open') {
      const user = requireCrmPermission(req, 'attendance');
      const result = await markAttendanceShift(user, await readJson(req), req, 'check_in');
      await writeAudit({
        user,
        action: 'attendance.check_in',
        entity: 'attendance_record',
        entityId: result.record?.id || '',
        description: `Приход: ${result.store?.name || ''}`,
        details: { distanceMeters: result.distanceMeters, storeId: result.store?.id || '' }
      });
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/attendance/close') {
      const user = requireCrmPermission(req, 'attendance');
      const result = await markAttendanceShift(user, await readJson(req), req, 'check_out');
      await writeAudit({
        user,
        action: 'attendance.check_out',
        entity: 'attendance_record',
        entityId: result.record?.id || '',
        description: `Уход: ${result.store?.name || ''}`,
        details: { distanceMeters: result.distanceMeters, storeId: result.store?.id || '' }
      });
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/attendance/reports') {
      const user = requireCrmPermission(req, 'attendance');
      await autoCloseAttendanceShifts();
      const report = await getAttendanceReport({
        dateFrom: url.searchParams.get('date_from') || url.searchParams.get('dateFrom') || '',
        dateTo: url.searchParams.get('date_to') || url.searchParams.get('dateTo') || '',
        userId: url.searchParams.get('user_id') || url.searchParams.get('userId') || '',
        storeId: url.searchParams.get('store_id') || url.searchParams.get('storeId') || ''
      }, user);
      sendJson(res, 200, report);
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/attendance/stores') {
      requireCrmPermission(req, 'attendance');
      sendJson(res, 200, { stores: await getAttendanceStores() });
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/attendance/stores') {
      const user = requireCrmRole(req, ['admin', 'owner']);
      const store = await createAttendanceStore(await readJson(req), user);
      await writeAudit({ user, action: 'attendance.store.create', entity: 'attendance_store', entityId: store.id, description: `Рабочая точка создана: ${store.name}` });
      sendJson(res, 201, { store });
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/attendance/admin-open') {
      const user = requireCrmRole(req, ['admin', 'owner']);
      const record = await adminOpenAttendanceShift(await readJson(req), user);
      await writeAudit({ user, action: 'attendance.admin_open', entity: 'attendance_record', entityId: record.id, description: `Смена открыта администратором: ${record.userName}` });
      sendJson(res, 201, { record });
      return;
    }

    if (req.method === 'PUT' && url.pathname === '/api/attendance/schedule') {
      const user = requireCrmRole(req, ['admin', 'owner']);
      const schedule = await saveAttendanceSchedule(await readJson(req));
      await writeAudit({ user, action: 'attendance.schedule.update', entity: 'attendance_schedule', entityId: 'default', description: 'График посещаемости изменен', details: schedule });
      sendJson(res, 200, { schedule });
      return;
    }

    const attendanceStoreMatch = url.pathname.match(/^\/api\/attendance\/stores\/([0-9a-f-]{36})$/i);
    if (attendanceStoreMatch && req.method === 'PUT') {
      const user = requireCrmRole(req, ['admin', 'owner']);
      const store = await updateAttendanceStore(attendanceStoreMatch[1], await readJson(req), user);
      await writeAudit({ user, action: 'attendance.store.update', entity: 'attendance_store', entityId: store.id, description: `Рабочая точка изменена: ${store.name}` });
      sendJson(res, 200, { store });
      return;
    }

    if (attendanceStoreMatch && req.method === 'DELETE') {
      const user = requireCrmRole(req, ['admin', 'owner']);
      const store = await deleteAttendanceStore(attendanceStoreMatch[1]);
      await writeAudit({ user, action: 'attendance.store.delete', entity: 'attendance_store', entityId: store.id, description: `Рабочая точка удалена: ${store.name}` });
      sendJson(res, 200, { ok: true, store });
      return;
    }

    const attendanceQrMatch = url.pathname.match(/^\/api\/attendance\/stores\/([0-9a-f-]{36})\/generate-qr$/i);
    if (attendanceQrMatch && req.method === 'POST') {
      const user = requireCrmRole(req, ['admin', 'owner']);
      const store = await generateAttendanceStoreQr(attendanceQrMatch[1], await readJson(req), user);
      await writeAudit({ user, action: 'attendance.store.qr', entity: 'attendance_store', entityId: store.id, description: `QR обновлен: ${store.name}` });
      sendJson(res, 200, { store });
      return;
    }

    const attendanceDeleteQrMatch = url.pathname.match(/^\/api\/attendance\/stores\/([0-9a-f-]{36})\/qr$/i);
    if (attendanceDeleteQrMatch && req.method === 'DELETE') {
      const user = requireCrmRole(req, ['admin', 'owner']);
      const store = await disableAttendanceStoreQr(attendanceDeleteQrMatch[1]);
      await writeAudit({ user, action: 'attendance.store.qr.disable', entity: 'attendance_store', entityId: store.id, description: `QR отключен: ${store.name}` });
      sendJson(res, 200, { store });
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/expenses') {
      const user = requireCrmPermission(req, 'expenses');
      const expense = await createExpense(await readJson(req), user);
      await writeAudit({ user, action: 'expense.create', entity: 'expense', entityId: expense.id, description: `Расход: ${expense.description || expense.subcategory} на ${formatMoney(expense.amount)} сом` });
      sendJson(res, 201, { expense });
      return;
    }

    const expenseMatch = url.pathname.match(/^\/api\/expenses\/([0-9a-f-]{36})$/i);
    if (expenseMatch && req.method === 'PUT') {
      const user = requireCrmPermission(req, 'expenses');
      const expense = await updateExpense(expenseMatch[1], await readJson(req), user);
      await writeAudit({ user, action: 'expense.update', entity: 'expense', entityId: expense.id, description: `Расход изменен: ${formatMoney(expense.amount)} сом` });
      sendJson(res, 200, { expense });
      return;
    }

    if (expenseMatch && req.method === 'DELETE') {
      const user = requireCrmPermission(req, 'expenses');
      await deleteExpense(expenseMatch[1]);
      await writeAudit({ user, action: 'expense.delete', entity: 'expense', entityId: expenseMatch[1], description: 'Расход удален' });
      sendJson(res, 200, { ok: true });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/deliveries') {
      const user = requireCrmPermission(req, 'deliveries');
      const deliveries = await getDeliveries({
        dateFrom: url.searchParams.get('dateFrom') || '',
        dateTo: url.searchParams.get('dateTo') || '',
        status: url.searchParams.get('status') || ''
      }, user);
      sendJson(res, 200, { deliveries });
      return;
    }

    const deliveryMatch = url.pathname.match(/^\/api\/deliveries\/([0-9a-f-]{36})$/i);
    if (deliveryMatch && req.method === 'PATCH') {
      const user = requireCrmPermission(req, 'deliveries');
      const delivery = await updateDelivery(deliveryMatch[1], await readJson(req), user);
      await writeAudit({ user, action: 'delivery.update', entity: 'delivery', entityId: delivery.id, description: `Статус доставки ${delivery.document_name}: ${delivery.status}` });
      sendJson(res, 200, { delivery });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/config') {
      requireCrmPermission(req, 'sales');
      sendJson(res, 200, {
        documentType: process.env.MOYSKLAD_DOCUMENT_TYPE || 'auto',
        loyalty: getLoyaltyConfig()
      });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/payment-types') {
      requireCrmPermission(req, 'sales');
      const paymentTypes = await getMoySkladPaymentTypes();
      sendJson(res, 200, { paymentTypes });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/employees') {
      requireCrmPermission(req, 'sales');
      const employees = await getMoySkladEmployees();
      sendJson(res, 200, { employees });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/payroll') {
      requireCrmPermission(req, 'payroll');
      const payroll = await getPayrollReport({
        dateFrom: url.searchParams.get('dateFrom') || '',
        dateTo: url.searchParams.get('dateTo') || ''
      });
      sendJson(res, 200, payroll);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/payroll/employees/config') {
      const user = requireCrmPermission(req, 'payroll');
      const body = await readJson(req);
      const entries = Array.isArray(body.employees) ? body.employees : [body];
      if (!entries.length || entries.length > 100) throw httpError(400, 'Можно сохранить от 1 до 100 сотрудников.');
      const employees = await mapWithConcurrency(entries, 3, updateMoySkladEmployeePayrollConfig);
      payrollReportCache.clear();
      await writeAudit({
        user,
        action: 'payroll.employees.config',
        entity: 'employee',
        description: `Настройки зарплаты сохранены: ${employees.length} сотрудников`,
        details: { employees: employees.map((employee) => employee.name) }
      });
      sendJson(res, 200, { employees });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/stores') {
      requireCrmPermission(req, 'sales');
      const stores = await getMoySkladStores();
      sendJson(res, 200, { stores });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/retail-stores') {
      requireAnyCrmPermission(req, ['sales', 'commercialDocuments']);
      const retailStores = await getMoySkladRetailStores({ branchName: url.searchParams.get('branchName') || '' });
      sendJson(res, 200, { retailStores });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/retail-shifts') {
      requireCrmPermission(req, 'sales');
      const retailStoreHref = url.searchParams.get('retailStoreHref') || '';
      if (!retailStoreHref) {
        throw httpError(400, 'Укажите retailStoreHref.');
      }
      const retailShifts = await getMoySkladRetailShifts(retailStoreHref, { branchName: url.searchParams.get('branchName') || '' });
      sendJson(res, 200, { retailShifts });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/retail-fiscal-status') {
      requireCrmPermission(req, 'sales');
      const documentId = url.searchParams.get('documentId') || '';
      if (!documentId) {
        throw httpError(400, 'Укажите documentId.');
      }
      const status = await getRetailFiscalStatus(documentId, { branchName: url.searchParams.get('branchName') || '' });
      sendJson(res, 200, status);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/retail-fiscalize') {
      const user = requireCrmPermission(req, 'sales');
      const body = await readJson(req);
      const documentId = String(body.documentId || body.id || url.searchParams.get('documentId') || '').trim();
      if (!documentId) {
        throw httpError(400, 'Укажите documentId.');
      }
      let result;
      try {
        const document = await getRetailDemandById(documentId, body);
        result = await triggerRetailFiscalizationSafely(document, body);
      } catch (error) {
        result = {
          attempted: true,
          success: false,
          error: error.message || 'Не удалось подготовить документ к фискализации.'
        };
      }
      await writeAudit({
        user,
        action: result.success ? 'fiscal.manual.success' : 'fiscal.manual.error',
        entity: 'retaildemand',
        entityId: documentId,
        description: result.success
          ? `Ручная отправка на фискализацию: успешно, документ ${documentId}`
          : `Ручная отправка на фискализацию: ошибка, документ ${documentId}`,
        details: {
          documentId,
          success: Boolean(result.success),
          mode: result.mode || process.env.MOYSKLAD_FISCALIZE_MODE || '',
          error: result.error || '',
          reason: result.reason || '',
          serviceUrl: result.serviceUrl || result.endpoint || '',
          responseText: String(result.responseText || '').slice(0, 1000)
        }
      });
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/products') {
      requireAnyCrmPermission(req, ['sales', 'commercialDocuments']);
      const search = (url.searchParams.get('search') || '').trim();
      const storeHref = url.searchParams.get('storeHref') || '';
      if (search.length < 2) {
        sendJson(res, 200, { products: [] });
        return;
      }
      const products = await getMoySkladProducts(search, storeHref, { branchName: url.searchParams.get('branchName') || '' });
      sendJson(res, 200, { products });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/customers') {
      requireAnyCrmPermission(req, ['sales', 'commercialDocuments']);
      const search = url.searchParams.get('search') || '';
      const customers = await getMoySkladCustomers(search, { branchName: url.searchParams.get('branchName') || '' });
      sendJson(res, 200, { customers });
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/commercial-documents/word') {
      const user = requireCrmPermission(req, 'commercialDocuments');
      const body = await readJson(req);
      const file = await createCommercialWordInvoice(body);
      await writeAudit({
        user,
        action: 'commercial.word',
        entity: 'invoice',
        description: `Счет на оплату Word: ${body.customerName || 'Контрагент'}`
      });
      res.writeHead(200, {
        'Content-Type': 'application/msword; charset=utf-8',
        'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(file.name)}`,
        'Cache-Control': 'no-store'
      });
      res.end(file.content);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/commercial-documents/pdf') {
      const user = requireCrmPermission(req, 'commercialDocuments');
      let body = await readJson(req);
      const document = body.documentType === 'demand'
        ? await (async () => {
            const token = getMoySkladTokenFor(body);
            const agentHref = await getOrCreateCounterparty(token, body);
            body = { ...body, agentHref, customerHref: body.customerHref || agentHref, customerMode: 'existing' };
            return createCommercialDemandDocument(body);
          })()
        : null;
      const file = await createCommercialPdfInvoice(body);
      await writeAudit({
        user,
        action: 'commercial.pdf',
        entity: 'invoice',
        description: document
          ? `PDF + отгрузка: ${document.name || ''} / ${body.customerName || 'Контрагент'}`
          : `Счет на оплату PDF: ${body.customerName || 'Контрагент'}`
      });
      res.writeHead(200, {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(file.name)}`,
        'Cache-Control': 'no-store',
        ...(document ? {
          'X-Commercial-Document-Type': document.type || '',
          'X-Commercial-Document-Name': encodeURIComponent(document.name || ''),
          'X-Commercial-Document-Id': document.id || '',
          'X-Commercial-Document-Web-Url': encodeURIComponent(getMoySkladWebUrl(document.type, document.id) || '')
        } : {})
      });
      res.end(file.content);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/commercial-documents') {
      const user = requireCrmPermission(req, 'commercialDocuments');
      const body = await readJson(req);
      if (body.documentType === 'demand') {
        throw httpError(400, 'Создание отгрузки на этой странице временно отключено.');
      }
      const document = body.documentType === 'demand'
        ? await createCommercialDemandDocument(body)
        : await createCommercialMoySkladDocument(body);
      salesReportCache.clear();
      payrollReportCache.clear();
      await writeAudit({
        user,
        action: 'commercial.create',
        entity: document.type || 'document',
        entityId: document.id || '',
        description: `${document.type === 'customerorder' ? 'Счет' : 'Отгрузка'} ${document.name || ''}`
      });
      sendJson(res, 201, { document });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/loyalty/customer') {
      requireCrmPermission(req, 'sales');
      const phone = url.searchParams.get('phone') || '';
      const customer = await getLoyaltyCustomer(phone);
      sendJson(res, 200, { customer, loyalty: getLoyaltyConfig() });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/report/session') {
      const user = getCrmUser(req);
      sendJson(res, 200, { authenticated: isReportAuthenticated(req), user });
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/report/login') {
      const body = await readJson(req);
      await loginReportUser(req, res, body);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/report/logout') {
      clearReportSession(res);
      sendJson(res, 200, { ok: true });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/reports/sales') {
      const user = requireReportAuth(req);
      const report = await getSalesReport({
        dateFrom: url.searchParams.get('dateFrom') || '',
        dateTo: url.searchParams.get('dateTo') || '',
        documentType: url.searchParams.get('documentType') || '',
        customerType: url.searchParams.get('customerType') || '',
        search: url.searchParams.get('search') || '',
        retailStoreHref: url.searchParams.get('retailStoreHref') || '',
        storeHref: url.searchParams.get('storeHref') || ''
      });
      sendJson(res, 200, sanitizeSalesReportForUser(report, user));
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/reports/bank-commissions') {
      requireReportAuth(req);
      const analytics = await getBankCommissionAnalytics({
        dateFrom: url.searchParams.get('dateFrom') || '',
        dateTo: url.searchParams.get('dateTo') || '',
        retailStoreHref: url.searchParams.get('retailStoreHref') || '',
        storeHref: url.searchParams.get('storeHref') || '',
        bank: url.searchParams.get('bank') || '',
        paymentType: url.searchParams.get('paymentType') || ''
      });
      sendJson(res, 200, analytics);
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/reports/bank-commissions/export.xls') {
      requireReportAuth(req);
      const analytics = await getBankCommissionAnalytics({
        dateFrom: url.searchParams.get('dateFrom') || '',
        dateTo: url.searchParams.get('dateTo') || '',
        retailStoreHref: url.searchParams.get('retailStoreHref') || '',
        storeHref: url.searchParams.get('storeHref') || '',
        bank: url.searchParams.get('bank') || '',
        paymentType: url.searchParams.get('paymentType') || ''
      });
      const content = buildBankCommissionExcelBuffer(analytics);
      res.writeHead(200, {
        'Content-Type': 'application/vnd.ms-excel; charset=utf-8',
        'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent('bank-commissions.xls')}`,
        'Cache-Control': 'no-store'
      });
      res.end(content);
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/reports/bank-commissions/export.pdf') {
      requireReportAuth(req);
      const analytics = await getBankCommissionAnalytics({
        dateFrom: url.searchParams.get('dateFrom') || '',
        dateTo: url.searchParams.get('dateTo') || '',
        retailStoreHref: url.searchParams.get('retailStoreHref') || '',
        storeHref: url.searchParams.get('storeHref') || '',
        bank: url.searchParams.get('bank') || '',
        paymentType: url.searchParams.get('paymentType') || ''
      });
      const content = await renderHtmlToPdf(buildBankCommissionExportHtml(analytics));
      res.writeHead(200, {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent('bank-commissions.pdf')}`,
        'Cache-Control': 'no-store'
      });
      res.end(content);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/reports/returns') {
      requireReportAuth(req);
      const user = getEffectiveUser(req, 'owner');
      const body = await readJson(req);
      const result = await createReportReturn(body);
      salesReportCache.clear();
      payrollReportCache.clear();
      await writeAudit({ user, action: 'return', entity: body.documentType || 'document', entityId: body.documentId, description: `Возврат товара, количество: ${body.quantity || 1}` });
      sendJson(res, 201, result);
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/accounting/prices') {
      requireAccountingAuth(req);
      const catalog = await getAccountingPriceCatalog({
        offset: url.searchParams.get('offset'),
        limit: url.searchParams.get('limit'),
        includePriceTypes: url.searchParams.get('includePriceTypes') !== 'false'
      });
      sendJson(res, 200, catalog);
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/accounting/supply-products') {
      requireAccountingAuth(req);
      const result = await getAccountingSupplyProducts(url.searchParams.get('query') || '');
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/accounting/price-formula/folder-template') {
      const user = requireAccountingAuth(req);
      const body = await readJson(req);
      const result = await updateAccountingFolderPriceTemplate(body);
      await writeAudit({
        user,
        action: 'prices.template.folder',
        entity: 'productfolder',
        entityId: result.id,
        description: result.template ? `Шаблон цен сохранен для группы «${result.name}»` : `Шаблон цен удален у группы «${result.name}»`
      });
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/accounting/prices/update') {
      requireAccountingAuth(req);
      const user = getEffectiveUser(req, 'accountant');
      const body = await readJson(req);
      const result = await updateAccountingPrices(body);
      await writeAudit({ user, action: 'prices.update', entity: 'product', description: `Массовое изменение цен: успешно ${result.updated}, ошибок ${result.failed}`, details: { updated: result.updated, failed: result.failed } });
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/accounting/prices/formula-update') {
      requireAccountingAuth(req);
      const user = getEffectiveUser(req, 'accountant');
      const body = await readJson(req);
      const result = await updateAccountingFormulaPrices(body);
      await writeAudit({ user, action: 'prices.formula.update', entity: 'product', description: `Расчет цен: успешно ${result.updated}, ошибок ${result.failed}`, details: { updated: result.updated, failed: result.failed } });
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/calculate') {
      requireCrmPermission(req, 'sales');
      const body = await readJson(req);
      sendJson(res, 200, calculate(await hydrateOrderItemCosts(body)));
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/orders') {
      const body = await readJson(req);
      const user = requireCrmPermission(req, body.paymentScenario === 'debt' ? 'debtSale' : 'sales');
      assertCrmBranchAccess(user, body.branchName);
      const requestKey = String(body.requestKey || '');
      if (requestKey && recentOrders.has(requestKey)) {
        sendJson(res, 200, recentOrders.get(requestKey));
        return;
      }

      if (body.receiptPhoto) {
        validateTelegramReceiptInput(body.receiptPhoto);
      }
      const result = calculate(await hydrateOrderItemCosts(body));
      await assertLoyaltyRedemptionAllowed(result, body);
      const document = await createMoySkladDocument(result, body);
      let delivery = null;
      let deliveryError = '';
      if (body.delivery?.enabled) {
        try {
          delivery = await createDeliveryRecord(body, document, user);
        } catch (error) {
          deliveryError = error.message || 'Не удалось сохранить доставку.';
        }
      }
      payrollReportCache.clear();
      salesReportCache.clear();
      const fiscalization = document.type === 'retaildemand'
        ? await triggerRetailFiscalizationSafely(document, body)
        : { attempted: false, skipped: true };
      const loyalty = await applyLoyaltySafely(result, body, document);
      const telegramReceipt = body.receiptPhoto
        ? await sendTelegramReceiptSafely(body.receiptPhoto, result, body, document)
        : { sent: false, skipped: true };
      const payload = { calculation: result, document, loyalty, delivery, deliveryError, telegramReceipt, fiscalization };
      if (document.type === 'retaildemand') {
        await writeAudit({
          user,
          action: fiscalization?.success ? 'fiscal.auto.success' : 'fiscal.auto.error',
          entity: 'retaildemand',
          entityId: document.id || '',
          description: fiscalization?.success
            ? `Автофискализация отправлена: ${document.name || document.id || ''}`
            : `Автофискализация не выполнена: ${document.name || document.id || ''}`,
          details: {
            documentId: document.id || '',
            documentName: document.name || '',
            success: Boolean(fiscalization?.success),
            attempted: Boolean(fiscalization?.attempted),
            skipped: Boolean(fiscalization?.skipped),
            mode: fiscalization?.mode || process.env.MOYSKLAD_FISCALIZE_MODE || '',
            error: fiscalization?.error || '',
            reason: fiscalization?.reason || '',
            serviceUrl: fiscalization?.serviceUrl || fiscalization?.endpoint || '',
            responseText: String(fiscalization?.responseText || '').slice(0, 1000)
          }
        });
      }
      await writeAudit({
        user,
        action: 'sale.create',
        entity: document.type || 'document',
        entityId: document.id || '',
        description: `${document.type === 'retaildemand' ? 'Продажа' : 'Отгрузка'} ${document.name || ''} на ${formatMoney(result.finalTotal)} сом`,
        details: { documentName: document.name, amount: result.finalTotal, branch: body.branchName || '', customer: body.customerName || '' }
      });
      if (requestKey) {
        recentOrders.set(requestKey, payload);
        setTimeout(() => recentOrders.delete(requestKey), 10 * 60 * 1000);
      }
      sendJson(res, 201, payload);
      return;
    }

    if (req.method === 'GET') {
      await serveStatic(url, res);
      return;
    }

    sendJson(res, 405, { error: 'Method not allowed' });
  } catch (error) {
    const status = Number(error.status || 500);
    sendJson(res, status, {
      error: error.message || 'Internal server error',
      details: error.details
    });
  }
});

server.listen(PORT, HOST, () => {
  console.log(`App is running at http://localhost:${PORT}`);
});

function calculate(input) {
  const items = getOrderItems(input);
  const cashPrepayment = toMoney(input.cashPrepayment || 0);
  const prepaymentMethodName = String(input.prepaymentMethodName || 'Наличными');
  const transferPrepayment = toMoney(input.transferPrepayment || 0);
  const loyaltyRedemption = getValidatedLoyaltyRedemption(input);
  const paymentTypeName = String(input.paymentTypeName || input.bank || 'M+ (6 мес)');
  const paymentType = parsePaymentType(paymentTypeName);
  const months = paymentType.months;
  const secondPaymentTypeName = String(input.secondPaymentTypeName || '').trim();
  const secondPaymentType = secondPaymentTypeName ? parsePaymentType(secondPaymentTypeName) : { provider: '', months: 0 };
  const secondBankAmount = toMoney(input.secondBankAmount || 0);

  if (!items.length) {
    throw httpError(400, 'Добавьте хотя бы один товар.');
  }
  if (!items.some((item) => !item.isGift && item.lineTotal > 0)) {
    throw httpError(400, 'В продаже должен быть хотя бы один оплачиваемый товар. Подарок добавляется вместе с покупкой.');
  }
  if (!Number.isFinite(cashPrepayment) || cashPrepayment < 0) {
    throw httpError(400, 'Наличная предоплата не может быть отрицательной.');
  }
  if (!Number.isFinite(transferPrepayment) || transferPrepayment < 0) {
    throw httpError(400, 'Предоплата переводом не может быть отрицательной.');
  }
  if (!Number.isFinite(secondBankAmount) || secondBankAmount < 0) {
    throw httpError(400, 'Сумма через второй банк не может быть отрицательной.');
  }
  if (secondBankAmount > 0 && !secondPaymentTypeName) {
    throw httpError(400, 'Выберите второй банк.');
  }
  if (secondBankAmount > 0 && secondPaymentTypeName === paymentTypeName) {
    throw httpError(400, 'Для смешанной оплаты выберите два разных банка.');
  }
  if (loyaltyRedemption > 0 && !getLoyaltyConfig().enabled) {
    throw httpError(400, 'Бонусная система сейчас выключена.');
  }
  if (loyaltyRedemption > 0 && input.customerMode === 'retail') {
    throw httpError(400, 'Для розничного покупателя нельзя списывать бонусы. Выберите старого или нового клиента.');
  }

  const rateFromInput = Number(input.paymentTypeRate);
  const rateFromPaymentComment = parseRateFromComment(input.paymentTypeComment);
  const explicitRate = Number.isFinite(rateFromInput) && rateFromInput > 0
    ? rateFromInput
    : rateFromPaymentComment;
  const rate = getPaymentRate(paymentType.provider, months, explicitRate);
  const secondRateFromInput = Number(input.secondPaymentTypeRate);
  const secondRateFromComment = parseRateFromComment(input.secondPaymentTypeComment);
  const secondExplicitRate = Number.isFinite(secondRateFromInput) && secondRateFromInput > 0
    ? secondRateFromInput
    : secondRateFromComment;
  const secondRate = secondPaymentTypeName
    ? getPaymentRate(secondPaymentType.provider, secondPaymentType.months, secondExplicitRate)
    : 0;

  const baseTotal = roundMoney(items.reduce((sum, item) => sum + item.lineTotal, 0));
  if (loyaltyRedemption > baseTotal) {
    throw httpError(400, 'Нельзя списать бонусов больше суммы товара.');
  }
  const maxLoyaltyRedemption = roundMoney(baseTotal * getLoyaltyMaxRedeemPercent() / 100);
  if (loyaltyRedemption > maxLoyaltyRedemption) {
    throw httpError(400, `Можно списать бонусами не больше ${formatMoney(maxLoyaltyRedemption)} сом.`);
  }
  const payableTotal = roundMoney(baseTotal - loyaltyRedemption);
  const prepaidTotal = roundMoney(cashPrepayment + transferPrepayment);
  if (prepaidTotal > payableTotal) {
    throw httpError(400, 'Предоплата не может быть больше суммы товара.');
  }

  const installmentBase = roundMoney(payableTotal - prepaidTotal);
  if (secondBankAmount > installmentBase) {
    throw httpError(400, 'Сумма через второй банк не может быть больше остатка после оплаты сразу.');
  }
  const primaryBankAmount = roundMoney(installmentBase - secondBankAmount);
  const commission = roundMoney(primaryBankAmount * rate + secondBankAmount * secondRate);
  const finalTotal = payableTotal;
  const netTotal = roundMoney(payableTotal - commission);
  const costTotal = roundMoney(items.reduce((sum, item) => sum + item.costTotal, 0));
  const netProfit = roundMoney(netTotal - costTotal);
  const primaryMonthlyPayment = months > 0 ? primaryBankAmount / months : 0;
  const secondMonthlyPayment = secondPaymentType.months > 0 ? secondBankAmount / secondPaymentType.months : 0;
  const monthlyPayment = roundMoney(primaryMonthlyPayment + secondMonthlyPayment);
  const paymentLabel = secondBankAmount > 0
    ? `${paymentTypeName} + ${secondPaymentTypeName}`
    : paymentTypeName;

  const result = {
    items,
    bank: paymentType.provider,
    paymentType: paymentTypeName,
    paymentLabel,
    months,
    rate,
    primaryBankAmount,
    secondPaymentType: secondPaymentTypeName,
    secondPaymentTypeHref: String(input.secondPaymentTypeHref || ''),
    secondMonths: secondPaymentType.months,
    secondRate,
    secondBankAmount,
    baseTotal,
    loyaltyRedemption,
    payableTotal,
    cashPrepayment,
    prepaymentMethodName,
    transferPrepayment,
    prepaidTotal,
    installmentBase,
    commission,
    finalTotal,
    netTotal,
    costTotal,
    netProfit,
    monthlyPayment,
    currency: 'KGS'
  };
  result.documentType = resolveDocumentType(result);
  return result;
}

async function createMoySkladDocument(calculation, input) {
  const token = getMoySkladTokenFor(input);
  const documentType = String(input.documentType || resolveDocumentType(calculation));
  const organizationHref = getMoySkladEnvValue('ORGANIZATION_HREF', input);
  if (input.customerMode !== 'retail' && !String(input.customerPhone || '').trim()) {
    throw httpError(400, 'Укажите номер телефона клиента.');
  }
  const agentHref = await getOrCreateCounterparty(token, input);
  const storeHref = input.storeHref || getMoySkladEnvValue('STORE_HREF', input);
  const retailStoreHref = input.retailStoreHref || getMoySkladEnvValue('RETAIL_STORE_HREF', input);

  if (!['customerorder', 'demand', 'retaildemand'].includes(documentType)) {
    throw httpError(500, 'MOYSKLAD_DOCUMENT_TYPE должен быть auto, customerorder, demand или retaildemand.');
  }

  if (documentType === 'demand' && !storeHref) {
    throw httpError(500, 'Для создания Отгрузки нужен MOYSKLAD_STORE_HREF.');
  }
  if (documentType === 'retaildemand' && !retailStoreHref) {
    throw httpError(500, 'Для создания розничной продажи нужна точка продаж.');
  }
  if (documentType === 'demand' && !calculation.items.length) {
    throw httpError(400, 'Выберите товар для отгрузки.');
  }
  if (documentType === 'retaildemand' && !calculation.items.length) {
    throw httpError(400, 'Выберите товар для розничной продажи.');
  }

  const description = buildDocumentDescription(calculation);

  const positions = buildPositions(calculation);
  const documentTotal = fromMoySkladPrice(getPositionsTotal(positions));

  const payload = {
    organization: meta(organizationHref, 'organization'),
    agent: meta(agentHref, 'counterparty'),
    description,
    positions
  };

  if (documentType === 'retaildemand') {
    payload.retailStore = meta(retailStoreHref, 'retailstore');
    const retailStoreStockHref = input.storeHref || await getStoreHrefForRetailStore(token, retailStoreHref);
    if (retailStoreStockHref) {
      payload.store = meta(retailStoreStockHref, 'store');
    }
    const retailShiftHref = input.retailShiftHref || await getActiveRetailShiftHref(token, retailStoreHref);
    if (!retailShiftHref) {
      throw httpError(400, 'Для выбранной точки продаж нет открытой смены.');
    }
    payload.retailShift = meta(retailShiftHref, 'retailshift');
    Object.assign(payload, getRetailPaymentSums(calculation, documentTotal));
  } else if (storeHref) {
    payload.store = meta(storeHref, 'store');
  }

  if (process.env.MOYSKLAD_STATE_HREF) {
    payload.state = meta(process.env.MOYSKLAD_STATE_HREF, 'state');
  }

  const attributes = [];
  const paymentTypeAttributeHref = getAttributeHref('PAYMENT_TYPE', documentType);
  if (input.paymentTypeHref && paymentTypeAttributeHref) {
    attributes.push({
      meta: {
        href: paymentTypeAttributeHref,
        type: 'attributemetadata',
        mediaType: 'application/json'
      },
      value: meta(input.paymentTypeHref, 'customentity')
    });
  }

  const employeeAttributeHref = getAttributeHref('EMPLOYEE', documentType);
  if (input.employeeHref && employeeAttributeHref) {
    attributes.push({
      meta: {
        href: employeeAttributeHref,
        type: 'attributemetadata',
        mediaType: 'application/json'
      },
      value: meta(input.employeeHref, 'customentity')
    });
  }

  const receivableAttributeHref = getAttributeHref('RECEIVABLE', documentType);
  if (receivableAttributeHref) {
    attributes.push({
      meta: {
        href: receivableAttributeHref,
        type: 'attributemetadata',
        mediaType: 'application/json'
      },
      value: Math.round(getReceivableAmount(calculation, documentType))
    });
  }

  const paidAttributeHref = getAttributeHref('PAID', documentType);
  if (paidAttributeHref) {
    attributes.push({
      meta: {
        href: paidAttributeHref,
        type: 'attributemetadata',
        mediaType: 'application/json'
      },
      value: Math.round(getPaidAmount(calculation))
    });
  }

  const unpaidAttributeHref = getAttributeHref('UNPAID', documentType);
  if (unpaidAttributeHref) {
    attributes.push({
      meta: {
        href: unpaidAttributeHref,
        type: 'attributemetadata',
        mediaType: 'application/json'
      },
      value: Math.round(getUnpaidAmount(calculation))
    });
  }

  const commissionAttributeHref = getAttributeHref('COMMISSION', documentType);
  if (commissionAttributeHref) {
    attributes.push({
      meta: {
        href: commissionAttributeHref,
        type: 'attributemetadata',
        mediaType: 'application/json'
      },
      value: `${formatMoney(calculation.commission)} сом`
    });
  }

  const netProfitAttributeHref = getAttributeHref('NET_PROFIT', documentType);
  if (netProfitAttributeHref) {
    attributes.push({
      meta: {
        href: netProfitAttributeHref,
        type: 'attributemetadata',
        mediaType: 'application/json'
      },
      value: Math.round(calculation.netProfit)
    });
  }

  if (attributes.length) {
    payload.attributes = attributes;
  }

  const data = await postMoySkladDocumentWithAttributeRetry(token, documentType, payload);

  const document = {
    id: data.id,
    name: data.name,
    type: documentType,
    moment: data.moment,
    sum: data.sum,
    meta: data.meta
  };

  if (documentType === 'demand' && getPaidAmount(calculation) > 0) {
    document.payment = await createIncomingPayment(token, {
      organizationHref,
      agentHref,
      demandMeta: data.meta,
      amount: getPaidAmount(calculation),
      description: `Оплата по отгрузке ${data.name || ''}`.trim()
    });
  }

  return document;
}

async function postMoySkladDocumentWithAttributeRetry(token, documentType, payload) {
  const safePayload = structuredClone(payload);
  const skippedAttributeIds = [];

  for (let attempt = 0; attempt < 6; attempt += 1) {
    const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/${documentType}`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json;charset=utf-8',
        'Content-Type': 'application/json;charset=utf-8'
      },
      body: JSON.stringify(safePayload)
    });

    const data = await response.json().catch(() => null);
    if (response.ok) {
      if (skippedAttributeIds.length) {
        data._skippedAttributeIds = skippedAttributeIds;
      }
      return data;
    }

    const badAttributeId = getMissingAttributeId(data);
    if (!badAttributeId || !Array.isArray(safePayload.attributes)) {
      throw httpError(response.status, 'МойСклад вернул ошибку при создании документа.', data);
    }

    const before = safePayload.attributes.length;
    safePayload.attributes = safePayload.attributes.filter((attribute) =>
      getIdFromHref(attribute?.meta?.href) !== badAttributeId
    );
    if (safePayload.attributes.length === before) {
      throw httpError(response.status, 'МойСклад вернул ошибку при создании документа.', data);
    }
    if (!safePayload.attributes.length) {
      delete safePayload.attributes;
    }
    skippedAttributeIds.push(badAttributeId);
    console.warn(`MoySklad attribute ${badAttributeId} not found. Retrying ${documentType} without this attribute.`);
  }

  throw httpError(500, 'Не удалось создать документ: слишком много некорректных доп.полей.');
}

function getMissingAttributeId(data) {
  const errors = Array.isArray(data?.errors) ? data.errors : [];
  for (const error of errors) {
    const message = String(error?.error || '');
    if (error?.code !== 1021 || !message.includes('AttributeMetadata')) {
      continue;
    }
    const match = message.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
    if (match) {
      return match[0];
    }
  }
  return '';
}

function resolveDocumentType(calculation) {
  const configuredType = process.env.MOYSKLAD_DOCUMENT_TYPE || 'auto';
  if (configuredType !== 'auto') {
    return configuredType;
  }

  return shouldCreateRetailDemand(calculation) ? 'retaildemand' : 'demand';
}

function getRemainderLabel(calculation) {
  const paymentName = String(calculation.paymentType || '').toLowerCase();
  if (paymentName.includes('долг')) {
    return 'В долг';
  }
  if (calculation.commission > 0) {
    return 'В рассрочку';
  }
  return 'Остаток';
}

function buildDocumentDescription(calculation) {
  const paymentName = String(calculation.paymentType || '');
  const paymentNameLower = paymentName.toLowerCase();
  const paidAmount = getPaidAmount(calculation);
  const unpaidAmount = getUnpaidAmount(calculation);
  const isDebt = paymentNameLower.includes('долг');
  const hasSecondBank = Number(calculation.secondBankAmount || 0) > 0;
  const isMixed = paidAmount > 0 && unpaidAmount > 0;

  const lines = (isMixed || hasSecondBank) && !isDebt
    ? []
    : [`Тип оплаты: ${paymentName}.`];

  if (isDebt) {
    lines.push(`${calculation.prepaymentMethodName}: ${formatMoney(paidAmount)} сом.`);
    lines.push(`Не оплачено: ${formatMoney(unpaidAmount)} сом.`);
    lines.push(`Долг: ${formatMoney(unpaidAmount)} сом.`);
  } else if (hasSecondBank) {
    if (paidAmount > 0) {
      lines.push(`${calculation.prepaymentMethodName}: ${formatMoney(paidAmount)} сом.`);
    }
    if (calculation.primaryBankAmount > 0) {
      lines.push(`${paymentName}: ${formatMoney(calculation.primaryBankAmount)} сом.`);
    }
    lines.push(`${calculation.secondPaymentType}: ${formatMoney(calculation.secondBankAmount)} сом.`);
  } else if (isMixed) {
    lines.push(`${calculation.prepaymentMethodName}: ${formatMoney(paidAmount)} сом.`);
    lines.push(`${paymentName}: ${formatMoney(unpaidAmount)} сом.`);
  }
  if (calculation.loyaltyRedemption > 0) {
    lines.push(`Бонусы списано: ${formatMoney(calculation.loyaltyRedemption)} сом.`);
  }

  return lines.slice(0, 4).join('\n');
}

function getPaidAmount(calculation) {
  return roundMoney(calculation.prepaidTotal || 0);
}

function getUnpaidAmount(calculation) {
  return roundMoney(Math.max(0, calculation.finalTotal - getPaidAmount(calculation)));
}

function getReceivableAmount(calculation, documentType) {
  if (calculation.commission > 0) {
    return calculation.netTotal;
  }

  if (documentType === 'retaildemand') {
    return calculation.finalTotal;
  }

  return getUnpaidAmount(calculation);
}

async function createIncomingPayment(token, input) {
  const amount = roundMoney(input.amount || 0);
  if (amount <= 0) {
    return null;
  }

  const sum = toMoySkladPrice(amount);
  const payload = {
    organization: meta(input.organizationHref, 'organization'),
    agent: meta(input.agentHref, 'counterparty'),
    sum,
    description: input.description || 'Создано автоматически из приложения рассрочки',
    operations: [
      {
        meta: input.demandMeta,
        linkedSum: sum
      }
    ]
  };

  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/paymentin`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8',
      'Content-Type': 'application/json;charset=utf-8'
    },
    body: JSON.stringify(payload)
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Отгрузка создана, но не удалось создать входящий платеж.', data);
  }

  return {
    id: data.id,
    name: data.name,
    sum: data.sum,
    meta: data.meta
  };
}

async function createCommercialMoySkladDocument(input) {
  const token = getMoySkladTokenFor(input);
  const organizationHref = getMoySkladEnvValue('ORGANIZATION_HREF', input);
  const documentType = String(input.documentType || 'customerorder');
  if (!['customerorder', 'demand'].includes(documentType)) {
    throw httpError(400, 'Выберите тип документа: счет или отгрузка.');
  }

  const items = getOrderItems(input);
  const agentHref = await getOrCreateCounterparty(token, input);
  const storeHref = input.storeHref || getMoySkladEnvValue('STORE_HREF', input);

  if (documentType === 'demand' && !storeHref) {
    throw httpError(500, 'Для создания отгрузки нужен MOYSKLAD_STORE_HREF.');
  }

  const payload = {
    organization: meta(organizationHref, 'organization'),
    agent: meta(agentHref, 'counterparty'),
    description: String(input.description || '').trim() || (documentType === 'demand' ? 'Отгрузка' : 'Счет на оплату'),
    positions: items.map((item) => ({
      quantity: item.quantity,
      price: toMoySkladPrice(item.productPrice),
      assortment: meta(item.assortmentHref, item.assortmentType)
    }))
  };

  if (documentType === 'demand') {
    payload.store = meta(storeHref, 'store');
  }

  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/${documentType}`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8',
      'Content-Type': 'application/json;charset=utf-8'
    },
    body: JSON.stringify(payload)
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось создать коммерческий документ в МойСклад.', data);
  }

  return {
    id: data.id,
    name: data.name,
    type: documentType,
    moment: data.moment,
    sum: data.sum,
    meta: data.meta
  };
}

async function createCommercialDemandDocument(input) {
  const payload = {
    items: Array.isArray(input.items) ? input.items : [],
    customerMode: input.customerMode || 'new',
    customerName: input.customerName || '',
    customerPhone: input.customerPhone || '',
    customerAddress: input.customerAddress || '',
    customerInn: input.customerInn || '',
    customerHref: input.customerHref || '',
    storeHref: input.storeHref || '',
    retailStoreHref: input.retailStoreHref || '',
    branchName: input.branchName || '',
    employeeName: input.employeeName || '',
    paymentScenario: 'cash',
    paymentTypeName: 'Наличными',
    prepaymentMethodName: 'Наличными',
    cashPrepayment: 0,
    transferPrepayment: 0,
    secondBankAmount: 0,
    loyaltyRedemption: 0,
    documentType: 'demand'
  };

  const calculation = calculate(await hydrateOrderItemCosts(payload));
  const token = getMoySkladTokenFor(payload);
  const document = await createMoySkladDocument({
    ...calculation,
    documentType: 'demand'
  }, payload);
  return document;
}

async function createCommercialWordInvoice(input) {
  const token = getMoySkladTokenFor(input);
  const items = getOrderItems(input);
  await getOrCreateCounterparty(token, input);

  const total = roundMoney(items.reduce((sum, item) => sum + item.lineTotal, 0));
  const today = new Date();
  const invoiceNumber = `INV-${today.getFullYear()}${String(today.getMonth() + 1).padStart(2, '0')}${String(today.getDate()).padStart(2, '0')}-${String(today.getTime()).slice(-4)}`;
  const dateLabel = new Intl.DateTimeFormat('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(today);
  const html = buildCommercialInvoiceHtml(input, items, { total, invoiceNumber, dateLabel });

  return {
    name: `schet-na-oplatu-${invoiceNumber}.doc`,
    content: Buffer.from(`\ufeff${html}`, 'utf8')
  };
}

async function createCommercialPdfInvoice(input) {
  const token = getMoySkladTokenFor(input);
  const items = await enrichInvoiceItemsWithImages(token, getOrderItems(input));
  await getOrCreateCounterparty(token, input);

  const total = roundMoney(items.reduce((sum, item) => sum + item.lineTotal, 0));
  const today = new Date();
  const invoiceNumber = `INV-${today.getFullYear()}${String(today.getMonth() + 1).padStart(2, '0')}${String(today.getDate()).padStart(2, '0')}-${String(today.getTime()).slice(-4)}`;
  const dateLabel = new Intl.DateTimeFormat('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(today);
  const html = buildCommercialInvoiceHtml(input, items, { total, invoiceNumber, dateLabel });
  const content = await renderHtmlToPdf(html);

  return {
    name: `schet-na-oplatu-${invoiceNumber}.pdf`,
    content
  };
}

function buildCommercialInvoiceHtml(input, items, meta) {
  const customerName = String(input.customerName || 'Контрагент').trim();
  const customerInn = String(input.customerInn || '').trim();
  const customerBank = String(input.customerBank || '').trim();
  const customerBik = String(input.customerBik || '').trim();
  const customerSettlementAccount = String(input.customerSettlementAccount || '').trim();
  const customerCorrAccount = String(input.customerCorrAccount || '').trim();
  const customerOkpo = String(input.customerOkpo || '').trim();
  const customerPhone = String(input.customerPhone || '').trim();
  const customerEmail = String(input.customerEmail || '').trim();
  const customerAddress = String(input.customerAddress || '').trim();
  const customerGroups = Array.isArray(input.customerGroups) ? input.customerGroups.filter(Boolean) : [];
  const total = meta.total;
  const invoiceNumber = meta.invoiceNumber;
  const dateLabel = meta.dateLabel;

  const rows = items.map((item, index) => `
    <tr>
      <td>${index + 1}</td>
      <td>${item.imageDataUrl ? `<img src="${item.imageDataUrl}" alt="" style="width:54px;height:54px;object-fit:contain;display:block;margin:auto;">` : ''}</td>
      <td>${escapeWordHtml(item.productName || '')}</td>
      <td>${escapeWordHtml(item.code || '')}</td>
      <td>${formatMoney(item.quantity)}</td>
      <td>${formatMoney(item.productPrice)}</td>
      <td>${formatMoney(item.lineTotal)}</td>
    </tr>
  `).join('');

  const html = `<!doctype html>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<meta charset="utf-8">
<title>Счет на оплату</title>
<style>
body { font-family: Arial, sans-serif; font-size: 12pt; color: #111; }
h1 { font-size: 18pt; margin: 0 0 8px; }
.meta, .party { margin: 0 0 14px; }
.meta p, .party p { margin: 4px 0; }
table { width: 100%; border-collapse: collapse; margin-top: 14px; }
th, td { border: 1px solid #333; padding: 6px 8px; vertical-align: top; }
th { background: #eef3fb; }
.sum { margin-top: 16px; text-align: right; font-size: 13pt; }
.words { margin-top: 8px; font-style: italic; }
</style>
</head>
<body>
  <h1>Счет на оплату</h1>
  <div class="meta">
    <p><strong>Номер:</strong> ${escapeWordHtml(invoiceNumber)}</p>
    <p><strong>Дата:</strong> ${escapeWordHtml(dateLabel)}</p>
    <p><strong>Основание:</strong> ${escapeWordHtml(String(input.description || 'Оплата товаров').trim() || 'Оплата товаров')}</p>
  </div>
  <div class="party">
    <p><strong>Организация:</strong> ${escapeWordHtml(getInvoiceSellerLine())}</p>
  </div>
  <div class="party">
    <p><strong>Покупатель:</strong></p>
    <p>${escapeWordHtml(customerName)}</p>
    ${customerInn ? `<p>ИНН ${escapeWordHtml(customerInn)}</p>` : ''}
    ${customerOkpo ? `<p>ОКПО ${escapeWordHtml(customerOkpo)}</p>` : ''}
    ${customerBik ? `<p>БИК ${escapeWordHtml(customerBik)}${customerBank ? ` ${escapeWordHtml(customerBank)}` : ''}</p>` : customerBank ? `<p>${escapeWordHtml(customerBank)}</p>` : ''}
    ${customerSettlementAccount ? `<p>p/c ${escapeWordHtml(customerSettlementAccount)}</p>` : ''}
    ${customerCorrAccount ? `<p>Корр. счет ${escapeWordHtml(customerCorrAccount)}</p>` : ''}
    ${customerAddress ? `<p>Адрес: ${escapeWordHtml(customerAddress)}</p>` : ''}
    ${(customerPhone || customerEmail) ? `<p>${escapeWordHtml([customerPhone, customerEmail].filter(Boolean).join('. '))}</p>` : ''}
    ${customerGroups.length ? `<p>Группы: ${escapeWordHtml(customerGroups.join(', '))}</p>` : ''}
  </div>
  <table>
    <thead>
      <tr>
        <th style="width:5%">#</th>
        <th style="width:10%">Фото</th>
        <th style="width:33%">Товар</th>
        <th style="width:14%">Артикул</th>
        <th style="width:10%">Кол-во</th>
        <th style="width:14%">Цена</th>
        <th style="width:14%">Сумма</th>
      </tr>
    </thead>
    <tbody>${rows}</tbody>
  </table>
  <div class="sum"><strong>Всего: ${escapeWordHtml(formatMoney(total))}</strong></div>
  <div class="sum"><strong>К оплате: ${escapeWordHtml(formatMoney(total))}</strong></div>
  <div>в том числе НДС: 0,00</div>
  <div>в том числе НСП: 0,00</div>
  <div class="sum">Всего наименований ${items.length}, на сумму ${escapeWordHtml(formatMoney(total))} KGS</div>
  <div class="words">${escapeWordHtml(numberToRussianSom(total))}</div>
  <div style="margin-top:28px;">Руководитель ____________________ ${escapeWordHtml(getInvoiceDirectorName())}</div>
</body>
</html>`;
  return html;
}

async function renderHtmlToPdf(html) {
  const chromePath = process.env.CHROME_BIN || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
  const workdir = await mkdtemp(join(tmpdir(), 'mysrs-invoice-'));
  const htmlPath = join(workdir, 'invoice.html');
  const pdfPath = join(workdir, 'invoice.pdf');

  try {
    await writeFile(htmlPath, html, 'utf8');
    await execFileAsync(chromePath, [
      '--headless=new',
      '--disable-gpu',
      '--allow-file-access-from-files',
      '--no-pdf-header-footer',
      `--print-to-pdf=${pdfPath}`,
      htmlPath
    ], { timeout: 30000 });
    return await readFile(pdfPath);
  } catch (error) {
    throw httpError(500, 'Не удалось сформировать PDF-счет.', { message: error.message });
  } finally {
    await rm(workdir, { recursive: true, force: true }).catch(() => {});
  }
}

async function enrichInvoiceItemsWithImages(token, items) {
  return mapWithConcurrency(items, 3, async (item) => ({
    ...item,
    imageDataUrl: await getMoySkladProductImageDataUrl(token, item.assortmentHref).catch(() => '')
  }));
}

async function getMoySkladProductImageDataUrl(token, productHref) {
  if (!productHref) return '';

  const response = await moySkladFetch(`${productHref}/images?limit=1`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });
  const data = await response.json().catch(() => null);
  if (!response.ok) return '';

  const image = Array.isArray(data?.rows) ? data.rows[0] : null;
  const downloadHref = image?.miniature?.downloadHref
    || image?.tiny?.downloadHref
    || image?.downloadHref
    || image?.meta?.downloadHref
    || '';
  if (!downloadHref) return '';

  const imageResponse = await moySkladFetch(downloadHref, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'image/*'
    }
  });
  if (!imageResponse.ok) return '';
  const mimeType = imageResponse.headers.get('content-type') || 'image/png';
  const buffer = Buffer.from(await imageResponse.arrayBuffer());
  return `data:${mimeType};base64,${buffer.toString('base64')}`;
}

function shouldCreateRetailDemand(calculation) {
  const paymentName = String(calculation.paymentType || '').toLowerCase();
  const debtPayment = paymentName.includes('долг');

  if (debtPayment) {
    return false;
  }

  return true;
}

function getOrderItems(input) {
  const rawItems = Array.isArray(input.items) && input.items.length
    ? input.items
    : [{
        productName: input.productName,
        assortmentHref: input.assortmentHref,
        assortmentType: input.assortmentType,
        productPrice: input.productPrice,
        quantity: input.quantity
      }];

  return rawItems.map((item, index) => {
    const isGift = item.isGift === true;
    const productPrice = isGift ? 0 : toMoney(item.productPrice);
    const productCost = toMoney(item.productCost || 0);
    const quantity = Number(item.quantity || 1);
    const assortmentHref = item.assortmentHref;
    const assortmentType = item.assortmentType || process.env.MOYSKLAD_ASSORTMENT_TYPE || 'product';

    if (!assortmentHref) {
      throw httpError(400, `Выберите товар в позиции ${index + 1}.`);
    }
    if (!Number.isFinite(productPrice) || (!isGift && productPrice <= 0)) {
      throw httpError(400, `Укажите цену товара в позиции ${index + 1}.`);
    }
    if (!Number.isFinite(quantity) || quantity <= 0) {
      throw httpError(400, `Укажите количество в позиции ${index + 1}.`);
    }

    return {
      productName: item.productName || `Позиция ${index + 1}`,
      code: String(item.code || item.article || '').trim(),
      assortmentHref,
      assortmentType,
      productPrice,
      productCost,
      isGift,
      quantity,
      lineTotal: roundMoney(productPrice * quantity),
      costTotal: roundMoney(productCost * quantity)
    };
  });
}

function buildPositions(calculation) {
  const discounts = distributeLoyaltyDiscount(calculation);
  return calculation.items.map((item, index) => ({
    quantity: item.quantity,
    price: toMoySkladPrice(item.productPrice),
    ...(discounts[index] > 0 ? { discount: discounts[index] } : {}),
    assortment: meta(item.assortmentHref, item.assortmentType)
  }));
}

function distributeLoyaltyDiscount(calculation) {
  const targetDiscount = toMoySkladPrice(calculation.loyaltyRedemption || 0);
  if (targetDiscount <= 0) {
    return calculation.items.map(() => 0);
  }

  const lineTotals = calculation.items.map((item) => toMoySkladPrice(item.lineTotal));
  const total = lineTotals.reduce((sum, value) => sum + value, 0);
  if (total <= 0) {
    return calculation.items.map(() => 0);
  }

  let distributed = 0;
  const lineDiscounts = lineTotals.map((lineTotal, index) => {
    if (index === lineTotals.length - 1) {
      return Math.max(0, targetDiscount - distributed);
    }
    const value = Math.round(targetDiscount * lineTotal / total);
    distributed += value;
    return value;
  });

  return calculation.items.map((item, index) => {
    const lineTotal = lineTotals[index];
    if (lineTotal <= 0) {
      return 0;
    }
    return Number((lineDiscounts[index] / lineTotal * 100).toFixed(6));
  });
}

function getPositionsTotal(positions) {
  return positions.reduce((sum, position) => {
    const quantity = Number(position.quantity || 0);
    const price = Number(position.price || 0);
    const discount = Number(position.discount || 0);
    return sum + Math.round(price * quantity * Math.max(0, 100 - discount) / 100);
  }, 0);
}

function getRetailPaymentSums(calculation, documentTotal = calculation.finalTotal) {
  const paymentName = String(calculation.paymentType || '').toLowerCase();
  const prepaidTotal = roundMoney(calculation.cashPrepayment + calculation.transferPrepayment);
  const total = roundMoney(documentTotal);

  if (prepaidTotal <= 0 && (paymentName.includes('налич') || paymentName.includes('cash'))) {
    return {
      cashSum: toMoySkladPrice(total),
      noCashSum: 0
    };
  }

  if (prepaidTotal <= 0 && (paymentName.includes('карта') || paymentName.includes('qr'))) {
    return {
      cashSum: 0,
      noCashSum: toMoySkladPrice(total)
    };
  }

  const prepaidAmount = roundMoney(Math.min(calculation.cashPrepayment, total));
  const prepaymentIsCash = isCashPrepaymentMethod(calculation.prepaymentMethodName);
  const cashSum = prepaymentIsCash ? prepaidAmount : 0;
  const noCashSum = roundMoney(total - cashSum);
  return {
    cashSum: toMoySkladPrice(cashSum),
    noCashSum: toMoySkladPrice(noCashSum)
  };
}

function isCashPrepaymentMethod(methodName) {
  const name = String(methodName || '').toLowerCase();
  return name.includes('налич') || name.includes('cash');
}

async function getOrCreateCounterparty(token, input) {
  if (input.agentHref) {
    return input.agentHref;
  }
  if (input.customerMode === 'retail') {
    return getMoySkladEnvValue('AGENT_HREF', input);
  }

  if (input.customerMode === 'existing' && input.customerHref) {
    await updateCounterpartyContact(token, input.customerHref, input);
    return input.customerHref;
  }

  const customerName = String(input.customerName || '').trim();
  if (!customerName) {
    throw httpError(400, 'Укажите ФИО клиента.');
  }

  const existing = await findCounterpartyDuplicate(token, customerName, input.customerPhone);
  if (existing) {
    throw httpError(409, `Такой клиент уже есть: ${existing.name}. Выберите режим "Старый клиент".`);
  }

  const payload = {
    name: customerName,
    description: 'Создано автоматически из приложения рассрочки'
  };

  const tags = Array.isArray(input.customerGroups) ? input.customerGroups.filter((value) => String(value || '').trim()) : [];
  const bank = String(input.customerBank || '').trim();
  const bik = String(input.customerBik || '').trim();
  const settlementAccount = String(input.customerSettlementAccount || '').trim();
  const corrAccount = String(input.customerCorrAccount || '').trim();
  const okpo = String(input.customerOkpo || '').trim();
  const email = String(input.customerEmail || '').trim();

  const descriptionLines = ['Создано автоматически из приложения рассрочки'];
  if (bank) descriptionLines.push(`Банк: ${bank}`);
  if (bik) descriptionLines.push(`БИК: ${bik}`);
  if (settlementAccount) descriptionLines.push(`Расчетный счет: ${settlementAccount}`);
  if (corrAccount) descriptionLines.push(`Корр. счет: ${corrAccount}`);
  if (okpo) descriptionLines.push(`ОКПО: ${okpo}`);
  payload.description = descriptionLines.join('\n');

  const inn = String(input.customerInn || '').trim();
  if (inn) {
    payload.inn = inn;
  }

  const phone = String(input.customerPhone || '').trim();
  if (phone) {
    payload.phone = phone;
  }
  if (email) {
    payload.email = email;
  }

  const address = String(input.customerAddress || '').trim();
  if (address) {
    payload.actualAddress = address;
  }
  if (tags.length) {
    payload.tags = tags;
  }

  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/counterparty`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8',
      'Content-Type': 'application/json;charset=utf-8'
    },
    body: JSON.stringify(payload)
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось создать контрагента в МойСклад.', data);
  }

  return data.meta.href;
}

async function updateCounterpartyContact(token, href, input) {
  const payload = {};
  const phone = String(input.customerPhone || '').trim();
  const address = String(input.customerAddress || '').trim();
  const bank = String(input.customerBank || '').trim();
  const bik = String(input.customerBik || '').trim();
  const settlementAccount = String(input.customerSettlementAccount || '').trim();
  const corrAccount = String(input.customerCorrAccount || '').trim();
  const okpo = String(input.customerOkpo || '').trim();
  const email = String(input.customerEmail || '').trim();
  const tags = Array.isArray(input.customerGroups) ? input.customerGroups.filter((value) => String(value || '').trim()) : [];

  if (phone) {
    payload.phone = phone;
  }
  if (email) {
    payload.email = email;
  }
  if (address) {
    payload.actualAddress = address;
  }
  if (tags.length) {
    payload.tags = tags;
  }
  if (bank || bik || settlementAccount || corrAccount || okpo) {
    const lines = [];
    if (bank) lines.push(`Банк: ${bank}`);
    if (bik) lines.push(`БИК: ${bik}`);
    if (settlementAccount) lines.push(`Расчетный счет: ${settlementAccount}`);
    if (corrAccount) lines.push(`Корр. счет: ${corrAccount}`);
    if (okpo) lines.push(`ОКПО: ${okpo}`);
    payload.description = lines.join('\n');
  }
  if (!Object.keys(payload).length) {
    return;
  }

  const response = await moySkladFetch(href, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8',
      'Content-Type': 'application/json;charset=utf-8'
    },
    body: JSON.stringify(payload)
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось обновить контрагента в МойСклад.', data);
  }
}

async function findCounterparty(token, name) {
  const params = new URLSearchParams({ search: name, limit: '20' });
  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/counterparty?${params}`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось найти контрагента в МойСклад.', data);
  }

  const normalizedName = name.toLowerCase();
  return (data.rows || []).find((counterparty) => String(counterparty.name || '').toLowerCase() === normalizedName);
}

async function findCounterpartyDuplicate(token, name, phone) {
  const candidates = [];
  const normalizedName = String(name || '').trim().toLowerCase();
  const normalizedPhone = normalizePhone(phone);

  if (normalizedName) {
    const byName = await findCounterparties(token, name);
    candidates.push(...byName);
  }
  if (normalizedPhone) {
    const byPhone = await findCounterparties(token, phone);
    candidates.push(...byPhone);
  }

  return candidates.find((counterparty) => {
    const sameName = normalizedName && String(counterparty.name || '').trim().toLowerCase() === normalizedName;
    const samePhone = normalizedPhone && normalizePhone(counterparty.phone) === normalizedPhone;
    return sameName || samePhone;
  });
}

async function findCounterparties(token, search) {
  const params = new URLSearchParams({ search: String(search || '').trim(), limit: '20' });
  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/counterparty?${params}`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось найти контрагента в МойСклад.', data);
  }

  return data.rows || [];
}

async function getMoySkladCustomers(search, input = {}) {
  const token = getMoySkladTokenFor(input);
  const params = new URLSearchParams({ limit: '30' });
  if (search.trim()) {
    params.set('search', search.trim());
  }

  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/counterparty?${params}`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось загрузить клиентов из МойСклад.', data);
  }

  return (data.rows || []).map((counterparty) => ({
    id: counterparty.id,
    name: counterparty.name,
    phone: counterparty.phone || '',
    actualAddress: counterparty.actualAddress || '',
    inn: counterparty.inn || '',
    bank: getCounterpartyDescriptionField(counterparty.description, 'Банк'),
    bik: getCounterpartyDescriptionField(counterparty.description, 'БИК'),
    settlementAccount: getCounterpartyDescriptionField(counterparty.description, 'Расчетный счет'),
    corrAccount: getCounterpartyDescriptionField(counterparty.description, 'Корр. счет'),
    okpo: getCounterpartyDescriptionField(counterparty.description, 'ОКПО'),
    groups: Array.isArray(counterparty.tags) ? counterparty.tags : [],
    email: counterparty.email || '',
    href: counterparty.meta.href
  }));
}

async function getWhatsappCustomers(input = {}) {
  const search = normalizeTextSearch(input.search);
  const customerType = String(input.customerType || '').trim();
  const limit = Math.max(20, Math.min(1000, Number(input.limit) || 300));
  const payload = whatsappCustomersCache.value && Date.now() - whatsappCustomersCache.createdAt < WHATSAPP_CUSTOMERS_CACHE_TTL_MS
    ? whatsappCustomersCache.value
    : await loadWhatsappCustomers();

  if (payload !== whatsappCustomersCache.value) {
    whatsappCustomersCache = { value: payload, createdAt: Date.now() };
  }

  const customers = payload.customers
    .filter((customer) => {
      if (customerType && customer.customerType !== customerType) return false;
      if (!search) return true;
      return normalizeTextSearch(`${customer.name} ${customer.phone} ${customer.whatsappPhone} ${customer.inn} ${customer.actualAddress}`).includes(search);
    })
    .slice(0, limit);

  return {
    loadedAt: payload.loadedAt,
    total: payload.customers.length,
    customers,
    filters: { search: input.search || '', customerType, limit }
  };
}

async function loadWhatsappCustomers() {
  const token = requiredEnv('MOYSKLAD_TOKEN');
  const rows = [];
  let offset = 0;
  const limit = 100;

  while (offset < WHATSAPP_CUSTOMERS_LIMIT) {
    const params = new URLSearchParams({
      limit: String(limit),
      offset: String(offset),
      order: 'updated,desc'
    });
    const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/counterparty?${params}`, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json;charset=utf-8'
      }
    });
    const data = await response.json().catch(() => null);
    if (!response.ok) throw httpError(response.status, 'Не удалось загрузить базу клиентов из МойСклад.', data);

    const pageRows = Array.isArray(data?.rows) ? data.rows : [];
    rows.push(...pageRows);
    if (pageRows.length < limit) break;
    offset += limit;
  }

  const seen = new Set();
  const customers = rows.flatMap((counterparty) => {
    const type = normalizeCounterpartyType(counterparty);
    return extractWhatsappPhones(counterparty.phone).map((phone) => ({
      id: `${counterparty.id}:${phone.whatsappPhone}`,
      customerId: counterparty.id,
      href: counterparty.meta?.href || '',
      name: counterparty.name || 'Без имени',
      phone: phone.displayPhone,
      whatsappPhone: phone.whatsappPhone,
      customerType: type,
      customerTypeLabel: getCounterpartyTypeLabel(counterparty),
      inn: counterparty.inn || '',
      actualAddress: counterparty.actualAddress || counterparty.legalAddress || '',
      updated: counterparty.updated || counterparty.created || ''
    }));
  }).filter((customer) => {
    const key = customer.whatsappPhone;
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  }).sort((left, right) => String(left.name).localeCompare(String(right.name), 'ru'));

  return { loadedAt: new Date().toISOString(), customers };
}

function extractWhatsappPhones(value) {
  return String(value || '')
    .split(/[,;/\n\r]+/)
    .map((phone) => normalizeWhatsappPhone(phone))
    .filter(Boolean);
}

function normalizeWhatsappPhone(value) {
  const rawDigits = String(value || '').replace(/\D/g, '');
  if (!rawDigits) return null;
  let digits = rawDigits;
  if (digits.length === 9) digits = `996${digits}`;
  if (digits.length === 10 && digits.startsWith('0')) digits = `996${digits.slice(1)}`;
  if (digits.length === 11 && digits.startsWith('8')) digits = `7${digits.slice(1)}`;
  if (digits.length < 10 || digits.length > 15) return null;
  return {
    displayPhone: `+${digits}`,
    whatsappPhone: digits
  };
}

async function getMoySkladProducts(search, storeHref = '', input = {}) {
  const token = getMoySkladTokenFor(input);
  const normalizedSearch = String(search || '').trim();
  const branchKey = getMoySkladBranchKey(input) || 'default';
  const cacheKey = [
    branchKey,
    String(storeHref || '').trim(),
    normalizedSearch.toLocaleLowerCase('ru-RU')
  ].join('|');
  const cached = moySkladProductSearchCache.get(cacheKey);
  if (cached && Date.now() - cached.createdAt < PRODUCT_SEARCH_CACHE_TTL_MS) {
    return cached.value;
  }

  const queries = getProductSearchQueries(normalizedSearch);
  const allProducts = [];
  const seen = new Set();

  const rowsByQuery = await Promise.all(queries.map((query) =>
    loadMoySkladProductRows(token, query).catch(() => [])
  ));
  for (const rows of rowsByQuery) {
    for (const product of rows) {
      const href = product.meta?.href;
      if (!href || seen.has(href)) {
        continue;
      }
      seen.add(href);
      allProducts.push(product);
    }
  }

  const selectedProducts = allProducts.slice(0, PRODUCT_SEARCH_LIMIT);
  const [currencies, priceTypes] = await Promise.all([
    getMoySkladCurrencies(token).catch(() => []),
    getCachedMoySkladPriceTypes(token, branchKey).catch(() => [])
  ]);
  const priceType36 = findPreferredPriceType(priceTypes, process.env.MOYSKLAD_PRODUCT_PRICE_NAME || '3-6');
  const currenciesByHref = new Map(currencies.map((currency) => [currency.meta?.href, currency]));
  const stockValues = selectedProducts.map((product) => getCachedProductStockValue(storeHref, product.meta?.href || ''));

  const result = selectedProducts.map((product, index) => {
    const cost = getProductCost(product, currenciesByHref);
    const minPrice = getAccountingMinPrice(product, currenciesByHref);
    const price36 = getAccountingSalePriceByName(product, currenciesByHref, process.env.MOYSKLAD_PRODUCT_PRICE_NAME || '3-6', priceType36);
    const wholesalePrice = getAccountingWholesalePrice(product, currenciesByHref);
    productCostCache.set(product.meta?.href || '', { value: cost, createdAt: Date.now() });
    return {
      id: product.id,
      name: product.name,
      code: product.code,
      article: product.article || '',
      externalCode: product.externalCode || '',
      barcode: getProductBarcode(product),
      price: price36.value,
      price36,
      minPrice,
      wholesalePrice,
      cost,
      stock: stockValues[index],
      href: product.meta.href,
      type: product.meta.type
    };
  });
  moySkladProductSearchCache.set(cacheKey, { value: result, createdAt: Date.now() });
  trimMap(moySkladProductSearchCache, 200);
  return result;
}

async function hydrateOrderItemCosts(input) {
  if (!Array.isArray(input.items) || !input.items.length) return input;

  const token = requiredEnv('MOYSKLAD_TOKEN');
  const currencies = await getMoySkladCurrencies(token).catch(() => []);
  const currenciesByHref = new Map(currencies.map((currency) => [currency.meta?.href, currency]));
  const costs = await mapWithConcurrency(input.items, 5, async (item) => {
    const href = String(item.assortmentHref || '');
    const type = String(item.assortmentType || 'product');
    if (!href || type !== 'product') return toMoney(item.productCost || 0);

    const cached = productCostCache.get(href);
    if (cached && Date.now() - cached.createdAt < 300_000) return cached.value;

    const response = await moySkladFetch(href, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json;charset=utf-8'
      }
    });
    const product = await response.json().catch(() => null);
    if (!response.ok) {
      throw httpError(response.status, `Не удалось получить закупочную цену товара «${item.productName || ''}».`, product);
    }
    const value = getProductCost(product, currenciesByHref);
    productCostCache.set(href, { value, createdAt: Date.now() });
    return value;
  });

  return {
    ...input,
    items: input.items.map((item, index) => ({ ...item, productCost: costs[index] }))
  };
}

async function getMoySkladProductStock(token, productHref, storeHref) {
  if (!productHref || !storeHref) return null;

  const cacheKey = `${storeHref}|${productHref}`;
  const cached = productStockCache.get(cacheKey);
  if (cached && Date.now() - cached.createdAt < 20_000) {
    return cached.value;
  }

  const params = new URLSearchParams({
    limit: '1',
    filter: `store=${storeHref};product=${productHref}`
  });
  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/report/stock/all?${params}`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось загрузить остаток товара.', data);
  }

  const row = Array.isArray(data?.rows) ? data.rows[0] : null;
  const rawStock = Number(row?.stock ?? 0);
  const value = Number.isFinite(rawStock) ? rawStock : 0;
  productStockCache.set(cacheKey, { value, createdAt: Date.now() });
  return value;
}

function getCachedProductStockValue(storeHref, productHref) {
  if (!storeHref || !productHref) return null;
  const cached = productStockCache.get(`${storeHref}|${productHref}`);
  if (!cached || Date.now() - cached.createdAt > 300_000) return null;
  return cached.value;
}

function trimMap(map, maxSize) {
  while (map.size > maxSize) {
    map.delete(map.keys().next().value);
  }
}

async function getAccountingPriceCatalog(options = {}) {
  const token = requiredEnv('MOYSKLAD_TOKEN');
  const offset = Math.max(0, Number.parseInt(options.offset, 10) || 0);
  const limit = Math.min(500, Math.max(1, Number.parseInt(options.limit, 10) || 500));
  const [productPage, priceTypes, folders, currencies] = await Promise.all([
    loadMoySkladProductPage(token, offset, limit),
    options.includePriceTypes ? getMoySkladPriceTypes(token) : Promise.resolve([]),
    options.includePriceTypes ? getMoySkladProductFolders(token).catch(() => []) : Promise.resolve([]),
    getMoySkladCurrencies(token).catch(() => [])
  ]);
  const currenciesByHref = new Map(currencies.map((currency) => [currency.meta?.href, currency]));

  return {
    priceTypes,
    folders,
    offset,
    limit,
    total: productPage.total,
    nextOffset: offset + productPage.products.length,
    hasMore: offset + productPage.products.length < productPage.total,
    products: productPage.products.map((product) => ({
      id: product.id,
      name: product.name || '',
      code: product.code || '',
      article: product.article || '',
      href: product.meta?.href || '',
      type: product.meta?.type || 'product',
      archived: Boolean(product.archived),
      folder: getAccountingProductFolder(product),
      buyPrice: getAccountingBuyPrice(product, currenciesByHref),
      minPrice: getAccountingMinPrice(product, currenciesByHref),
      prices: (product.salePrices || []).map((price) => ({
        value: roundMoney(Number(price.value || 0) / 100),
        priceTypeHref: price.priceType?.meta?.href || '',
        priceTypeName: price.priceType?.name || '',
        currencyHref: price.currency?.meta?.href || '',
        currencyIsoCode: resolveAccountingCurrency(price.currency, currenciesByHref).isoCode || '',
        currencyName: resolveAccountingCurrency(price.currency, currenciesByHref).name || resolveAccountingCurrency(price.currency, currenciesByHref).fullName || ''
      }))
    }))
  };
}

async function getAccountingSupplyProducts(query) {
  const token = requiredEnv('MOYSKLAD_TOKEN');
  const normalizedQuery = String(query || '').trim();
  if (!normalizedQuery) throw httpError(400, 'Введите номер или ссылку приемки.');

  const supplyId = getMoySkladEntityIdFromInput(normalizedQuery);
  const supply = supplyId
    ? await loadMoySkladSupply(token, supplyId)
    : await findMoySkladSupply(token, normalizedQuery);
  if (!supply?.id) throw httpError(404, 'Приемка не найдена.');

  const positions = await loadMoySkladSupplyPositions(token, supply.id);
  return {
    id: supply.id,
    name: supply.name || '',
    moment: supply.moment || '',
    products: positions.map((position) => {
      const assortment = position.assortment || {};
      return {
        id: assortment.id || getIdFromHref(assortment.meta?.href || ''),
        href: assortment.meta?.href || '',
        type: assortment.meta?.type || '',
        name: assortment.name || position.name || '',
        code: assortment.code || '',
        article: assortment.article || '',
        quantity: Number(position.quantity || 0)
      };
    }).filter((product) => product.href && product.type === 'product')
  };
}

async function findMoySkladSupply(token, query) {
  const params = new URLSearchParams({
    limit: '10',
    search: query,
    order: 'moment,desc'
  });
  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/supply?${params}`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось найти приемку в МойСклад.', data);
  }

  const rows = Array.isArray(data?.rows) ? data.rows : [];
  const exact = rows.find((item) => String(item.name || '').trim() === query);
  const selected = exact || rows[0];
  if (!selected?.id) throw httpError(404, `Приемка «${query}» не найдена.`);
  return loadMoySkladSupply(token, selected.id);
}

async function loadMoySkladSupply(token, supplyId) {
  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/supply/${supplyId}`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось загрузить приемку из МойСклад.', data);
  }
  return data;
}

async function loadMoySkladSupplyPositions(token, supplyId) {
  const positions = [];
  let offset = 0;
  const limit = 1000;

  while (offset < 10000) {
    const params = new URLSearchParams({
      limit: String(limit),
      offset: String(offset),
      expand: 'assortment'
    });
    const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/supply/${supplyId}/positions?${params}`, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json;charset=utf-8'
      }
    });
    const data = await response.json().catch(() => null);
    if (!response.ok) {
      throw httpError(response.status, 'Не удалось загрузить товары из приемки.', data);
    }

    const rows = Array.isArray(data?.rows) ? data.rows : [];
    positions.push(...rows);
    if (rows.length < limit) break;
    offset += limit;
  }

  return positions;
}

function getMoySkladEntityIdFromInput(value) {
  return String(value || '').match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i)?.[0] || '';
}

function resolveAccountingCurrency(currency, currenciesByHref = new Map()) {
  return currenciesByHref.get(currency?.meta?.href) || currency || {};
}

function getAccountingBuyPrice(product, currenciesByHref) {
  const buyPrice = product.buyPrice || {};
  const currency = resolveAccountingCurrency(buyPrice.currency, currenciesByHref);
  const value = Number(buyPrice.value || 0);
  return {
    value: Number.isFinite(value) ? roundMoney(value / 100) : 0,
    currencyName: currency.name || currency.fullName || '',
    currencyIsoCode: currency.isoCode || '',
    currencyHref: buyPrice.currency?.meta?.href || ''
  };
}

function getAccountingMinPrice(product, currenciesByHref) {
  const minPrice = product.minPrice || {};
  const currency = resolveAccountingCurrency(minPrice.currency, currenciesByHref);
  const value = Number(minPrice.value || 0);
  return {
    value: Number.isFinite(value) ? roundMoney(value / 100) : 0,
    currencyName: currency.name || currency.fullName || '',
    currencyIsoCode: currency.isoCode || '',
    currencyHref: minPrice.currency?.meta?.href || ''
  };
}

function getAccountingWholesalePrice(product, currenciesByHref) {
  const salePrices = Array.isArray(product.salePrices) ? product.salePrices : [];
  const wholesale = findPreferredProductSalePrice(salePrices, 'Оптовая цена');
  const currency = resolveAccountingCurrency(wholesale?.currency, currenciesByHref);
  const rawValue = Number(wholesale?.value || 0);
  const value = Number.isFinite(rawValue)
    ? (isUsdCurrency(currency) ? rawValue / 100 * getReportUsdCostRate(1) : rawValue / 100)
    : 0;
  return {
    value: Number.isFinite(value) ? roundMoney(value) : 0,
    currencyName: 'KGS',
    currencyIsoCode: 'KGS',
    currencyHref: wholesale?.currency?.meta?.href || ''
  };
}

function getAccountingSalePriceByName(product, currenciesByHref, preferredName, preferredPriceType = null) {
  const salePrices = Array.isArray(product.salePrices) ? product.salePrices : [];
  const salePrice = preferredPriceType?.href
    ? salePrices.find((price) => price.priceType?.meta?.href === preferredPriceType.href)
    : findPreferredProductSalePrice(salePrices, preferredName);
  const currency = resolveAccountingCurrency(salePrice?.currency, currenciesByHref);
  const rawValue = Number(salePrice?.value || 0);
  const value = Number.isFinite(rawValue)
    ? (isUsdCurrency(currency) ? rawValue / 100 * getReportUsdCostRate(1) : rawValue / 100)
    : 0;
  return {
    value: Number.isFinite(value) ? roundMoney(value) : 0,
    currencyName: isUsdCurrency(currency) ? 'KGS' : (currency.name || currency.fullName || ''),
    currencyIsoCode: isUsdCurrency(currency) ? 'KGS' : (currency.isoCode || ''),
    currencyHref: salePrice?.currency?.meta?.href || '',
    priceTypeName: preferredPriceType?.name || salePrice?.priceType?.name || ''
  };
}

function getAccountingProductFolder(product) {
  const folder = product.productFolder || {};
  return {
    href: folder.meta?.href || '',
    id: folder.id || getIdFromHref(folder.meta?.href || ''),
    name: folder.name || '',
    pathName: folder.pathName || ''
  };
}

async function loadMoySkladProductPage(token, offset, limit) {
  const params = new URLSearchParams({
    limit: String(limit),
    offset: String(offset),
    order: 'name,asc',
    expand: 'productFolder'
  });
  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/product?${params}`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось загрузить каталог цен из МойСклад.', data);
  }

  const products = data?.rows || [];
  const total = Number(data?.meta?.size);
  return {
    products,
    total: Number.isFinite(total) ? total : offset + products.length
  };
}

async function getMoySkladProductFolders(token) {
  const folders = [];
  let offset = 0;
  const limit = 100;

  while (offset < 5000) {
    const params = new URLSearchParams({
      limit: String(limit),
      offset: String(offset),
      order: 'pathName,asc'
    });
    const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/productfolder?${params}`, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json;charset=utf-8'
      }
    });
    const data = await response.json().catch(() => null);
    if (!response.ok) {
      throw httpError(response.status, 'Не удалось загрузить группы товаров из МойСклад.', data);
    }

    const rows = data?.rows || [];
    folders.push(...rows.map((folder) => ({
      id: folder.id || getIdFromHref(folder.meta?.href || ''),
      name: folder.name || '',
      pathName: folder.pathName || '',
      href: folder.meta?.href || '',
      template: parsePriceFormulaTemplate(folder.description || '')
    })).filter((folder) => folder.href));
    if (rows.length < limit) break;
    offset += limit;
  }

  return folders.sort((left, right) =>
    getFolderDisplayName(left).localeCompare(getFolderDisplayName(right), 'ru')
  );
}

function getFolderDisplayName(folder) {
  return [folder.pathName, folder.name].filter(Boolean).join(' / ');
}

async function updateAccountingFolderPriceTemplate(input) {
  const token = requiredEnv('MOYSKLAD_TOKEN');
  const folderHref = String(input.folderHref || '').trim();
  const templateInput = input.template || null;
  const folderId = getMoySkladEntityIdFromInput(folderHref);
  if (!folderId) throw httpError(400, 'Выберите корректную группу или подгруппу.');

  const folder = await loadMoySkladProductFolder(token, folderId);
  const template = templateInput ? normalizePriceFormulaTemplate(templateInput, folder) : null;
  const description = setPriceFormulaTemplateInDescription(folder.description || '', template);

  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/productfolder/${folderId}`, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ description })
  });
  const updated = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось сохранить шаблон в описании группы.', updated);
  }

  return {
    id: folderId,
    href: updated?.meta?.href || folderHref,
    name: updated?.name || folder.name || '',
    pathName: updated?.pathName || folder.pathName || '',
    template: parsePriceFormulaTemplate(updated?.description || description)
  };
}

async function loadMoySkladProductFolder(token, folderId) {
  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/productfolder/${folderId}`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось загрузить группу товаров из МойСклад.', data);
  }
  return data;
}

function normalizePriceFormulaTemplate(template, folder = {}) {
  const id = String(template.id || folder.meta?.href || folder.id || randomUUID());
  const name = String(template.name || folder.name || 'Шаблон группы').trim();
  const tiers = Array.isArray(template.tiers) ? template.tiers : [];
  const wholesaleTiers = Array.isArray(template.wholesaleTiers) ? template.wholesaleTiers : tiers;
  const normalizeTiers = (items) => items.map((tier) => ({
    from: tier.from ?? '',
    to: tier.to ?? '',
    amount: tier.amount ?? '',
    currency: String(tier.currency || 'kgs').toLowerCase() === 'usd' ? 'usd' : 'kgs'
  }));
  return {
    id,
    name,
    usdRate: toFiniteNumber(template.usdRate, 89),
    markup: 0,
    markupMode: 'tiers',
    tiers: normalizeTiers(tiers),
    wholesaleTiers: normalizeTiers(wholesaleTiers),
    fallbackMarkupMode: 'none',
    fallbackMarkup: 0,
    wholesaleFallbackMarkupMode: 'none',
    wholesaleFallbackMarkup: 0,
    bank36: toFiniteNumber(template.bank36, 10),
    bank912: toFiniteNumber(template.bank912, 20),
    calculate36: template.calculate36 !== false,
    calculate912: template.calculate912 !== false,
    rounding: toFiniteNumber(template.rounding, 10),
    wholesaleRounding: toFiniteNumber(template.wholesaleRounding, 0.1)
  };
}

function toFiniteNumber(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function parsePriceFormulaTemplate(description) {
  const text = String(description || '');
  const startIndex = text.indexOf(PRICE_FORMULA_TEMPLATE_START);
  const endIndex = text.indexOf(PRICE_FORMULA_TEMPLATE_END);
  if (startIndex < 0 || endIndex < 0 || endIndex <= startIndex) return null;

  const encoded = text.slice(startIndex + PRICE_FORMULA_TEMPLATE_START.length, endIndex).trim();
  try {
    const json = Buffer.from(encoded, 'base64url').toString('utf8');
    const parsed = JSON.parse(json);
    return normalizePriceFormulaTemplate(parsed);
  } catch {
    return null;
  }
}

function setPriceFormulaTemplateInDescription(description, template) {
  const clean = removePriceFormulaTemplateFromDescription(description);
  if (!template) return clean;
  const encoded = Buffer.from(JSON.stringify(template), 'utf8').toString('base64url');
  const block = `${PRICE_FORMULA_TEMPLATE_START}\n${encoded}\n${PRICE_FORMULA_TEMPLATE_END}`;
  return [clean, block].filter(Boolean).join('\n\n');
}

function removePriceFormulaTemplateFromDescription(description) {
  const text = String(description || '');
  const startIndex = text.indexOf(PRICE_FORMULA_TEMPLATE_START);
  const endIndex = text.indexOf(PRICE_FORMULA_TEMPLATE_END);
  if (startIndex < 0 || endIndex < 0 || endIndex <= startIndex) return text.trim();
  return `${text.slice(0, startIndex)}${text.slice(endIndex + PRICE_FORMULA_TEMPLATE_END.length)}`.trim();
}

async function getMoySkladPriceTypes(token) {
  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/context/companysettings/pricetype`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось загрузить типы цен из МойСклад.', data);
  }

  return (data || []).map((priceType) => ({
    id: priceType.id,
    name: priceType.name,
    href: priceType.meta?.href || ''
  })).filter((priceType) => priceType.href);
}

async function getCachedMoySkladPriceTypes(token, cacheKey = 'default') {
  const key = String(cacheKey || 'default');
  const cached = moySkladPriceTypesCache.get(key);
  if (cached && Date.now() - cached.createdAt < PRODUCT_PRICE_TYPES_CACHE_TTL_MS) {
    return cached.value;
  }
  const inflight = moySkladPriceTypesInflight.get(key);
  if (inflight) return inflight;

  const promise = getMoySkladPriceTypes(token).then((value) => {
    moySkladPriceTypesCache.set(key, { value, createdAt: Date.now() });
    trimMap(moySkladPriceTypesCache, 10);
    return value;
  }).finally(() => {
    moySkladPriceTypesInflight.delete(key);
  });
  moySkladPriceTypesInflight.set(key, promise);
  return promise;
}

async function updateAccountingPrices(input) {
  const changes = Array.isArray(input.changes) ? input.changes : [];
  const priceTypeHref = String(input.priceTypeHref || '').trim();
  if (!changes.length) throw httpError(400, 'Нет цен для сохранения.');
  if (changes.length > 200) throw httpError(400, 'За один раз можно изменить не более 200 товаров.');

  const token = requiredEnv('MOYSKLAD_TOKEN');
  const priceTypes = await getMoySkladPriceTypes(token);
  const priceType = priceTypes.find((item) => item.href === priceTypeHref);
  if (!priceType) throw httpError(400, 'Выбранный тип цены не найден в МойСклад.');

  const normalized = changes.map((change) => {
    const productId = String(change.productId || '').trim();
    const value = toMoney(change.value);
    if (!/^[0-9a-f-]{36}$/i.test(productId)) throw httpError(400, 'Некорректный идентификатор товара.');
    if (!Number.isFinite(value) || value < 0 || value > 1000000000) {
      throw httpError(400, 'Цена должна быть от 0 до 1 000 000 000.');
    }
    return { productId, value: roundMoney(value) };
  });

  const results = await mapWithConcurrency(normalized, 5, async (change) => {
    try {
      await updateMoySkladProductPrice(token, change, priceType);
      return { productId: change.productId, value: change.value, ok: true };
    } catch (error) {
      return { productId: change.productId, value: change.value, ok: false, error: error.message };
    }
  });

  return {
    updated: results.filter((item) => item.ok).length,
    failed: results.filter((item) => !item.ok).length,
    results
  };
}

async function updateMoySkladProductPrice(token, change, priceType) {
  const productUrl = `${MOYSKLAD_BASE_URL}/entity/product/${change.productId}`;
  const currentResponse = await moySkladFetch(productUrl, {
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/json;charset=utf-8' }
  });
  const product = await currentResponse.json().catch(() => null);
  if (!currentResponse.ok) {
    throw httpError(currentResponse.status, 'Не удалось загрузить товар перед обновлением.', product);
  }

  const salePrices = Array.isArray(product.salePrices) ? [...product.salePrices] : [];
  const existingIndex = salePrices.findIndex((price) => price.priceType?.meta?.href === priceType.href);
  const existing = existingIndex >= 0 ? salePrices[existingIndex] : null;
  const currency = existing?.currency || salePrices.find((price) => price.currency)?.currency;
  if (!currency?.meta?.href) {
    throw httpError(400, `У товара «${product.name || change.productId}» не найдена валюта цены.`);
  }

  const newPrice = {
    value: toMoySkladPrice(change.value),
    currency,
    priceType: meta(priceType.href, 'pricetype')
  };
  if (existingIndex >= 0) salePrices[existingIndex] = newPrice;
  else salePrices.push(newPrice);

  const updateResponse = await moySkladFetch(productUrl, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ salePrices })
  });
  const updated = await updateResponse.json().catch(() => null);
  if (!updateResponse.ok) {
    throw httpError(updateResponse.status, `Не удалось обновить цену товара «${product.name || change.productId}».`, updated);
  }
}

async function updateAccountingFormulaPrices(input) {
  const changes = Array.isArray(input.changes) ? input.changes : [];
  const priceType36Href = String(input.priceType36Href || '').trim();
  const priceType912Href = String(input.priceType912Href || '').trim();
  const priceTypeWholesaleHref = String(input.priceTypeWholesaleHref || '').trim();
  if (!changes.length) throw httpError(400, 'Нет цен для сохранения.');
  if (changes.length > 200) throw httpError(400, 'За один раз можно изменить не более 200 товаров.');
  const shouldSave36 = Boolean(priceType36Href);
  const shouldSave912 = Boolean(priceType912Href);

  const token = requiredEnv('MOYSKLAD_TOKEN');
  const priceTypes = await getMoySkladPriceTypes(token);
  const priceType36 = shouldSave36 ? priceTypes.find((item) => item.href === priceType36Href) : null;
  const priceType912 = shouldSave912 ? priceTypes.find((item) => item.href === priceType912Href) : null;
  const priceTypeWholesale = priceTypes.find((item) => item.href === priceTypeWholesaleHref);
  if (shouldSave36 && !priceType36) throw httpError(400, 'Тип цены 3-6 не найден в МойСклад.');
  if (shouldSave912 && !priceType912) throw httpError(400, 'Тип цены 9-12 не найден в МойСклад.');
  if (!priceTypeWholesale) throw httpError(400, 'Тип цены «Оптовая цена» не найден в МойСклад.');
  const defaultUsdCurrency = await getMoySkladCurrencyByIsoCode(token, 'USD').catch(() => null);

  const normalized = changes.map((change) => {
    const productId = String(change.productId || '').trim();
    const wholesaleCurrencyHref = String(change.wholesaleCurrencyHref || '').trim();
    const wholesalePrice = toMoney(change.wholesalePrice);
    const minPrice = toMoney(change.minPrice);
    const price36 = change.price36 === null || change.price36 === undefined ? null : toMoney(change.price36);
    const price912 = change.price912 === null || change.price912 === undefined ? null : toMoney(change.price912);
    if (!/^[0-9a-f-]{36}$/i.test(productId)) throw httpError(400, 'Некорректный идентификатор товара.');
    if (wholesaleCurrencyHref && !getMoySkladEntityIdFromInput(wholesaleCurrencyHref)) {
      throw httpError(400, 'Некорректная валюта оптовой цены.');
    }
    for (const value of [wholesalePrice, minPrice, price36, price912].filter((item) => item !== null)) {
      if (!Number.isFinite(value) || value < 0 || value > 1000000000) {
        throw httpError(400, 'Цена должна быть от 0 до 1 000 000 000.');
      }
    }
    return {
      productId,
      wholesaleCurrencyHref,
      wholesalePrice: roundMoney(wholesalePrice),
      minPrice: roundMoney(minPrice),
      price36: price36 === null ? null : roundMoney(price36),
      price912: price912 === null ? null : roundMoney(price912)
    };
  });

  const results = await mapWithConcurrency(normalized, 5, async (change) => {
    try {
      await updateMoySkladProductFormulaPrices(token, change, priceType36, priceType912, priceTypeWholesale, defaultUsdCurrency);
      return { productId: change.productId, wholesalePrice: change.wholesalePrice, minPrice: change.minPrice, price36: change.price36, price912: change.price912, ok: true };
    } catch (error) {
      return { productId: change.productId, wholesalePrice: change.wholesalePrice, minPrice: change.minPrice, price36: change.price36, price912: change.price912, ok: false, error: error.message };
    }
  });

  return {
    updated: results.filter((item) => item.ok).length,
    failed: results.filter((item) => !item.ok).length,
    results
  };
}

async function updateMoySkladProductFormulaPrices(token, change, priceType36, priceType912, priceTypeWholesale, defaultUsdCurrency) {
  const productUrl = `${MOYSKLAD_BASE_URL}/entity/product/${change.productId}`;
  const currentResponse = await moySkladFetch(productUrl, {
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/json;charset=utf-8' }
  });
  const product = await currentResponse.json().catch(() => null);
  if (!currentResponse.ok) {
    throw httpError(currentResponse.status, 'Не удалось загрузить товар перед обновлением.', product);
  }

  const salePrices = Array.isArray(product.salePrices) ? [...product.salePrices] : [];
  const preferredPriceTypeHrefs = [priceType36?.href, priceType912?.href].filter(Boolean);
  const kgsCurrency = findKgsPriceCurrency(product, salePrices, preferredPriceTypeHrefs);
  if (!kgsCurrency?.meta?.href) {
    throw httpError(400, `У товара «${product.name || change.productId}» не найдена валюта KGS для цен.`);
  }
  const requestedUsdCurrency = change.wholesaleCurrencyHref
    ? meta(change.wholesaleCurrencyHref, 'currency')
    : null;
  const usdCurrency = requestedUsdCurrency
    || findUsdPriceCurrency(product, salePrices, priceTypeWholesale.href)
    || defaultUsdCurrency;
  if (!usdCurrency?.meta?.href) {
    throw httpError(400, `У товара «${product.name || change.productId}» не найдена валюта USD для оптовой цены.`);
  }

  upsertSalePrice(salePrices, priceTypeWholesale, change.wholesalePrice, usdCurrency);
  if (priceType36 && change.price36 !== null && change.price36 !== undefined) {
    upsertSalePrice(salePrices, priceType36, change.price36, kgsCurrency);
  }
  if (priceType912 && change.price912 !== null && change.price912 !== undefined) {
    upsertSalePrice(salePrices, priceType912, change.price912, kgsCurrency);
  }

  const updateResponse = await moySkladFetch(productUrl, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      minPrice: { value: toMoySkladPrice(change.minPrice), currency: kgsCurrency },
      salePrices
    })
  });
  const updated = await updateResponse.json().catch(() => null);
  if (!updateResponse.ok) {
    throw httpError(updateResponse.status, `Не удалось обновить цены товара «${product.name || change.productId}».`, updated);
  }
  const savedWholesale = (updated?.salePrices || []).find((price) =>
    price.priceType?.meta?.href === priceTypeWholesale.href
  );
  const savedWholesaleValue = savedWholesale ? fromMoySkladPrice(savedWholesale.value) : null;
  if (savedWholesaleValue === null || Math.abs(savedWholesaleValue - change.wholesalePrice) > 0.001) {
    throw httpError(409, `МойСклад не подтвердил оптовую цену ${change.wholesalePrice} USD для товара «${product.name || change.productId}».`);
  }
}

function upsertSalePrice(salePrices, priceType, value, currency) {
  const nextPrice = {
    value: toMoySkladPrice(value),
    currency,
    priceType: meta(priceType.href, 'pricetype')
  };
  for (let index = salePrices.length - 1; index >= 0; index -= 1) {
    if (salePrices[index].priceType?.meta?.href === priceType.href) salePrices.splice(index, 1);
  }
  salePrices.push(nextPrice);
}

function findKgsPriceCurrency(product, salePrices, preferredPriceTypeHrefs = []) {
  const preferred = salePrices.find((price) =>
    preferredPriceTypeHrefs.includes(price.priceType?.meta?.href) && isKgsCurrency(price.currency)
  )?.currency;
  if (preferred) return preferred;
  if (isKgsCurrency(product.minPrice?.currency)) return product.minPrice.currency;
  return salePrices.find((price) => isKgsCurrency(price.currency))?.currency
    || product.minPrice?.currency
    || salePrices.find((price) => price.currency)?.currency;
}

function findUsdPriceCurrency(product, salePrices, wholesalePriceTypeHref) {
  const wholesaleCurrency = salePrices.find((price) =>
    price.priceType?.meta?.href === wholesalePriceTypeHref && isUsdCurrency(price.currency)
  )?.currency;
  if (wholesaleCurrency) return wholesaleCurrency;
  if (isUsdCurrency(product.buyPrice?.currency)) return product.buyPrice.currency;
  return salePrices.find((price) => isUsdCurrency(price.currency))?.currency || null;
}

async function getMoySkladCurrencyByIsoCode(token, isoCode) {
  const currencies = await getMoySkladCurrencies(token);
  return currencies.find((currency) =>
    String(currency.isoCode || '').toUpperCase() === String(isoCode || '').toUpperCase()
  ) || null;
}

async function getMoySkladCurrencies(token) {
  if (currenciesCache.value.length && Date.now() - currenciesCache.createdAt < 600_000) {
    return currenciesCache.value;
  }
  if (currenciesInflight) return currenciesInflight;

  currenciesInflight = loadMoySkladCurrencies(token).finally(() => {
    currenciesInflight = null;
  });
  return currenciesInflight;
}

async function loadMoySkladCurrencies(token) {
  const params = new URLSearchParams({ limit: '100' });
  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/currency?${params}`, {
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/json;charset=utf-8' }
  });
  const data = await response.json().catch(() => null);
  if (!response.ok) throw httpError(response.status, 'Не удалось загрузить валюты из МойСклад.', data);
  const rows = data?.rows || [];
  currenciesCache = { value: rows, createdAt: Date.now() };
  return rows;
}

function isKgsCurrency(currency) {
  const value = String([currency?.isoCode, currency?.name, currency?.fullName].filter(Boolean).join(' ')).toLowerCase();
  return value.includes('kgs') || value.includes('сом');
}

async function mapWithConcurrency(items, concurrency, worker) {
  const results = new Array(items.length);
  let nextIndex = 0;
  const runners = Array.from({ length: Math.min(concurrency, items.length) }, async () => {
    while (nextIndex < items.length) {
      const index = nextIndex++;
      results[index] = await worker(items[index], index);
    }
  });
  await Promise.all(runners);
  return results;
}

function getProductSearchQueries(search) {
  const query = String(search || '').trim();
  if (!query) {
    return [''];
  }

  const queries = [query];
  if (/^\d+$/.test(query)) {
    queries.push(`B${query}`, `b${query}`);
  }

  return [...new Set(queries)];
}

async function loadMoySkladProductRows(token, search) {
  const params = new URLSearchParams({ limit: String(PRODUCT_SEARCH_LIMIT) });
  if (search) {
    params.set('search', search);
  }

  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/product?${params}`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось загрузить товары из МойСклад.', data);
  }

  return data.rows || [];
}

function getProductBarcode(product) {
  const barcode = Array.isArray(product.barcodes) ? product.barcodes[0] : null;
  if (!barcode) {
    return '';
  }
  return barcode.ean13 || barcode.ean8 || barcode.code128 || barcode.gtin || '';
}

function getProductPrice(product) {
  const salePrices = Array.isArray(product.salePrices) ? product.salePrices : [];
  const preferredName = process.env.MOYSKLAD_PRODUCT_PRICE_NAME || '3-6';
  const salePrice = findPreferredProductSalePrice(salePrices, preferredName);

  if (!salePrice || !Number.isFinite(Number(salePrice.value))) {
    return 0;
  }
  return roundMoney(Number(salePrice.value) / 100);
}

function findPreferredProductSalePrice(salePrices, preferredName) {
  const preferred = normalizePriceTypeName(preferredName);
  const normalizedPrices = salePrices.map((price) => ({
    price,
    name: normalizePriceTypeName(price.priceType?.name || '')
  }));

  return normalizedPrices.find((item) => item.name && item.name === preferred)?.price
    || normalizedPrices.find((item) => item.name && (item.name.includes(preferred) || preferred.includes(item.name)))?.price
    || normalizedPrices.find((item) => item.name.includes('3-6') || item.name.includes('3 6'))?.price
    || null;
}

function findPreferredPriceType(priceTypes, preferredName) {
  const preferred = normalizePriceTypeName(preferredName);
  const normalizedTypes = (Array.isArray(priceTypes) ? priceTypes : []).map((priceType) => ({
    priceType,
    name: normalizePriceTypeName(priceType.name || '')
  }));

  return normalizedTypes.find((item) => item.name && item.name === preferred)?.priceType
    || normalizedTypes.find((item) => item.name && (item.name.includes(preferred) || preferred.includes(item.name)))?.priceType
    || normalizedTypes.find((item) => item.name.includes('3-6') || item.name.includes('3 6'))?.priceType
    || null;
}

function normalizePriceTypeName(value) {
  return String(value || '')
    .trim()
    .toLowerCase()
    .replace(/[–—]/g, '-')
    .replace(/\s+/g, ' ');
}

function getProductCost(product, currenciesByHref = new Map()) {
  const buyPrice = product.buyPrice;
  if (!buyPrice || !Number.isFinite(Number(buyPrice.value))) {
    return 0;
  }
  const value = Number(buyPrice.value) / 100;
  const currency = resolveAccountingCurrency(buyPrice.currency, currenciesByHref);
  return roundMoney(isUsdCurrency(currency) ? value * getReportUsdCostRate(1) : value);
}

function getReportPositionCostTotal(position, documentMoneyRate = 1, currenciesByHref = new Map()) {
  const buyPrice = position.assortment?.buyPrice;
  if (!buyPrice || !Number.isFinite(Number(buyPrice.value))) {
    return 0;
  }
  const value = Number(buyPrice.value) / 100;
  const currency = resolveAccountingCurrency(buyPrice.currency, currenciesByHref);
  const cost = shouldConvertReportBuyPriceToKgs(currency)
    ? value * getReportUsdCostRate(documentMoneyRate)
    : value;
  return roundMoney(cost * Number(position.quantity || 0));
}

function shouldConvertReportBuyPriceToKgs(currency) {
  return isUsdCurrency(currency);
}

function isUsdCurrency(currency) {
  const value = String([currency?.isoCode, currency?.name, currency?.fullName].filter(Boolean).join(' ')).toLowerCase();
  return value.includes('usd') || value.includes('доллар');
}

function getReportUsdCostRate(documentRate) {
  const documentRateNumber = Number(documentRate);
  if (Number.isFinite(documentRateNumber) && documentRateNumber > 10 && documentRateNumber < 200) {
    return documentRateNumber;
  }

  const envRate = Number(process.env.MOYSKLAD_REPORT_USD_RATE || process.env.MOYSKLAD_COST_USD_RATE || 88);
  return Number.isFinite(envRate) && envRate > 0 ? envRate : 88;
}

async function getMoySkladPaymentTypes() {
  const token = requiredEnv('MOYSKLAD_TOKEN');
  const customEntityId = requiredEnv('MOYSKLAD_PAYMENT_TYPE_CUSTOM_ENTITY_ID');
  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/customentity/${customEntityId}?limit=100`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось загрузить типы оплаты из МойСклад.', data);
  }

  return (data.rows || [])
    .map((item) => {
      const parsed = parsePaymentType(item.name);
      const rateFromComment = parseRateFromComment(item.description || item.comment || '');
      return {
        name: item.name,
        href: item.meta.href,
        comment: item.description || item.comment || '',
        provider: parsed.provider,
        months: parsed.months,
        rate: getPaymentRate(parsed.provider, parsed.months, rateFromComment)
      };
    })
    .sort(comparePaymentTypes);
}

function comparePaymentTypes(left, right) {
  return getPaymentSortWeight(left) - getPaymentSortWeight(right)
    || left.provider.localeCompare(right.provider, 'ru')
    || left.months - right.months
    || left.name.localeCompare(right.name, 'ru');
}

function getPaymentSortWeight(paymentType) {
  const name = String(paymentType?.name || '').toLowerCase();
  if (name.includes('налич') || name.includes('cash')) return 10;
  if (name.includes('долг')) return 20;
  if (name.includes('qr')) return 30;
  return 40;
}

async function getSalesReport(input) {
  const cacheKey = [input.dateFrom, input.dateTo, input.documentType || '', input.customerType || '', input.search || '', input.retailStoreHref || '', input.storeHref || ''].join('|');
  const cached = salesReportCache.get(cacheKey);
  if (cached && Date.now() - cached.createdAt < 60_000) return cached.value;
  if (salesReportInflight.has(cacheKey)) return salesReportInflight.get(cacheKey);

  const request = loadSalesReport(input)
    .then((report) => {
      salesReportCache.set(cacheKey, { value: report, createdAt: Date.now() });
      return report;
    })
    .finally(() => salesReportInflight.delete(cacheKey));
  salesReportInflight.set(cacheKey, request);
  return request;
}

async function getBankCommissionAnalytics(input) {
  const report = await getSalesReport(input);
  const paymentTypes = await getMoySkladPaymentTypes().catch(() => []);
  const paymentTypeMap = new Map(paymentTypes.map((item) => [normalizePaymentAnalyticsKey(item.name), item]));
  const bankFilter = normalizePaymentAnalyticsKey(input.bank);
  const paymentTypeFilter = normalizePaymentAnalyticsKey(input.paymentType);

  const allPayments = (report.rows || [])
    .flatMap((row) => extractBankCommissionPayments(row, paymentTypeMap))
    .filter((payment) => {
      if (bankFilter && normalizePaymentAnalyticsKey(payment.bankName) !== bankFilter) return false;
      if (paymentTypeFilter && normalizePaymentAnalyticsKey(payment.paymentType) !== paymentTypeFilter) return false;
      return true;
    })
    .sort((left, right) => new Date(right.moment) - new Date(left.moment));

  const totals = allPayments.reduce((sum, payment) => ({
    turnover: roundMoney(sum.turnover + payment.amount),
    commission: roundMoney(sum.commission + payment.commission),
    net: roundMoney(sum.net + payment.netAmount),
    count: sum.count + 1,
    withoutCommission: sum.withoutCommission + (payment.withoutCommission ? 1 : 0)
  }), { turnover: 0, commission: 0, net: 0, count: 0, withoutCommission: 0 });

  const banks = new Map();
  for (const payment of allPayments) {
    const key = payment.paymentType;
    const existing = banks.get(key) || {
      bankName: payment.bankName,
      paymentType: payment.paymentType,
      turnover: 0,
      commission: 0,
      netAmount: 0,
      paymentCount: 0,
      averageRate: 0,
      withoutCommissionCount: 0,
      payments: []
    };
    existing.turnover = roundMoney(existing.turnover + payment.amount);
    existing.commission = roundMoney(existing.commission + payment.commission);
    existing.netAmount = roundMoney(existing.netAmount + payment.netAmount);
    existing.paymentCount += 1;
    existing.withoutCommissionCount += payment.withoutCommission ? 1 : 0;
    existing.payments.push(payment);
    banks.set(key, existing);
  }

  const rows = [...banks.values()]
    .map((bank) => {
      const averageRate = bank.turnover > 0 ? roundMoney(bank.commission / bank.turnover * 100) : 0;
      const shareOfTotalCommission = totals.commission > 0 ? roundMoney(bank.commission / totals.commission * 100) : 0;
      return {
        bankName: bank.bankName,
        paymentType: bank.paymentType,
        turnover: bank.turnover,
        commission: bank.commission,
        netAmount: bank.netAmount,
        paymentCount: bank.paymentCount,
        averageRate,
        shareOfTotalCommission,
        withoutCommissionCount: bank.withoutCommissionCount,
        payments: bank.payments
      };
    })
    .sort((left, right) =>
      right.commission - left.commission
      || right.turnover - left.turnover
      || right.paymentCount - left.paymentCount
      || left.paymentType.localeCompare(right.paymentType, 'ru')
    );

  const topCommissionBank = rows[0] || null;
  const averageRate = totals.turnover > 0 ? roundMoney(totals.commission / totals.turnover * 100) : 0;
  const bankOptions = [...new Set(allPayments.map((payment) => payment.bankName).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'ru'));
  const paymentTypeOptions = [...new Set(allPayments.map((payment) => payment.paymentType).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'ru'));

  return {
    filters: {
      dateFrom: input.dateFrom,
      dateTo: input.dateTo,
      bank: input.bank || '',
      paymentType: input.paymentType || ''
    },
    totals: {
      turnover: totals.turnover,
      commission: totals.commission,
      netAmount: totals.net,
      paymentCount: totals.count,
      averageRate,
      withoutCommissionCount: totals.withoutCommission,
      topCommissionBank: topCommissionBank ? {
        bankName: topCommissionBank.bankName,
        paymentType: topCommissionBank.paymentType,
        commission: topCommissionBank.commission
      } : null
    },
    bankOptions,
    paymentTypeOptions,
    rows,
    payments: allPayments
  };
}

async function loadReconciliationDebtorsChunk(input = {}) {
  const token = requiredEnv('MOYSKLAD_TOKEN');
  const limit = Math.max(20, Math.min(100, Number(input.limit) || 60));
  const offset = Math.max(0, Number(input.offset) || 0);
  const search = normalizeTextSearch(input.search);
  const customerType = String(input.customerType || '').trim();
  const [retailRows, demandRows] = await Promise.all([
    loadReconciliationDocuments(token, 'retaildemand', { limit, maxRows: limit, offset }),
    loadReconciliationDocuments(token, 'demand', { limit, maxRows: limit, offset })
  ]);
  const rawDocuments = [...retailRows, ...demandRows]
    .map(mapReconciliationDocument)
    .filter((document) => document.customerHref && document.debt > 0)
    .filter((document) => {
      if (customerType && document.customerType !== customerType) return false;
      if (!search) return true;
      return normalizeTextSearch([document.customerName, document.customerPhone, document.customerInn, document.name].join(' ')).includes(search);
    });
  const debtorsByHref = new Map();
  for (const document of rawDocuments) {
    const existing = debtorsByHref.get(document.customerHref) || {
      id: document.customerId,
      href: document.customerHref,
      name: document.customerName || 'Без имени',
      customerType: document.customerType,
      customerTypeLabel: document.customerTypeLabel,
      phone: document.customerPhone,
      inn: document.customerInn,
      actualAddress: document.customerAddress,
      debt: 0,
      amount: 0,
      paid: 0,
      documentCount: 0,
      lastMoment: '',
      lastDocumentName: ''
    };
    existing.debt = roundMoney(existing.debt + document.debt);
    existing.amount = roundMoney(existing.amount + document.amount);
    existing.paid = roundMoney(existing.paid + document.paid);
    existing.documentCount += 1;
    if (!existing.lastMoment || new Date(document.moment) > new Date(existing.lastMoment)) {
      existing.lastMoment = document.moment;
      existing.lastDocumentName = document.name;
    }
    debtorsByHref.set(document.customerHref, existing);
  }
  const debtors = [...debtorsByHref.values()].sort((left, right) => right.debt - left.debt || String(left.name).localeCompare(String(right.name), 'ru'));
  const totals = debtors.reduce((sum, debtor) => ({
    debt: roundMoney(sum.debt + debtor.debt),
    amount: roundMoney(sum.amount + debtor.amount),
    paid: roundMoney(sum.paid + debtor.paid),
    debtors: sum.debtors + 1,
    documents: sum.documents + debtor.documentCount
  }), { debt: 0, amount: 0, paid: 0, debtors: 0, documents: 0 });
  const hasMore = retailRows.length >= limit || demandRows.length >= limit;
  return {
    loadedAt: new Date().toISOString(),
    truncated: hasMore,
    partial: true,
    totals,
    debtors,
    page: { offset, limit, nextOffset: offset + limit, hasMore },
    filters: { search: input.search || '', customerType, limit, offset }
  };
}

async function getReconciliationDebtors(input = {}) {
  if (input.offset !== undefined && input.offset !== null && String(input.offset) !== '') {
    return loadReconciliationDebtorsChunk(input);
  }
  const limit = Math.max(20, Math.min(500, Number(input.limit) || 200));
  const search = normalizeTextSearch(input.search);
  const customerType = String(input.customerType || '').trim();
  const cacheKey = 'all-debtors';
  const cached = reconciliationDebtorsCache.get(cacheKey);
  let payload = cached && Date.now() - cached.createdAt < RECONCILIATION_CACHE_TTL_MS ? cached.value : null;
  if (!payload) {
    payload = await loadReconciliationDebtors();
    reconciliationDebtorsCache.set(cacheKey, { value: payload, createdAt: Date.now() });
  }

  const debtors = payload.debtors
    .filter((debtor) => {
      if (customerType && debtor.customerType !== customerType) return false;
      if (!search) return true;
      return normalizeTextSearch(`${debtor.name} ${debtor.phone} ${debtor.inn}`).includes(search);
    })
    .slice(0, limit);

  return { ...payload, debtors, filters: { search: input.search || '', customerType, limit } };
}

async function loadReconciliationDebtors() {
  const token = requiredEnv('MOYSKLAD_TOKEN');
  const [retailRows, demandRows] = await Promise.all([
    loadReconciliationDocuments(token, 'retaildemand'),
    loadReconciliationDocuments(token, 'demand')
  ]);
  const rawDocuments = [...retailRows, ...demandRows]
    .map(mapReconciliationDocument)
    .filter((document) => document.customerHref && document.debt > 0);
  const agentHrefs = [...new Set(rawDocuments.map((document) => document.customerHref))];
  const documentsByAgent = new Map();
  for (const document of rawDocuments) {
    const list = documentsByAgent.get(document.customerHref) || [];
    list.push(document);
    documentsByAgent.set(document.customerHref, list);
  }
  const adjustedDocumentGroups = await mapWithConcurrency(agentHrefs, 4, async (agentHref) => {
    const payments = await loadReconciliationPayments(token, agentHref, { limit: 100, maxRows: 500 }).catch(() => []);
    return applyReconciliationPayments(documentsByAgent.get(agentHref) || [], payments);
  });
  const documents = adjustedDocumentGroups.flat();
  const debtorsByHref = new Map();

  for (const document of documents) {
    const existing = debtorsByHref.get(document.customerHref) || {
      id: document.customerId,
      href: document.customerHref,
      name: document.customerName || 'Без имени',
      customerType: document.customerType,
      customerTypeLabel: document.customerTypeLabel,
      phone: document.customerPhone,
      inn: document.customerInn,
      actualAddress: document.customerAddress,
      debt: 0,
      amount: 0,
      paid: 0,
      documentCount: 0,
      lastMoment: '',
      lastDocumentName: ''
    };
    existing.debt = roundMoney(existing.debt + document.debt);
    existing.amount = roundMoney(existing.amount + document.amount);
    existing.paid = roundMoney(existing.paid + document.paid);
    existing.documentCount += 1;
    if (!existing.lastMoment || new Date(document.moment) > new Date(existing.lastMoment)) {
      existing.lastMoment = document.moment;
      existing.lastDocumentName = document.name;
    }
    debtorsByHref.set(document.customerHref, existing);
  }

  const debtors = [...debtorsByHref.values()]
    .sort((left, right) => right.debt - left.debt || String(left.name).localeCompare(String(right.name), 'ru'));
  const totals = debtors.reduce((sum, debtor) => ({
    debt: roundMoney(sum.debt + debtor.debt),
    amount: roundMoney(sum.amount + debtor.amount),
    paid: roundMoney(sum.paid + debtor.paid),
    debtors: sum.debtors + 1,
    documents: sum.documents + debtor.documentCount
  }), { debt: 0, amount: 0, paid: 0, debtors: 0, documents: 0 });

  return {
    loadedAt: new Date().toISOString(),
    truncated: retailRows.length >= RECONCILIATION_DOCUMENT_LIMIT || demandRows.length >= RECONCILIATION_DOCUMENT_LIMIT,
    totals,
    debtors
  };
}

async function getReconciliationDebtorDetails(counterpartyId) {
  const token = requiredEnv('MOYSKLAD_TOKEN');
  const agentHref = `${MOYSKLAD_BASE_URL}/entity/counterparty/${encodeURIComponent(counterpartyId)}`;
  const [retailRows, demandRows, payments] = await Promise.all([
    loadReconciliationDocuments(token, 'retaildemand', { agentHref, limit: 100, maxRows: 500 }),
    loadReconciliationDocuments(token, 'demand', { agentHref, limit: 100, maxRows: 500 }),
    loadReconciliationPayments(token, agentHref).catch(() => [])
  ]);
  const documentsBeforePayments = [...retailRows, ...demandRows]
    .map(mapReconciliationDocument)
    .filter((document) => document.customerHref && document.debt > 0)
    .sort((left, right) => new Date(right.moment) - new Date(left.moment));
  const documents = applyReconciliationPayments(documentsBeforePayments, payments);
  const act = buildReconciliationAct(documentsBeforePayments, payments, documentsBeforePayments[0]?.customerName || 'Контрагент');
  const debtorSource = documents[0] || documentsBeforePayments[0];
  const debtor = debtorSource
    ? {
        id: debtorSource.customerId,
        href: debtorSource.customerHref,
        name: debtorSource.customerName,
        customerType: debtorSource.customerType,
        customerTypeLabel: debtorSource.customerTypeLabel,
        phone: debtorSource.customerPhone,
        inn: debtorSource.customerInn,
        actualAddress: debtorSource.customerAddress
      }
    : { id: counterpartyId, href: agentHref, name: 'Должник', customerType: '', customerTypeLabel: 'Контрагент' };
  const totals = documents.reduce((sum, document) => ({
    debt: roundMoney(sum.debt + document.debt),
    amount: roundMoney(sum.amount + document.amount),
    paid: roundMoney(sum.paid + document.paid),
    documents: sum.documents + 1
  }), { debt: 0, amount: 0, paid: 0, documents: 0 });

  return { debtor, totals, documents, payments: payments.slice(0, 100), act };
}

async function loadReconciliationDocuments(token, documentType, options = {}) {
  const rows = [];
  let offset = Math.max(0, Number(options.offset) || 0);
  const limit = Math.min(100, Math.max(1, Number(options.limit) || 100));
  const maxRows = Math.min(RECONCILIATION_DOCUMENT_LIMIT, Math.max(limit, Number(options.maxRows) || RECONCILIATION_DOCUMENT_LIMIT));

  while (offset < maxRows) {
    const filters = [];
    if (options.agentHref) filters.push(`agent=${options.agentHref}`);
    const params = new URLSearchParams({
      limit: String(limit),
      offset: String(offset),
      order: 'moment,desc',
      expand: 'agent,organization,store,retailStore,rate.currency'
    });
    if (filters.length) params.set('filter', filters.join(';'));

    const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/${documentType}?${params}`, {
      headers: { Authorization: `Bearer ${token}`, Accept: 'application/json;charset=utf-8' }
    });
    const data = await response.json().catch(() => null);
    if (!response.ok) {
      throw httpError(response.status, `Не удалось загрузить долги ${getDocumentTypeLabel(documentType).toLowerCase()} из МойСклад.`, data);
    }
    const pageRows = Array.isArray(data?.rows) ? data.rows : [];
    rows.push(...pageRows.map((row) => ({ ...row, reportDocumentType: documentType })));
    if (pageRows.length < limit) break;
    offset += limit;
  }

  return rows;
}

async function loadReconciliationPayments(token, agentHref = '', options = {}) {
  const rows = [];
  let offset = 0;
  const limit = Math.min(100, Math.max(1, Number(options.limit) || 100));
  const maxRows = Math.min(RECONCILIATION_DOCUMENT_LIMIT, Math.max(limit, Number(options.maxRows) || limit));

  while (offset < maxRows) {
    const params = new URLSearchParams({
      limit: String(limit),
      offset: String(offset),
      order: 'moment,desc',
      expand: 'agent,organization,operations'
    });
    if (agentHref) params.set('filter', `agent=${agentHref}`);

    const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/paymentin?${params}`, {
      headers: { Authorization: `Bearer ${token}`, Accept: 'application/json;charset=utf-8' }
    });
    const data = await response.json().catch(() => null);
    if (!response.ok) throw httpError(response.status, 'Не удалось загрузить оплаты должника из МойСклад.', data);

    const pageRows = Array.isArray(data?.rows) ? data.rows : [];
    rows.push(...pageRows.map(mapReconciliationPayment));
    if (pageRows.length < limit) break;
    offset += limit;
  }

  return rows;
}

function mapReconciliationPayment(payment) {
  return {
    id: payment.id,
    name: payment.name || '',
    moment: payment.moment || payment.created || '',
    amount: fromMoySkladPrice(payment.sum),
    organizationName: payment.organization?.name || '',
    agentHref: payment.agent?.meta?.href || '',
    description: payment.description || '',
    operationIds: getPaymentOperationIds(payment),
    operationNames: getPaymentOperationNames(payment),
    webUrl: getMoySkladWebUrl('paymentin', payment.id)
  };
}

function applyReconciliationPayments(documents, payments) {
  const result = documents
    .map((document) => ({
      ...document,
      appliedPayments: [],
      originalDebt: document.debt
    }))
    .sort((left, right) => new Date(left.moment) - new Date(right.moment));

  for (const payment of payments) {
    let remaining = roundMoney(payment.amount || 0);
    if (remaining <= 0) continue;

    for (const document of result.filter((item) => item.debt > 0)) {
      remaining = applyPaymentToReconciliationDocument(document, payment, remaining);
      if (remaining <= 0) break;
    }
  }

  return result
    .filter((document) => document.debt > 0)
    .sort((left, right) => new Date(right.moment) - new Date(left.moment));
}

function applyPaymentToReconciliationDocument(document, payment, remaining) {
  const applied = roundMoney(Math.min(document.debt, remaining));
  if (applied <= 0) return remaining;
  document.debt = roundMoney(document.debt - applied);
  document.paid = roundMoney(document.paid + applied);
  document.appliedPayments.push({
    id: payment.id,
    name: payment.name,
    amount: applied,
    moment: payment.moment
  });
  return roundMoney(remaining - applied);
}

function buildReconciliationAct(documents, payments, customerName) {
  const documentRows = documents.map((document) => ({
    id: `doc:${document.type}:${document.id}`,
    moment: document.moment,
    operation: `${document.typeLabel} (${formatActDateShort(document.moment)}, № ${document.name || ''})`,
    debit: roundMoney(document.amount || 0),
    credit: 0
  }));
  const paymentRows = payments.map((payment) => ({
    id: `payment:${payment.id}`,
    moment: payment.moment,
    operation: `Входящий платёж (${formatActDateShort(payment.moment)}, № ${payment.name || ''})`,
    debit: 0,
    credit: roundMoney(payment.amount || 0)
  }));
  const rows = [...documentRows, ...paymentRows]
    .sort((left, right) => new Date(left.moment) - new Date(right.moment));
  const totals = rows.reduce((sum, row) => ({
    debit: roundMoney(sum.debit + row.debit),
    credit: roundMoney(sum.credit + row.credit)
  }), { debit: 0, credit: 0 });
  const saldo = roundMoney(totals.debit - totals.credit);
  const lastMoment = rows[rows.length - 1]?.moment || new Date().toISOString();

  return {
    customerName,
    date: formatActDateShort(lastMoment),
    rows,
    totals: {
      ...totals,
      saldo
    }
  };
}

function formatActDateShort(value) {
  const date = value ? new Date(value) : new Date();
  if (Number.isNaN(date.getTime())) return '';
  return new Intl.DateTimeFormat('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: '2-digit'
  }).format(date);
}

function getPaymentOperationIds(payment) {
  return getPaymentOperationEntries(payment)
    .map((operation) => getIdFromHref(operation.meta?.href || operation.href || ''))
    .filter(Boolean);
}

function getPaymentOperationNames(payment) {
  return getPaymentOperationEntries(payment)
    .map((operation) => operation.name || operation.meta?.name || '')
    .filter(Boolean);
}

function getPaymentOperationEntries(payment) {
  if (Array.isArray(payment.operations)) return payment.operations;
  if (Array.isArray(payment.operations?.rows)) return payment.operations.rows;
  return [];
}

function normalizeDocumentNumber(value) {
  const text = String(value || '').trim().toLowerCase();
  const digits = text.match(/\d+/g)?.join('') || '';
  if (!digits) return text;
  return digits.replace(/^0+/, '') || '0';
}

function mapReconciliationDocument(document) {
  const documentType = document.reportDocumentType || document.meta?.type || '';
  const rate = getReportDocumentMoneyRate(document);
  const amount = fromReportDocumentMoney(document.sum, rate);
  const paidAttribute = getReportNumberAttribute(document, 'PAID', documentType);
  const unpaidAttribute = getReportNumberAttribute(document, 'UNPAID', documentType);
  const linkedPaid = fromReportDocumentMoney(document.payedSum, rate);
  const paid = documentType === 'retaildemand'
    ? paidAttribute !== null
      ? roundMoney(paidAttribute * rate)
      : roundMoney(fromReportDocumentMoney(document.cashSum, rate) + fromReportDocumentMoney(document.noCashSum, rate))
    : roundMoney(Math.max(linkedPaid, paidAttribute !== null ? paidAttribute * rate : 0));
  const debt = unpaidAttribute !== null
    ? roundMoney(Math.max(0, unpaidAttribute * rate))
    : roundMoney(Math.max(0, amount - paid));
  const agent = document.agent || {};
  const agentHref = agent.meta?.href || '';
  return {
    id: document.id,
    name: document.name || '',
    type: documentType,
    typeLabel: getDocumentTypeLabel(documentType),
    moment: document.moment || document.created || '',
    organizationName: document.organization?.name || '',
    storeName: document.retailStore?.name || document.store?.name || '',
    amount,
    paid,
    debt,
    paymentType: getReportPaymentType(document, documentType),
    comment: document.description || '',
    customerId: agent.id || getIdFromHref(agentHref),
    customerHref: agentHref,
    customerName: agent.name || '',
    customerType: normalizeCounterpartyType(agent),
    customerTypeLabel: getCounterpartyTypeLabel(agent),
    customerPhone: agent.phone || '',
    customerInn: agent.inn || '',
    customerAddress: agent.actualAddress || agent.legalAddress || '',
    webUrl: getMoySkladWebUrl(documentType, document.id)
  };
}

function normalizeCounterpartyType(counterparty) {
  const value = String([
    counterparty?.companyType,
    counterparty?.legalTitle,
    counterparty?.name
  ].filter(Boolean).join(' ')).toLowerCase();
  if (value.includes('entrepreneur') || value.includes('индивидуальный предприниматель') || /(^|[\s"«])ип([\s."»]|$)/i.test(value)) return 'entrepreneur';
  if (value.includes('individual') || value.includes('person') || value.includes('физ')) return 'individual';
  if (value.includes('legal') || value.includes('company') || value.includes('юр')) return 'legal';
  return counterparty?.inn ? 'legal' : 'individual';
}

function getCounterpartyTypeLabel(counterparty) {
  const type = normalizeCounterpartyType(counterparty);
  if (type === 'entrepreneur') return 'ИП';
  return type === 'legal' ? 'Юрлицо' : 'Физлицо';
}

function normalizeTextSearch(value) {
  return String(value || '').trim().toLocaleLowerCase('ru-RU').replace(/\s+/g, ' ');
}

function normalizeReportSearch(value) {
  return String(value || '').toLowerCase().replace(/ё/g, 'е').replace(/[^a-zа-я0-9]+/giu, ' ').trim();
}

function reportRowMatchesSearch(row, search) {
  const query = normalizeReportSearch(search);
  if (!query) return true;
  const products = Array.isArray(row.products) ? row.products.map((product) => [product.code, product.name, product.categoryName, product.categoryPath].join(' ')).join(' ') : '';
  const haystack = normalizeReportSearch([row.name, row.customerName, row.customerPhone, row.customerInn, row.customerAddress, row.organizationName, row.employeeName, row.paymentType, row.comment, row.productText, products].join(' '));
  return haystack.includes(query);
}

function reportCustomerKey(row) {
  const directKey = String(row.customerHref || row.customerId || '').trim();
  if (directKey) return directKey;
  return normalizeReportSearch([row.customerName, row.customerInn, row.customerPhone].join(' '));
}

function normalizeReportCustomerTypeFilter(value) {
  const type = String(value || '').trim();
  if (type === 'person') return 'individual';
  return ['legal', 'entrepreneur', 'individual'].includes(type) ? type : '';
}

async function loadSalesReport(input) {
  const token = requiredEnv('MOYSKLAD_TOKEN');
  const dateFrom = normalizeReportDate(input.dateFrom, 'from');
  const dateTo = normalizeReportDate(input.dateTo, 'to');
  const retailStoreHref = String(input.retailStoreHref || '').trim();
  const storeHref = String(input.storeHref || '').trim();
  const allowedDocumentTypes = ['retaildemand', 'demand', 'retailsalesreturn', 'salesreturn'];
  const requestedDocumentType = String(input.documentType || '').trim();
  const documentTypes = allowedDocumentTypes.includes(requestedDocumentType) ? [requestedDocumentType] : allowedDocumentTypes;
  const customerTypeFilter = normalizeReportCustomerTypeFilter(input.customerType);
  const search = String(input.search || '').trim();

  const [documentGroups, currencies] = await Promise.all([
    Promise.all(documentTypes.map((documentType) => loadMoySkladReportDocuments(token, documentType, dateFrom, dateTo, { retailStoreHref, storeHref }))),
    getMoySkladCurrencies(token).catch(() => [])
  ]);
  const currenciesByHref = new Map(currencies.map((currency) => [currency.meta?.href, currency]));

  const mappedRows = documentGroups.flat()
    .map((document) => mapReportDocument(document, currenciesByHref))
    .filter((row) => !customerTypeFilter || row.customerType === customerTypeFilter)
    .sort((left, right) => new Date(right.moment) - new Date(left.moment));
  const firstMatchedCustomer = search ? mappedRows.find((row) => reportRowMatchesSearch(row, search)) : null;
  const matchedCustomerKey = firstMatchedCustomer ? reportCustomerKey(firstMatchedCustomer) : '';
  const rows = search
    ? mappedRows.filter((row) => matchedCustomerKey && reportCustomerKey(row) === matchedCustomerKey)
    : mappedRows;

  const totals = rows.reduce((sum, row) => ({
    documents: sum.documents + 1,
    amount: roundMoney(sum.amount + row.amount),
    paid: roundMoney(sum.paid + row.paid),
    unpaid: roundMoney(sum.unpaid + row.unpaid),
    commission: roundMoney(sum.commission + row.commission),
    netProfit: roundMoney(sum.netProfit + row.netProfit)
  }), {
    documents: 0,
    amount: 0,
    paid: 0,
    unpaid: 0,
    commission: 0,
    netProfit: 0
  });

  return {
    dateFrom: input.dateFrom,
    dateTo: input.dateTo,
    rows,
    totals
  };
}

function extractBankCommissionPayments(row, paymentTypeMap) {
  const parsedLines = parseBankPaymentLines(row.comment || '');
  const bankLines = parsedLines.filter((line) => isBankCommissionPaymentName(line.name));
  const effectiveEntries = bankLines.length
    ? bankLines
    : isBankCommissionPaymentName(row.paymentType)
      ? [{ name: row.paymentType, amount: roundMoney(row.amount) }]
      : [];

  if (!effectiveEntries.length) return [];

  const entries = effectiveEntries
    .map((entry, index) => {
      const typeMeta = paymentTypeMap.get(normalizePaymentAnalyticsKey(entry.name));
      const rate = Number(typeMeta?.rate || 0);
      const bankName = String(typeMeta?.provider || parsePaymentType(entry.name).provider || entry.name || '').trim();
      const calculatedCommission = rate > 0 ? roundMoney(entry.amount * rate / 100) : 0;
      return {
        id: `${row.id}:${index}:${normalizePaymentAnalyticsKey(entry.name)}`,
        saleId: row.id,
        saleName: row.name,
        moment: row.moment,
        customerName: row.customerName || '',
        paymentType: entry.name,
        bankName: bankName || entry.name,
        amount: roundMoney(entry.amount),
        rate,
        calculatedCommission,
        commission: 0,
        netAmount: 0,
        withoutCommission: false,
        storeName: row.storeName || '',
        type: row.type,
        webUrl: row.webUrl || ''
      };
    })
    .filter((entry) => entry.amount > 0);

  if (!entries.length) return [];

  const knownCommissionTotal = roundMoney(Number(row.commission || 0));
  const calculatedTotal = roundMoney(entries.reduce((sum, entry) => sum + entry.calculatedCommission, 0));
  const amountTotal = roundMoney(entries.reduce((sum, entry) => sum + entry.amount, 0));

  for (const entry of entries) {
    if (knownCommissionTotal > 0) {
      if (calculatedTotal > 0) {
        entry.commission = roundMoney(knownCommissionTotal * (entry.calculatedCommission / calculatedTotal));
      } else if (amountTotal > 0) {
        entry.commission = roundMoney(knownCommissionTotal * (entry.amount / amountTotal));
      }
    } else {
      entry.commission = entry.calculatedCommission;
    }
  }

  if (entries.length > 1) {
    const diff = roundMoney(knownCommissionTotal - entries.reduce((sum, entry) => sum + entry.commission, 0));
    if (Math.abs(diff) > 0) {
      entries[0].commission = roundMoney(entries[0].commission + diff);
    }
  }

  for (const entry of entries) {
    entry.withoutCommission = entry.commission <= 0;
    entry.netAmount = roundMoney(entry.amount - entry.commission);
  }

  return entries;
}

function parseBankPaymentLines(description) {
  return String(description || '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const match = line.match(/^([^:]+):\s*(-?\d[\d\s.,]*)\s*сом/i);
      if (!match) return null;
      const amount = Number(String(match[2]).replace(/\s/g, '').replace(',', '.'));
      if (!Number.isFinite(amount)) return null;
      return {
        name: match[1].replace(/\.+$/, '').trim(),
        amount: roundMoney(amount)
      };
    })
    .filter(Boolean);
}

function normalizePaymentAnalyticsKey(value) {
  return String(value || '').trim().toLowerCase().replace(/\s+/g, ' ');
}

function isBankCommissionPaymentName(name) {
  const value = normalizePaymentAnalyticsKey(name);
  if (!value) return false;
  if (value.includes('налич')) return false;
  if (value.includes('долг')) return false;
  if (value.includes('не оплачено')) return false;
  if (value.includes('бонус')) return false;
  return /qr|банк|mbank|m\+|мбанк|мплюс|мбизнес|optima|оптима|bakai|бакай|o!|элькарт|visa|mastercard|терминал|расчетн|перевод|карт/i.test(value);
}

async function loadMoySkladReportDocuments(token, documentType, dateFrom, dateTo, options = {}) {
  const rows = [];
  let offset = 0;
  const limit = 100;

  while (offset < 1000) {
    const filters = [
      `moment>=${dateFrom}`,
      `moment<=${dateTo}`
    ];
    if ((documentType === 'retaildemand' || documentType === 'retailsalesreturn') && options.retailStoreHref) {
      filters.push(`retailStore=${options.retailStoreHref}`);
    }
    if ((documentType === 'demand' || documentType === 'salesreturn') && options.storeHref) {
      filters.push(`store=${options.storeHref}`);
    }

    const params = new URLSearchParams({
      limit: String(limit),
      offset: String(offset),
      order: 'moment,desc',
      filter: filters.join(';'),
      expand: reportCurrencyExpandSupported
        ? 'agent,organization,store,retailStore,retailShift,positions,positions.assortment,rate.currency'
        : 'agent,organization,store,retailStore,retailShift,positions,positions.assortment'
    });

    const data = await loadMoySkladReportPage(token, documentType, params);

    rows.push(...(data.rows || []).map((row) => ({ ...row, reportDocumentType: documentType })));
    if (!data.rows || data.rows.length < limit) {
      break;
    }
    offset += limit;
  }

  return rows;
}

async function loadMoySkladReportPage(token, documentType, params) {
  const headers = {
    Authorization: `Bearer ${token}`,
    Accept: 'application/json;charset=utf-8'
  };
  const url = `${MOYSKLAD_BASE_URL}/entity/${documentType}?${params}`;

  try {
    const response = await moySkladFetch(url, { headers });
    const data = await response.json().catch(() => null);
    if (response.ok) return data;

    if (String(params.get('expand') || '').includes('rate.currency')) {
      return loadMoySkladReportPageWithoutCurrency(token, documentType, params, headers, response.status, data);
    }
    throw httpError(response.status, `Не удалось загрузить отчет ${getDocumentTypeLabel(documentType)} из МойСклад.`, data);
  } catch (error) {
    if (!String(params.get('expand') || '').includes('rate.currency')) {
      throw error;
    }
    return loadMoySkladReportPageWithoutCurrency(token, documentType, params, headers, error.status, error.details);
  }
}

async function loadMoySkladReportPageWithoutCurrency(token, documentType, params, headers, originalStatus, originalData) {
  const fallbackParams = new URLSearchParams(params);
  fallbackParams.set('expand', 'agent,organization,store,retailStore,retailShift,positions,positions.assortment');
  const fallbackUrl = `${MOYSKLAD_BASE_URL}/entity/${documentType}?${fallbackParams}`;
  const fallbackResponse = await moySkladFetch(fallbackUrl, { headers });
  const fallbackData = await fallbackResponse.json().catch(() => null);
  if (fallbackResponse.ok) {
    reportCurrencyExpandSupported = false;
    return fallbackData;
  }
  throw httpError(
    fallbackResponse.status || originalStatus || 500,
    `Не удалось загрузить отчет ${getDocumentTypeLabel(documentType)} из МойСклад.`,
    fallbackData || originalData
  );
}

function mapReportDocument(document, currenciesByHref = new Map()) {
  const documentType = document.reportDocumentType || document.meta?.type || '';
  const positions = Array.isArray(document.positions?.rows) ? document.positions.rows : [];
  const moneyRate = getReportDocumentMoneyRate(document, currenciesByHref);
  const amount = fromReportDocumentMoney(document.sum, moneyRate);
  const isReturnDocument = documentType === 'retailsalesreturn' || documentType === 'salesreturn';
  const paidAttribute = getReportNumberAttribute(document, 'PAID', documentType);
  const unpaidAttribute = getReportNumberAttribute(document, 'UNPAID', documentType);
  const linkedPaid = fromReportDocumentMoney(document.payedSum, moneyRate);
  const paid = isReturnDocument
    ? amount
    : documentType === 'demand'
    ? roundMoney(Math.max(linkedPaid, paidAttribute !== null ? paidAttribute * moneyRate : 0))
    : paidAttribute !== null
      ? roundMoney(paidAttribute * moneyRate)
      : documentType === 'retaildemand'
      ? roundMoney(fromReportDocumentMoney(document.cashSum, moneyRate) + fromReportDocumentMoney(document.noCashSum, moneyRate))
      : fromReportDocumentMoney(document.payedSum, moneyRate);
  const unpaid = isReturnDocument
    ? 0
    : documentType === 'demand'
    ? roundMoney(Math.max(0, amount - paid))
    : unpaidAttribute !== null
    ? roundMoney(unpaidAttribute * moneyRate)
    : roundMoney(Math.max(0, amount - paid));
  const costTotal = roundMoney(positions.reduce((sum, position) =>
    sum + getReportPositionCostTotal(position, moneyRate, currenciesByHref), 0));
  const commission = roundMoney(getReportMoneyFromTextAttribute(document, 'COMMISSION', documentType) * moneyRate);
  const calculatedNetProfit = costTotal > 0 ? roundMoney(amount - commission - costTotal) : null;

  return {
    id: document.id,
    name: document.name || '',
    type: documentType,
    typeLabel: getDocumentTypeLabel(documentType),
    moment: document.moment || document.created || '',
    storeName: document.retailStore?.name || document.store?.name || '',
    organizationName: document.organization?.name || '',
    customerId: document.agent?.id || getIdFromHref(document.agent?.meta?.href || ''),
    customerHref: document.agent?.meta?.href || '',
    customerName: document.agent?.name || '',
    customerType: normalizeCounterpartyType(document.agent),
    customerTypeLabel: getCounterpartyTypeLabel(document.agent),
    customerInn: document.agent?.inn || '',
    customerPhone: getReportPhone(document),
    customerAddress: getReportAddress(document),
    webUrl: getMoySkladWebUrl(documentType, document.id),
    paymentType: getReportPaymentType(document, documentType),
    employeeName: getReportTextAttribute(document, 'EMPLOYEE', documentType),
    employeeHref: getReportAttributeObjectHref(document, 'EMPLOYEE', documentType),
    products: positions.map((position, index) => ({
      index,
      code: position.assortment?.code || '',
      name: position.assortment?.name || position.name || 'Товар',
      categoryName: position.assortment?.productFolder?.name || '',
      categoryPath: position.assortment?.productFolder?.pathName || '',
      quantity: Number(position.quantity || 0),
      price: fromReportDocumentMoney(position.price, moneyRate),
      sum: roundMoney(fromReportDocumentMoney(position.price, moneyRate) * Number(position.quantity || 0)),
      isGift: fromReportDocumentMoney(position.price, moneyRate) <= 0
    })),
    productText: buildReportProductText(positions.map((position) => {
      const name = position.assortment?.name || position.name || 'Товар';
      const quantity = Number(position.quantity || 0);
      return `${name} x ${quantity}`;
    })),
    amount,
    paid,
    unpaid,
    commission,
    netProfit: calculatedNetProfit ?? roundMoney((getReportNumberAttribute(document, 'NET_PROFIT', documentType) ?? 0) * moneyRate),
    comment: document.description || ''
  };
}

function fromReportDocumentMoney(value, rate = 1) {
  return roundMoney(fromMoySkladPrice(value) * rate);
}

function getReportDocumentMoneyRate(document, currenciesByHref = new Map()) {
  const currencyReference = document.rate?.currency || document.currency || document.currencyInfo;
  const currency = resolveAccountingCurrency(currencyReference, currenciesByHref);
  if (isKgsCurrency(currency)) return 1;
  if (isUsdCurrency(currency)) return getReportUsdCostRate(document.rate?.value);

  const rateValue = Number(document.rate?.value || 0);
  if (Number.isFinite(rateValue) && rateValue > 10 && rateValue < 200) {
    return rateValue;
  }
  return 1;
}

async function createReportReturn(input) {
  const token = requiredEnv('MOYSKLAD_TOKEN');
  const documentType = String(input.documentType || '');
  const documentId = String(input.documentId || '');
  const productIndex = Number(input.productIndex);
  const quantity = Number(input.quantity || 0);

  if (!['retaildemand', 'demand'].includes(documentType)) {
    throw httpError(400, 'Возврат можно создать только по продаже или отгрузке.');
  }
  if (!documentId) {
    throw httpError(400, 'Не найден документ для возврата.');
  }
  if (!Number.isInteger(productIndex) || productIndex < 0) {
    throw httpError(400, 'Не найден товар для возврата.');
  }

  const original = await getMoySkladDocumentForReturn(token, documentType, documentId);
  const positions = Array.isArray(original.positions?.rows) ? original.positions.rows : [];
  const position = positions[productIndex];
  if (!position) {
    throw httpError(400, 'Товар не найден в документе.');
  }

  const returnQuantity = quantity > 0 ? quantity : Number(position.quantity || 0);
  if (returnQuantity <= 0 || returnQuantity > Number(position.quantity || 0)) {
    throw httpError(400, 'Количество возврата указано неверно.');
  }

  const returnType = documentType === 'retaildemand' ? 'retailsalesreturn' : 'salesreturn';
  const payload = buildReturnPayload(original, documentType, position, returnQuantity);

  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/${returnType}`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8',
      'Content-Type': 'application/json;charset=utf-8'
    },
    body: JSON.stringify(payload)
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось создать возврат в МойСклад.', data);
  }

  return {
    document: {
      id: data.id,
      name: data.name,
      type: returnType,
      webUrl: getMoySkladWebUrl(returnType, data.id)
    }
  };
}

async function applyLoyalty(calculation, input, document) {
  const config = getLoyaltyConfig();
  if (!config.enabled || input.customerMode === 'retail') {
    return null;
  }

  const phone = normalizePhone(input.customerPhone);
  if (!phone) {
    return null;
  }

  const saleId = [document.type, document.id].filter(Boolean).join(':');
  const result = {
    enabled: true,
    redeemed: 0,
    accrued: 0,
    balance: null,
    customer: null
  };

  if (calculation.loyaltyRedemption > 0) {
    const rows = await supabaseRpc('loyalty_redeem', {
      p_phone: phone,
      p_sale_id: saleId,
      p_amount: Math.round(calculation.loyaltyRedemption),
      p_comment: `Списание по документу ${document.name || saleId}`
    });
    const redemption = rows[0];
    result.redeemed = redemption?.transaction_amount || Math.round(calculation.loyaltyRedemption);
    result.balance = redemption?.bonus_balance ?? result.balance;
    result.customer = redemption ? rpcLoyaltyCustomer(redemption) : result.customer;
  }

  const accrueBase = Math.round(calculation.finalTotal || 0);
  const shouldAccrue = calculation.loyaltyRedemption <= 0;
  if (shouldAccrue && accrueBase > 0 && config.accrualPercent > 0) {
    const rows = await supabaseRpc('loyalty_accrue', {
      p_phone: phone,
      p_name: String(input.customerName || '').trim(),
      p_sale_id: saleId,
      p_sale_amount: accrueBase,
      p_percent: config.accrualPercent,
      p_comment: `Начисление по документу ${document.name || saleId}`
    });
    const accrual = rows[0];
    result.accrued = accrual?.transaction_amount || 0;
    result.balance = accrual?.bonus_balance ?? result.balance;
    result.customer = accrual ? rpcLoyaltyCustomer(accrual) : result.customer;
  }

  return result;
}

async function assertLoyaltyRedemptionAllowed(calculation, input) {
  if (!calculation.loyaltyRedemption) {
    return;
  }
  const config = getLoyaltyConfig();
  if (!config.enabled) {
    throw httpError(400, 'Бонусная система выключена.');
  }
  if (input.customerMode === 'retail') {
    throw httpError(400, 'Для розничного покупателя нельзя списать бонусы.');
  }

  const customer = await getLoyaltyCustomer(input.customerPhone);
  if (!customer) {
    throw httpError(400, 'Клиент еще не найден в бонусной базе. Сначала можно только начислить бонусы после покупки.');
  }
  if (Number(customer.bonus_balance || 0) < calculation.loyaltyRedemption) {
    throw httpError(400, `У клиента доступно только ${formatMoney(customer.bonus_balance || 0)} бонусов.`);
  }
}

async function applyLoyaltySafely(calculation, input, document) {
  try {
    return await applyLoyalty(calculation, input, document);
  } catch (error) {
    return {
      enabled: getLoyaltyConfig().enabled,
      error: error.message || 'Не удалось выполнить бонусную операцию.'
    };
  }
}

async function getLoyaltyCustomer(phone) {
  if (!getLoyaltyConfig().enabled) {
    return null;
  }
  const normalizedPhone = normalizePhone(phone);
  if (!normalizedPhone) {
    return null;
  }
  const rows = await supabaseGet('/rest/v1/loyalty_customers', {
    phone: `eq.${normalizedPhone}`,
    select: 'id,phone,name,bonus_balance,created_at,updated_at',
    limit: '1'
  });
  return rows[0] || null;
}

function rpcLoyaltyCustomer(row) {
  return {
    id: row.customer_id,
    phone: row.phone,
    name: row.name,
    bonus_balance: row.bonus_balance
  };
}

function getLoyaltyConfig() {
  const configured = String(process.env.LOYALTY_ENABLED || '').toLowerCase();
  const enabledByEnv = configured ? ['1', 'true', 'yes', 'on'].includes(configured) : Boolean(process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY);
  return {
    enabled: enabledByEnv && Boolean(process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY),
    accrualPercent: Number.isFinite(loyaltyAccrualPercent) ? loyaltyAccrualPercent : 3,
    maxRedeemPercent: getLoyaltyMaxRedeemPercent()
  };
}

function getLoyaltyMaxRedeemPercent() {
  return Number.isFinite(loyaltyMaxRedeemPercent) ? loyaltyMaxRedeemPercent : 30;
}

function getValidatedLoyaltyRedemption(input) {
  const amount = toMoney(input.loyaltyRedemption || 0);
  if (!Number.isFinite(amount) || amount < 0) {
    throw httpError(400, 'Сумма списания бонусов должна быть числом больше или равна нулю.');
  }
  if (!Number.isInteger(amount)) {
    throw httpError(400, 'Бонусы списываются только целым числом.');
  }
  return amount;
}

async function getMoySkladDocumentForReturn(token, documentType, documentId) {
  const params = new URLSearchParams({
    expand: 'agent,organization,store,retailStore,retailShift,positions,positions.assortment'
  });
  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/${documentType}/${documentId}?${params}`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось загрузить исходный документ для возврата.', data);
  }
  return data;
}

function buildReturnPayload(original, documentType, position, quantity) {
  const returnSum = roundMoney(fromMoySkladPrice(position.price) * quantity);
  const payload = {
    organization: original.organization,
    agent: original.agent,
    description: `Возврат товара из документа ${original.name || ''}`.trim(),
    positions: [
      {
        quantity,
        price: position.price,
        assortment: position.assortment
      }
    ]
  };

  if (documentType === 'retaildemand') {
    payload.retailDemand = original.meta;
  } else {
    payload.demand = original.meta;
  }

  if (original.store) {
    payload.store = original.store;
  }

  if (documentType === 'retaildemand') {
    payload.retailStore = original.retailStore;
    if (original.retailShift) {
      payload.retailShift = original.retailShift;
    }
    Object.assign(payload, getRetailReturnPaymentSums(original, returnSum));
  }

  return payload;
}

function getRetailReturnPaymentSums(original, returnSum) {
  const cash = fromMoySkladPrice(original.cashSum);
  const noCash = fromMoySkladPrice(original.noCashSum);
  const total = roundMoney(cash + noCash);
  if (total <= 0) {
    return { cashSum: 0, noCashSum: toMoySkladPrice(returnSum) };
  }
  const cashPart = roundMoney(returnSum * cash / total);
  const noCashPart = roundMoney(returnSum - cashPart);
  return {
    cashSum: toMoySkladPrice(cashPart),
    noCashSum: toMoySkladPrice(noCashPart)
  };
}

function buildReportProductText(productLines) {
  if (!productLines.length) {
    return '';
  }
  if (productLines.length <= 3) {
    return productLines.join(', ');
  }
  return `${productLines.slice(0, 3).join(', ')} и еще ${productLines.length - 3}`;
}

function getReportPhone(document) {
  return document.agent?.phone || document.agent?.phoneNumber || document.agent?.phones?.[0] || '';
}

function getReportAddress(document) {
  return normalizeReportAddress(
    document.shipmentAddress ||
    document.deliveryAddress ||
    document.agent?.actualAddress ||
    document.agent?.legalAddress ||
    document.agent?.actualAddressFull ||
    document.agent?.legalAddressFull
  );
}

function normalizeReportAddress(address) {
  if (!address) {
    return '';
  }
  if (typeof address === 'string') {
    return address;
  }
  return [
    address.postalCode,
    address.country,
    address.region,
    address.city,
    address.street,
    address.house,
    address.apartment,
    address.addInfo
  ].map(formatReportAddressPart).filter(Boolean).join(', ');
}

function formatReportAddressPart(part) {
  if (!part) {
    return '';
  }
  if (typeof part === 'object') {
    return part.name || part.value || '';
  }
  return String(part);
}

function getReportPaymentType(document, documentType) {
  const fromAttribute = getReportTextAttribute(document, 'PAYMENT_TYPE', documentType);
  if (fromAttribute) {
    return fromAttribute;
  }

  const match = String(document.description || '').match(/Тип оплаты:\s*([^\n.]+)/i);
  return match ? match[1].trim() : '';
}

function getReportTextAttribute(document, attribute, documentType) {
  const value = getReportAttributeValue(document, attribute, documentType);
  if (!value) {
    return '';
  }
  if (typeof value === 'object') {
    return value.name || value.meta?.href || '';
  }
  return String(value);
}

function getReportNumberAttribute(document, attribute, documentType) {
  const value = getReportAttributeValue(document, attribute, documentType);
  if (value === undefined || value === null || value === '') {
    return null;
  }
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function getReportAttributeObjectHref(document, attribute, documentType) {
  const value = getReportAttributeValue(document, attribute, documentType);
  return typeof value === 'object' ? String(value.meta?.href || '') : '';
}

function getReportMoneyFromTextAttribute(document, attribute, documentType) {
  const value = getReportAttributeValue(document, attribute, documentType);
  if (value === undefined || value === null || value === '') {
    return 0;
  }
  if (typeof value === 'number') {
    return value;
  }
  const match = String(value).replace(/\s/g, '').replace(',', '.').match(/-?\d+(?:\.\d+)?/);
  return match ? Number(match[0]) : 0;
}

function getReportAttributeValue(document, attribute, documentType) {
  const attributeHref = getAttributeHref(attribute, documentType);
  if (!attributeHref || !Array.isArray(document.attributes)) {
    return undefined;
  }
  const attributeId = getIdFromHref(attributeHref);
  const found = document.attributes.find((entry) => {
    const href = entry.meta?.href || '';
    return href === attributeHref || getIdFromHref(href) === attributeId;
  });
  return found?.value;
}

function normalizeReportDate(value, side) {
  const date = String(value || '').trim() || new Date().toISOString().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    throw httpError(400, 'Дата отчета должна быть в формате YYYY-MM-DD.');
  }
  return `${date} ${side === 'to' ? '23:59:59' : '00:00:00'}`;
}

function getDocumentTypeLabel(type) {
  if (type === 'retaildemand') {
    return 'Продажа';
  }
  if (type === 'demand') {
    return 'Отгрузка';
  }
  if (type === 'retailsalesreturn') {
    return 'Возврат продажи';
  }
  if (type === 'salesreturn') {
    return 'Возврат отгрузки';
  }
  if (type === 'customerorder') {
    return 'Заказ';
  }
  return 'Документ';
}

function getMoySkladWebUrl(type, id) {
  if (!type || !id) {
    return '';
  }
  return `https://online.moysklad.ru/app/#${type}/edit?id=${encodeURIComponent(id)}`;
}

function fromMoySkladPrice(value) {
  const number = Number(value || 0);
  return Number.isFinite(number) ? roundMoney(number / 100) : 0;
}

async function getMoySkladEmployees() {
  const branchConfigs = getMoySkladBranchConfigs().filter((config) => config.branchKey);
  if (!branchConfigs.length) {
    const token = requiredEnv('MOYSKLAD_TOKEN');
    const customEntityId = requiredEnv('MOYSKLAD_EMPLOYEE_CUSTOM_ENTITY_ID');
    const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/customentity/${customEntityId}?limit=100`, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json;charset=utf-8'
      }
    });

    const data = await response.json().catch(() => null);
    if (!response.ok) {
      throw httpError(response.status, 'Не удалось загрузить сотрудников из МойСклад.', data);
    }

    return (data.rows || []).map((item) => ({
      id: item.id || getIdFromHref(item.meta?.href || ''),
      name: item.name,
      href: item.meta.href,
      branchKey: '',
      payroll: parsePayrollConfig(item.description || '')
    }));
  }

  const results = await Promise.all(branchConfigs.map(async (config) => {
    const customEntityId = String(process.env[`MOYSKLAD_${config.branchKey.toUpperCase()}_EMPLOYEE_CUSTOM_ENTITY_ID`] || process.env.MOYSKLAD_EMPLOYEE_CUSTOM_ENTITY_ID || '').trim();
    if (!customEntityId) return [];
    const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/customentity/${customEntityId}?limit=100`, {
      headers: {
        Authorization: `Bearer ${config.token}`,
        Accept: 'application/json;charset=utf-8'
      }
    });
    const data = await response.json().catch(() => null);
    if (!response.ok) {
      throw httpError(response.status, `Не удалось загрузить сотрудников из МойСклад (${moySkladBranchLabels[config.branchKey] || config.branchKey}).`, data);
    }
    return (data.rows || []).map((item) => ({
      id: item.id || getIdFromHref(item.meta?.href || ''),
      name: item.name,
      href: item.meta?.href || '',
      branchKey: config.branchKey,
      payroll: parsePayrollConfig(item.description || '')
    }));
  }));

  return results.flat();
}

async function updateMoySkladEmployeePayrollConfig(input) {
  const token = requiredEnv('MOYSKLAD_TOKEN');
  const customEntityId = requiredEnv('MOYSKLAD_EMPLOYEE_CUSTOM_ENTITY_ID');
  const employeeHref = String(input.employeeHref || '').trim();
  const expectedPrefix = `${MOYSKLAD_BASE_URL}/entity/customentity/${customEntityId}/`;
  if (!employeeHref.startsWith(expectedPrefix) || !getMoySkladEntityIdFromInput(employeeHref)) {
    throw httpError(400, 'Выберите корректного сотрудника.');
  }

  const currentResponse = await moySkladFetch(employeeHref, {
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/json;charset=utf-8' }
  });
  const current = await currentResponse.json().catch(() => null);
  if (!currentResponse.ok) {
    throw httpError(currentResponse.status, 'Не удалось загрузить сотрудника из МойСклад.', current);
  }

  const payroll = normalizePayrollConfig(input.payroll || {});
  const description = setMarkedJsonInDescription(
    current.description || '',
    PAYROLL_CONFIG_START,
    PAYROLL_CONFIG_END,
    payroll
  );
  const updateResponse = await moySkladFetch(employeeHref, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ description })
  });
  const updated = await updateResponse.json().catch(() => null);
  if (!updateResponse.ok) {
    throw httpError(updateResponse.status, `Не удалось сохранить настройки сотрудника «${current.name || ''}».`, updated);
  }

  return {
    id: updated?.id || current.id || getIdFromHref(employeeHref),
    name: updated?.name || current.name || '',
    href: updated?.meta?.href || employeeHref,
    payroll: parsePayrollConfig(updated?.description || description)
  };
}

function normalizePayrollConfig(input = {}) {
  const scheme = ['salary', 'percent', 'salary_percent', 'category_bonus', 'salary_category_bonus'].includes(input.scheme)
    ? input.scheme
    : 'salary_percent';
  const percentBase = input.percentBase === 'profit' ? 'profit' : 'revenue';
  const position = ['manager', 'seller', 'courier', 'cashier', 'warehouse', 'other'].includes(input.position)
    ? input.position
    : 'seller';
  return {
    enabled: input.enabled !== false,
    position,
    customPosition: position === 'other' ? String(input.customPosition || '').trim().slice(0, 80) : '',
    scheme,
    monthlySalary: clampPayrollNumber(input.monthlySalary, 0, 10000000),
    percent: clampPayrollNumber(input.percent, 0, 100),
    percentBase
  };
}

function clampPayrollNumber(value, min, max) {
  const number = Number(value);
  if (!Number.isFinite(number)) return min;
  return roundMoney(Math.min(max, Math.max(min, number)));
}

function parsePayrollConfig(description) {
  const parsed = parseMarkedJsonFromDescription(description, PAYROLL_CONFIG_START, PAYROLL_CONFIG_END);
  return normalizePayrollConfig(parsed || { enabled: false, scheme: 'salary_percent' });
}

async function getPayrollReport(input) {
  const dateFrom = normalizePayrollDate(input.dateFrom);
  const dateTo = normalizePayrollDate(input.dateTo);
  if (dateFrom > dateTo) throw httpError(400, 'Дата начала не может быть позже даты окончания.');

  const cacheKey = `${dateFrom}|${dateTo}`;
  const cached = payrollReportCache.get(cacheKey);
  if (cached && Date.now() - cached.createdAt < 30_000) return cached.value;

  const [employees, salesReport, crmPayrollUsers] = await Promise.all([
    getMoySkladEmployees(),
    getSalesReport({ dateFrom, dateTo, retailStoreHref: '', storeHref: '' }),
    getCrmPayrollUsers()
  ]);
  const crmPayrollByName = buildCrmPayrollLookup(crmPayrollUsers);
  const salesByEmployee = new Map();
  let unassignedDocuments = 0;
  let unassignedRevenue = 0;
  for (const row of salesReport.rows || []) {
    const key = row.employeeHref || normalizeEmployeeKey(row.employeeName);
    if (!key) {
      unassignedDocuments += 1;
      unassignedRevenue = roundMoney(unassignedRevenue + Number(row.amount || 0));
      continue;
    }
    const current = salesByEmployee.get(key) || { documents: 0, revenue: 0, profit: 0, categoryBonus: 0, sales: [] };
    current.documents += 1;
    current.revenue = roundMoney(current.revenue + Number(row.amount || 0));
    current.profit = roundMoney(current.profit + Number(row.netProfit || 0));
    current.categoryBonus = roundMoney(current.categoryBonus + getDocumentCategoryBonus(row.products || []));
    current.sales.push({
      id: row.id,
      name: row.name,
      typeLabel: row.typeLabel,
      moment: row.moment,
      amount: row.amount,
      netProfit: row.netProfit,
      webUrl: row.webUrl,
      customerName: row.customerName,
      products: row.products || []
    });
    salesByEmployee.set(key, current);
  }

  const rows = employees.map((employee) => {
    const payroll = normalizePayrollConfig(employee.payroll);
    const crmPayrollUser = findCrmPayrollUser(employee, crmPayrollByName);
    if (crmPayrollUser) {
      payroll.position = 'other';
      payroll.customPosition = crmPayrollUser.position || '';
      payroll.monthlySalary = crmPayrollUser.salary || 0;
    }
    const sales = salesByEmployee.get(employee.href)
      || salesByEmployee.get(normalizeEmployeeKey(employee.name))
      || { documents: 0, revenue: 0, profit: 0, categoryBonus: 0, sales: [] };
    const includesSalary = payroll.enabled && ['salary', 'salary_percent', 'salary_category_bonus'].includes(payroll.scheme);
    const includesPercent = payroll.enabled && ['percent', 'salary_percent'].includes(payroll.scheme);
    const includesCategoryBonus = payroll.enabled && ['category_bonus', 'salary_category_bonus'].includes(payroll.scheme);
    const fixedSalary = includesSalary
      ? calculateProratedMonthlySalary(payroll.monthlySalary, dateFrom, dateTo)
      : 0;
    const percentSource = payroll.percentBase === 'profit' ? Math.max(0, sales.profit) : Math.max(0, sales.revenue);
    const commission = includesCategoryBonus
      ? roundMoney(sales.categoryBonus)
      : includesPercent
        ? roundMoney(percentSource * payroll.percent / 100)
        : 0;
    return {
      ...employee,
      payroll,
      documents: sales.documents,
      revenue: sales.revenue,
      profit: sales.profit,
      categoryBonus: sales.categoryBonus,
      sales: [...sales.sales].sort((left, right) => new Date(right.moment) - new Date(left.moment)),
      fixedSalary,
      commission,
      totalSalary: roundMoney(fixedSalary + commission)
    };
  }).sort((left, right) => left.name.localeCompare(right.name, 'ru'));

  const totals = rows.reduce((sum, row) => ({
    employees: sum.employees + (row.payroll.enabled ? 1 : 0),
    documents: sum.documents + row.documents,
    revenue: roundMoney(sum.revenue + row.revenue),
    profit: roundMoney(sum.profit + row.profit),
    fixedSalary: roundMoney(sum.fixedSalary + row.fixedSalary),
    commission: roundMoney(sum.commission + row.commission),
    totalSalary: roundMoney(sum.totalSalary + row.totalSalary)
  }), { employees: 0, documents: 0, revenue: 0, profit: 0, fixedSalary: 0, commission: 0, totalSalary: 0 });

  const result = { dateFrom, dateTo, rows, totals: { ...totals, unassignedDocuments, unassignedRevenue } };
  payrollReportCache.set(cacheKey, { value: result, createdAt: Date.now() });
  return result;
}

function getDocumentCategoryBonus(products) {
  return roundMoney(products.reduce((sum, product) => {
    if (product.isGift || Number(product.price || 0) <= 0) return sum;
    const source = normalizeEmployeeKey(`${product.categoryPath || ''} ${product.categoryName || ''} ${product.name || ''}`);
    const rule = categorySaleBonusRules.find((item) => item.match.test(source));
    return sum + (rule?.amount || 0) * Math.max(0, Number(product.quantity || 0));
  }, 0));
}

function normalizePayrollDate(value) {
  const date = String(value || '').trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw httpError(400, 'Укажите период расчета зарплаты.');
  return date;
}

function normalizeEmployeeKey(value) {
  return String(value || '').trim().toLocaleLowerCase('ru-RU').replace(/\s+/g, ' ');
}

function getEmployeeLookupKeys(value) {
  const normalized = normalizeEmployeeKey(value);
  if (!normalized) return [];
  const compact = normalized.replace(/[^a-zа-яё0-9]/giu, '');
  const firstWord = normalized.split(/[\s,]+/).filter(Boolean)[0] || '';
  return [...new Set([normalized, compact, firstWord].filter(Boolean))];
}

function buildCrmPayrollLookup(users) {
  const lookup = new Map();
  for (const user of users || []) {
    for (const key of [
      ...getEmployeeLookupKeys(user.name),
      ...getEmployeeLookupKeys(user.login)
    ]) {
      if (!lookup.has(key)) lookup.set(key, user);
    }
  }
  return lookup;
}

function findCrmPayrollUser(employee, lookup) {
  for (const key of getEmployeeLookupKeys(employee?.name)) {
    const found = lookup.get(key);
    if (found) return found;
  }
  return null;
}

function calculateProratedMonthlySalary(monthlySalary, dateFrom, dateTo) {
  const salary = Number(monthlySalary || 0);
  if (salary <= 0) return 0;
  const start = new Date(`${dateFrom}T00:00:00Z`);
  const end = new Date(`${dateTo}T00:00:00Z`);
  let current = new Date(start);
  let total = 0;
  while (current <= end) {
    const year = current.getUTCFullYear();
    const month = current.getUTCMonth();
    const daysInMonth = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
    total += salary / daysInMonth;
    current = new Date(Date.UTC(year, month, current.getUTCDate() + 1));
  }
  return roundMoney(total);
}

function parseMarkedJsonFromDescription(description, startMarker, endMarker) {
  const text = String(description || '');
  const startIndex = text.indexOf(startMarker);
  const endIndex = text.indexOf(endMarker);
  if (startIndex < 0 || endIndex <= startIndex) return null;
  try {
    const encoded = text.slice(startIndex + startMarker.length, endIndex).trim();
    return JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
}

function setMarkedJsonInDescription(description, startMarker, endMarker, value) {
  const text = String(description || '');
  const startIndex = text.indexOf(startMarker);
  const endIndex = text.indexOf(endMarker);
  const clean = startIndex >= 0 && endIndex > startIndex
    ? `${text.slice(0, startIndex)}${text.slice(endIndex + endMarker.length)}`.trim()
    : text.trim();
  const encoded = Buffer.from(JSON.stringify(value), 'utf8').toString('base64url');
  return [clean, `${startMarker}\n${encoded}\n${endMarker}`].filter(Boolean).join('\n\n');
}

async function getMoySkladStores() {
  const token = requiredEnv('MOYSKLAD_TOKEN');
  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/store?limit=100`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось загрузить склады из МойСклад.', data);
  }

  return (data.rows || []).map((store) => ({
    id: store.id,
    name: store.name,
    href: store.meta.href
  }));
}

async function getMoySkladRetailStores(input = {}) {
  const branchKey = getMoySkladBranchKey(input);
  if (branchKey) {
    const retailStoreHref = getMoySkladEnvValue('RETAIL_STORE_HREF', input);
    const storeHref = getMoySkladEnvValue('STORE_HREF', input);
    if (retailStoreHref) {
      return [{
        href: retailStoreHref,
        storeHref,
        name: moySkladBranchLabels[branchKey] || branchKey
      }];
    }
  }
  const token = getMoySkladTokenFor(input);
  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/retailstore?limit=100`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось загрузить точки продаж из МойСклад.', data);
  }

  return (data.rows || []).map((retailStore) => ({
    id: retailStore.id,
    name: retailStore.name,
    href: retailStore.meta.href,
    storeHref: retailStore.store?.meta?.href || '',
    storeName: retailStore.store?.name || ''
  }));
}

async function getMoySkladRetailShifts(retailStoreHref, input = {}) {
  const token = getMoySkladTokenFor(input);
  const shifts = await getRetailShifts(token, retailStoreHref);
  return shifts.map((shift) => ({
    id: shift.id,
    name: shift.name,
    href: shift.meta?.href || '',
    moment: shift.moment,
    closeDate: shift.closeDate,
    closeMoment: shift.closeMoment,
    closed: Boolean(shift.closed),
    retailStoreHref: shift.retailStore?.meta?.href || shift.retailstore?.meta?.href || ''
  }));
}

async function getRetailFiscalStatus(documentId, input = {}) {
  const token = getMoySkladTokenFor(input);
  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/retaildemand/${encodeURIComponent(documentId)}?expand=retailStore,retailShift,store,agent`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось проверить фискальный статус документа в МойСклад.', data);
  }

  const cashSum = fromMoySkladPrice(data.cashSum);
  const noCashSum = fromMoySkladPrice(data.noCashSum);
  const total = fromMoySkladPrice(data.sum);
  const checks = {
    retailDemand: data.meta?.type === 'retaildemand',
    retailStore: Boolean(data.retailStore?.meta?.href),
    retailShift: Boolean(data.retailShift?.meta?.href),
    store: Boolean(data.store?.meta?.href),
    amount: total > 0,
    paymentSplit: cashSum > 0 || noCashSum > 0
  };
  const ready = Object.values(checks).every(Boolean);

  return {
    ready,
    checks,
    branchKey: getMoySkladBranchKey(input),
    document: {
      id: data.id,
      name: data.name || '',
      sum: total,
      cashSum,
      noCashSum,
      retailStoreName: data.retailStore?.name || '',
      retailShiftName: data.retailShift?.name || '',
      storeName: data.store?.name || '',
      customerName: data.agent?.name || '',
      moment: data.moment || '',
      webUrl: getMoySkladWebUrl('retaildemand', data.id)
    },
    note: ready
      ? 'Документ выглядит готовым для облачной фискализации через кассовую схему МойСклад/NewCas.'
      : 'Документ создан, но не все кассовые поля заполнены для уверенной фискализации.'
  };
}

async function getStoreHrefForRetailStore(token, retailStoreHref) {
  const response = await moySkladFetch(retailStoreHref, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось получить точку продаж из МойСклад.', data);
  }

  return data.store?.meta?.href || '';
}

async function getActiveRetailShiftHref(token, retailStoreHref) {
  const shifts = await getRetailShifts(token, retailStoreHref);
  const retailStoreId = getIdFromHref(retailStoreHref);
  const activeShift = shifts.find((shift) => {
    const shiftStoreHref = shift.retailStore?.meta?.href || shift.retailstore?.meta?.href || '';
    const sameStore = shiftStoreHref === retailStoreHref || getIdFromHref(shiftStoreHref) === retailStoreId;
    return sameStore && !shift.closed;
  });

  return activeShift?.meta?.href || '';
}

async function getRetailShifts(token, retailStoreHref) {
  const params = new URLSearchParams({
    limit: '20',
    filter: `retailStore=${retailStoreHref}`,
    order: 'moment,desc'
  });
  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/retailshift?${params}`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'Не удалось загрузить смены из МойСклад.', data);
  }

  return data.rows || [];
}

function parsePaymentType(name) {
  const text = String(name || '').trim();
  const monthsMatch = text.match(/\((\d+)\s*мес\)/i);
  const months = monthsMatch ? Number(monthsMatch[1]) : 1;
  const provider = text.replace(/\s*\(\d+\s*мес\)\s*/i, '').trim();
  return { provider, months };
}

function parseRateFromComment(comment) {
  const text = String(comment || '').trim().replace(',', '.');
  const numberOnlyMatch = text.match(/^(\d+(?:\.\d+)?)$/);
  if (numberOnlyMatch) {
    return Number(numberOnlyMatch[1]) / 100;
  }

  const percentMatch = text.match(/(\d+(?:\.\d+)?)\s*%/);
  if (percentMatch) {
    return Number(percentMatch[1]) / 100;
  }

  const rateMatch = text.match(/(?:ставка|процент|комиссия)\s*[:=-]?\s*(0?\.\d+|\d+(?:\.\d+)?)/i);
  if (!rateMatch) {
    return undefined;
  }

  const value = Number(rateMatch[1]);
  if (!Number.isFinite(value)) {
    return undefined;
  }
  return value > 1 ? value / 100 : value;
}

function getPaymentRate(provider, months, explicitRate) {
  const rate = Number(explicitRate);
  if (Number.isFinite(rate) && rate >= 0) {
    return rate > 1 ? rate / 100 : rate;
  }

  const rates = paymentRateRules[provider];
  if (!rates || rates[months] === undefined) {
    return 0;
  }
  return rates[months];
}

function getAttributeHref(attribute, documentType) {
  const retailSpecific = process.env[`MOYSKLAD_RETAILDEMAND_${attribute}_ATTRIBUTE_HREF`];
  if (documentType === 'retaildemand') {
    return retailSpecific || '';
  }
  const customerOrderSpecific = process.env[`MOYSKLAD_CUSTOMERORDER_${attribute}_ATTRIBUTE_HREF`];
  if (documentType === 'customerorder') {
    return customerOrderSpecific || '';
  }
  return process.env[`MOYSKLAD_${attribute}_ATTRIBUTE_HREF`] || '';
}

function getIdFromHref(href) {
  return String(href || '').split('/').filter(Boolean).at(-1) || '';
}

async function serveStatic(url, res) {
  const pathname = typeof url === 'string' ? url : url.pathname;
  const requestedVersion = typeof url === 'string' ? '' : String(url.searchParams.get('v') || '');
  const safePath = pathname === '/'
    ? '/about.html'
    : pathname === '/sales.html' || pathname === '/debt-sale.html'
      ? '/index.html'
      : pathname;
  const normalized = normalize(safePath).replace(/^(\.\.[/\\])+/, '');
  const filePath = join(publicDir, normalized);

  if (!filePath.startsWith(publicDir)) {
    sendJson(res, 403, { error: 'Forbidden' });
    return;
  }

  try {
    let file = await readFile(filePath);
    const type = contentTypes[extname(filePath)] || 'application/octet-stream';
    const extension = extname(filePath);
    if (extension === '.html') {
      file = Buffer.from(rewriteStaticHtml(file.toString('utf8')), 'utf8');
    } else if (extension === '.js') {
      file = Buffer.from(rewriteStaticJsModule(file.toString('utf8'), safePath), 'utf8');
    }
    const currentVersion = ['.js', '.css'].includes(extension) ? getStaticAssetVersion(safePath) : '';
    const cacheControl = currentVersion && requestedVersion && requestedVersion === currentVersion
      ? 'public, max-age=31536000, immutable'
      : extension === '.html'
        ? 'no-store'
        : 'public, max-age=300';
    res.writeHead(200, { 'Content-Type': type, 'Cache-Control': cacheControl });
    res.end(file);
  } catch {
    sendJson(res, 404, { error: 'Not found' });
  }
}

function rewriteStaticHtml(source) {
  return source.replace(/((?:src|href)=["'])(\/[^"'?#]+\.(?:js|css))(\?[^"']*)?(["'])/gi, (_match, prefix, assetPath, _query, suffix) => {
    const version = getStaticAssetVersion(assetPath);
    return `${prefix}${assetPath}${version ? `?v=${version}` : ''}${suffix}`;
  });
}

function rewriteStaticJsModule(source, modulePath) {
  return source.replace(/((?:import|export)\s[^"'`]*?\sfrom\s*["']|import\s*\(\s*["'])((?:\.{1,2}\/|\/)[^"'?#]+\.(?:js|css))(["'])/g, (_match, prefix, assetPath, suffix) => {
    const versioned = toVersionedModuleSpecifier(modulePath, assetPath);
    return `${prefix}${versioned}${suffix}`;
  });
}

function toVersionedModuleSpecifier(modulePath, assetPath) {
  const normalized = assetPath.startsWith('/')
    ? posixPath.normalize(assetPath)
    : posixPath.normalize(posixPath.join(posixPath.dirname(modulePath), assetPath));
  const version = getStaticAssetVersion(normalized.startsWith('/') ? normalized : `/${normalized}`);
  return `${assetPath}${version ? `?v=${version}` : ''}`;
}

function getStaticAssetVersion(assetPath) {
  const normalized = normalizeStaticAssetPath(assetPath);
  if (!normalized) return '';
  if (staticAssetHashCache.has(normalized)) return staticAssetHashCache.get(normalized);
  try {
    const content = readFileSync(join(publicDir, normalized.slice(1)));
    const hash = createHmac('sha256', 'mysrs-static-assets')
      .update(content)
      .digest('hex')
      .slice(0, 12);
    staticAssetHashCache.set(normalized, hash);
    return hash;
  } catch {
    return '';
  }
}

function normalizeStaticAssetPath(assetPath) {
  const pathname = String(assetPath || '').split('?')[0];
  if (!pathname.startsWith('/')) return '';
  const normalized = posixPath.normalize(pathname);
  if (normalized.includes('..')) return '';
  return normalized;
}

async function readJson(req) {
  let body = '';
  for await (const chunk of req) {
    body += chunk;
    if (body.length > 8 * 1024 * 1024) {
      throw httpError(413, 'Слишком большой запрос.');
    }
  }
  return body ? JSON.parse(body) : {};
}

async function getAttendanceStores() {
  const stores = await readJsonArrayFile(attendanceStoresPath);
  if (stores.length) return stores;
  return seedDefaultAttendanceStores();
}

async function seedDefaultAttendanceStores() {
  const now = new Date().toISOString();
  const rows = [
    {
      id: randomUUID(),
      name: 'Аю-Гранд',
      branch: 'ayu',
      address: '',
      latitude: 0,
      longitude: 0,
      allowedRadiusMeters: ATTENDANCE_DEFAULT_RADIUS_METERS,
      qrToken: createAttendanceToken(),
      qrTokenExpiresAt: '',
      createdAt: now,
      updatedAt: now
    },
    {
      id: randomUUID(),
      name: 'Беш-Сары',
      branch: 'besh',
      address: '',
      latitude: 0,
      longitude: 0,
      allowedRadiusMeters: ATTENDANCE_DEFAULT_RADIUS_METERS,
      qrToken: createAttendanceToken(),
      qrTokenExpiresAt: '',
      createdAt: now,
      updatedAt: now
    }
  ];
  await writeJsonArrayFile(attendanceStoresPath, rows);
  return rows;
}

async function createAttendanceStore(input) {
  const stores = await getAttendanceStores();
  const now = new Date().toISOString();
  const store = normalizeAttendanceStoreInput(input, {
    id: randomUUID(),
    qrToken: createAttendanceToken(),
    qrTokenExpiresAt: '',
    createdAt: now,
    updatedAt: now
  });
  stores.push(store);
  await writeJsonArrayFile(attendanceStoresPath, stores);
  return store;
}

async function updateAttendanceStore(id, input) {
  const stores = await getAttendanceStores();
  const index = stores.findIndex((store) => store.id === id);
  if (index < 0) throw httpError(404, 'Рабочая точка не найдена.');
  stores[index] = normalizeAttendanceStoreInput(input, {
    ...stores[index],
    updatedAt: new Date().toISOString()
  });
  await writeJsonArrayFile(attendanceStoresPath, stores);
  return stores[index];
}

async function deleteAttendanceStore(id) {
  const stores = await getAttendanceStores();
  const index = stores.findIndex((store) => store.id === id);
  if (index < 0) throw httpError(404, 'Рабочая точка не найдена.');
  const [store] = stores.splice(index, 1);
  await writeJsonArrayFile(attendanceStoresPath, stores);
  return store;
}

async function generateAttendanceStoreQr(id, input = {}) {
  const stores = await getAttendanceStores();
  const index = stores.findIndex((store) => store.id === id);
  if (index < 0) throw httpError(404, 'Рабочая точка не найдена.');
  const ttlMinutes = Number(input.ttlMinutes || 0);
  stores[index] = {
    ...stores[index],
    qrToken: createAttendanceToken(),
    qrDisabled: false,
    qrTokenExpiresAt: ttlMinutes > 0 ? new Date(Date.now() + ttlMinutes * 60_000).toISOString() : '',
    updatedAt: new Date().toISOString()
  };
  await writeJsonArrayFile(attendanceStoresPath, stores);
  return stores[index];
}

async function disableAttendanceStoreQr(id) {
  const stores = await getAttendanceStores();
  const index = stores.findIndex((store) => store.id === id);
  if (index < 0) throw httpError(404, 'Рабочая точка не найдена.');
  stores[index] = {
    ...stores[index],
    qrToken: '',
    qrDisabled: true,
    qrTokenExpiresAt: '',
    updatedAt: new Date().toISOString()
  };
  await writeJsonArrayFile(attendanceStoresPath, stores);
  return stores[index];
}

function normalizeAttendanceStoreInput(input, base) {
  const name = String(input.name ?? base.name ?? '').trim();
  if (!name) throw httpError(400, 'Укажите название рабочей точки.');
  const latitude = Number(input.latitude ?? base.latitude);
  const longitude = Number(input.longitude ?? base.longitude);
  if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90) throw httpError(400, 'Некорректная широта.');
  if (!Number.isFinite(longitude) || longitude < -180 || longitude > 180) throw httpError(400, 'Некорректная долгота.');
  const allowedRadiusMeters = Math.max(1, Math.min(1000, Number(input.allowedRadiusMeters ?? input.allowed_radius_meters ?? base.allowedRadiusMeters ?? ATTENDANCE_DEFAULT_RADIUS_METERS)));
  return {
    id: base.id,
    name,
    branch: normalizeAttendanceBranchKey(input.branch ?? base.branch ?? name),
    address: String(input.address ?? base.address ?? '').trim(),
    latitude,
    longitude,
    allowedRadiusMeters,
    qrToken: base.qrDisabled ? '' : String(base.qrToken || createAttendanceToken()),
    qrDisabled: Boolean(base.qrDisabled),
    qrTokenExpiresAt: String(input.qrTokenExpiresAt ?? input.qr_token_expires_at ?? base.qrTokenExpiresAt ?? ''),
    createdAt: base.createdAt || new Date().toISOString(),
    updatedAt: base.updatedAt || new Date().toISOString()
  };
}

async function getAttendanceSchedule() {
  try {
    const raw = await readFile(attendanceSchedulePath, 'utf8');
    const data = JSON.parse(raw || '{}');
    return normalizeAttendanceScheduleInput(data);
  } catch {
    return { workStartsAt: '09:00', workEndsAt: '18:00' };
  }
}

async function saveAttendanceSchedule(input) {
  const schedule = normalizeAttendanceScheduleInput(input);
  await writeFile(attendanceSchedulePath, JSON.stringify(schedule, null, 2));
  return schedule;
}

function normalizeAttendanceScheduleInput(input = {}) {
  const workStartsAt = String(input.workStartsAt || input.work_starts_at || '09:00').trim();
  const workEndsAt = String(input.workEndsAt || input.work_ends_at || '18:00').trim();
  const timePattern = /^([01]\d|2[0-3]):[0-5]\d$/;
  return {
    workStartsAt: timePattern.test(workStartsAt) ? workStartsAt : '09:00',
    workEndsAt: timePattern.test(workEndsAt) ? workEndsAt : '18:00'
  };
}

async function getAttendanceStatus(user) {
  const [records, stores] = await Promise.all([
    readJsonArrayFile(attendanceRecordsPath),
    getAttendanceStores()
  ]);
  const openRecord = records.find((record) => record.userId === user.id && record.status === 'open') || null;
  return {
    status: openRecord ? 'working' : 'not_working',
    openRecord: openRecord ? enrichAttendanceRecord(openRecord, stores) : null,
    now: new Date().toISOString()
  };
}

async function getAttendanceGate(user) {
  const required = isAttendanceRequiredForUser(user);
  const openRecord = required ? await getOpenAttendanceRecord(user) : null;
  return {
    required,
    allowed: !required || Boolean(openRecord),
    status: openRecord ? 'working' : 'not_working',
    openRecord: openRecord ? enrichAttendanceRecord(openRecord, await getAttendanceStores()) : null,
    attendanceUrl: '/attendance.html'
  };
}

async function getOpenAttendanceRecord(user) {
  const records = await readJsonArrayFile(attendanceRecordsPath);
  return records.find((record) => record.userId === user.id && record.status === 'open') || null;
}

function isAttendanceRequiredForUser(user) {
  return ['manager', 'seller', 'logistics', 'accountant', 'employee'].includes(user?.role);
}

async function shouldBlockByAttendanceGate(pathname, user) {
  if (!isAttendanceRequiredForUser(user)) return false;
  if (isAttendanceGateAllowedPath(pathname)) return false;
  return !(await getOpenAttendanceRecord(user));
}

function isAttendanceGateAllowedPath(pathname) {
  return pathname === '/api/crm/session'
    || pathname === '/api/crm/login'
    || pathname === '/api/crm/logout'
    || pathname === '/api/crm/login-users'
    || pathname.startsWith('/api/attendance/');
}

async function markAttendanceShift(user, input, req, expectedAction) {
  const storeId = String(input.storeId || input.store_id || '').trim();
  const latitude = Number(input.latitude);
  const longitude = Number(input.longitude);
  const deviceInfo = String(input.device_info || input.deviceInfo || req.headers['user-agent'] || '').slice(0, 500);
  const ipAddress = getRequestIp(req);

  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
    await saveAttendanceEvent({ user, type: 'failed_attempt', success: false, reason: 'Для отметки прихода/ухода необходимо разрешить доступ к геолокации.', latitude: null, longitude: null, deviceInfo, ipAddress });
    throw httpError(400, 'Для отметки прихода/ухода необходимо разрешить доступ к геолокации.');
  }

  const stores = await getAttendanceStores();
  const records = await readJsonArrayFile(attendanceRecordsPath);
  const openRecordIndex = records.findIndex((record) => record.userId === user.id && record.status === 'open');
  const openRecord = openRecordIndex >= 0 ? records[openRecordIndex] : null;
  const store = expectedAction === 'check_out'
    ? stores.find((entry) => entry.id === (openRecord?.storeId || storeId))
    : stores.find((entry) => entry.id === storeId);

  if (expectedAction === 'check_in' && openRecord) throw httpError(400, 'Смена уже открыта.');
  if (expectedAction === 'check_out' && !openRecord) throw httpError(400, 'Открытая смена не найдена.');
  if (!store) throw httpError(400, 'Рабочая точка не найдена.');

  const userBranches = normalizeCrmBranches(user.branches);
  if (store.branch && userBranches.length && !userBranches.includes(store.branch) && !['admin', 'owner'].includes(user.role)) {
    await saveAttendanceEvent({ user, store, type: 'failed_attempt', success: false, reason: 'У сотрудника нет доступа к этой рабочей точке.', latitude, longitude, deviceInfo, ipAddress });
    throw httpError(403, 'У сотрудника нет доступа к этой рабочей точке.');
  }

  const distanceMeters = Math.round(haversineDistanceMeters(latitude, longitude, store.latitude, store.longitude) * 10) / 10;
  if (!Number.isFinite(distanceMeters) || distanceMeters > Number(store.allowedRadiusMeters || ATTENDANCE_DEFAULT_RADIUS_METERS)) {
    await saveAttendanceEvent({ user, store, type: 'failed_attempt', success: false, reason: 'Вы слишком далеко от рабочей точки. Отметка невозможна.', latitude, longitude, distanceMeters, deviceInfo, ipAddress });
    throw httpError(403, 'Вы слишком далеко от рабочей точки. Отметка невозможна.', { distanceMeters });
  }

  const now = new Date().toISOString();
  let record;
  if (expectedAction === 'check_out') {
    record = {
      ...openRecord,
      checkOutTime: now,
      checkOutLatitude: latitude,
      checkOutLongitude: longitude,
      checkOutDistanceMeters: distanceMeters,
      totalWorkMinutes: openRecord.excludeFromWorkTime ? 0 : calculateWorkMinutes(openRecord.checkInTime, now),
      status: 'closed',
      updatedAt: now
    };
    records[openRecordIndex] = record;
  } else {
    record = {
      id: randomUUID(),
      userId: user.id,
      userName: user.name || user.login || '',
      storeId: store.id,
      storeName: store.name,
      checkInTime: now,
      checkOutTime: '',
      checkInLatitude: latitude,
      checkInLongitude: longitude,
      checkOutLatitude: null,
      checkOutLongitude: null,
      checkInDistanceMeters: distanceMeters,
      checkOutDistanceMeters: null,
      totalWorkMinutes: 0,
      status: 'open',
      source: 'geo',
      excludeFromWorkTime: false,
      deviceInfo,
      ipAddress,
      createdAt: now,
      updatedAt: now
    };
    records.push(record);
  }

  await writeJsonArrayFile(attendanceRecordsPath, records);
  await saveAttendanceEvent({ user, store, type: expectedAction, success: true, reason: '', latitude, longitude, distanceMeters, deviceInfo, ipAddress });

  return {
    ok: true,
    action: expectedAction,
    message: expectedAction === 'check_in' ? 'Смена открыта.' : 'Смена завершена.',
    status: expectedAction === 'check_in' ? 'working' : 'not_working',
    record: enrichAttendanceRecord(record, stores),
    store: sanitizeAttendanceStore(store),
    distanceMeters
  };
}

async function scanAttendanceQr(user, input, req) {
  const qrToken = String(input.qr_token || input.qrToken || input.token || '').trim();
  const latitude = Number(input.latitude);
  const longitude = Number(input.longitude);
  const deviceInfo = String(input.device_info || input.deviceInfo || req.headers['user-agent'] || '').slice(0, 500);
  const ipAddress = getRequestIp(req);

  if (!qrToken) {
    await saveAttendanceEvent({ user, type: 'failed_attempt', success: false, reason: 'QR-код недействителен или устарел.', latitude, longitude, deviceInfo, ipAddress });
    throw httpError(400, 'QR-код недействителен или устарел.');
  }
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
    await saveAttendanceEvent({ user, type: 'failed_attempt', success: false, reason: 'Для отметки прихода/ухода необходимо разрешить доступ к геолокации.', latitude: null, longitude: null, deviceInfo, ipAddress });
    throw httpError(400, 'Для отметки прихода/ухода необходимо разрешить доступ к геолокации.');
  }

  const stores = await getAttendanceStores();
  const store = stores.find((entry) => entry.qrToken === qrToken);
  if (!store || store.qrDisabled || (store.qrTokenExpiresAt && new Date(store.qrTokenExpiresAt).getTime() <= Date.now())) {
    await saveAttendanceEvent({ user, type: 'failed_attempt', success: false, reason: 'QR-код недействителен или устарел.', latitude, longitude, deviceInfo, ipAddress });
    throw httpError(400, 'QR-код недействителен или устарел.');
  }

  const userBranches = normalizeCrmBranches(user.branches);
  if (store.branch && userBranches.length && !userBranches.includes(store.branch) && !['admin', 'owner'].includes(user.role)) {
    await saveAttendanceEvent({ user, store, type: 'failed_attempt', success: false, reason: 'У сотрудника нет доступа к этой рабочей точке.', latitude, longitude, deviceInfo, ipAddress });
    throw httpError(403, 'У сотрудника нет доступа к этой рабочей точке.');
  }

  const distanceMeters = Math.round(haversineDistanceMeters(latitude, longitude, store.latitude, store.longitude) * 10) / 10;
  if (!Number.isFinite(distanceMeters) || distanceMeters > Number(store.allowedRadiusMeters || ATTENDANCE_DEFAULT_RADIUS_METERS)) {
    await saveAttendanceEvent({ user, store, type: 'failed_attempt', success: false, reason: 'Вы слишком далеко от рабочей точки. Отметка невозможна.', latitude, longitude, distanceMeters, deviceInfo, ipAddress });
    throw httpError(403, 'Вы слишком далеко от рабочей точки. Отметка невозможна.', { distanceMeters });
  }

  const records = await readJsonArrayFile(attendanceRecordsPath);
  const openRecordIndex = records.findIndex((record) => record.userId === user.id && record.status === 'open');
  const lastEvent = (await readJsonArrayFile(attendanceEventsPath))
    .filter((event) => event.userId === user.id && event.success)
    .sort((left, right) => new Date(right.createdAt) - new Date(left.createdAt))[0];
  if (lastEvent && Date.now() - new Date(lastEvent.createdAt).getTime() < ATTENDANCE_MIN_SCAN_INTERVAL_MS) {
    await saveAttendanceEvent({ user, store, type: 'failed_attempt', success: false, reason: 'Повторное сканирование слишком быстро. Подождите 30 секунд.', latitude, longitude, distanceMeters, deviceInfo, ipAddress });
    throw httpError(429, 'Повторное сканирование слишком быстро. Подождите 30 секунд.');
  }

  const now = new Date().toISOString();
  let action;
  let record;
  if (openRecordIndex >= 0) {
    record = {
      ...records[openRecordIndex],
      checkOutTime: now,
      checkOutLatitude: latitude,
      checkOutLongitude: longitude,
      checkOutDistanceMeters: distanceMeters,
      totalWorkMinutes: records[openRecordIndex].excludeFromWorkTime ? 0 : calculateWorkMinutes(records[openRecordIndex].checkInTime, now),
      status: 'closed',
      updatedAt: now
    };
    records[openRecordIndex] = record;
    action = 'check_out';
  } else {
    record = {
      id: randomUUID(),
      userId: user.id,
      userName: user.name || user.login || '',
      storeId: store.id,
      storeName: store.name,
      checkInTime: now,
      checkOutTime: '',
      checkInLatitude: latitude,
      checkInLongitude: longitude,
      checkOutLatitude: null,
      checkOutLongitude: null,
      checkInDistanceMeters: distanceMeters,
      checkOutDistanceMeters: null,
      totalWorkMinutes: 0,
      status: 'open',
      source: 'qr',
      excludeFromWorkTime: false,
      deviceInfo,
      ipAddress,
      createdAt: now,
      updatedAt: now
    };
    records.push(record);
    action = 'check_in';
  }
  await writeJsonArrayFile(attendanceRecordsPath, records);
  await saveAttendanceEvent({ user, store, type: action, success: true, reason: '', latitude, longitude, distanceMeters, deviceInfo, ipAddress });

  return {
    ok: true,
    action,
    message: action === 'check_in' ? 'Вы успешно отметили приход.' : 'Вы успешно отметили уход.',
    status: action === 'check_in' ? 'working' : 'not_working',
    record: enrichAttendanceRecord(record, stores),
    store: sanitizeAttendanceStore(store),
    distanceMeters
  };
}

async function adminOpenAttendanceShift(input, actor) {
  const stores = await getAttendanceStores();
  const users = await getAttendanceReportUsers();
  const userId = String(input.userId || input.user_id || '').trim();
  const storeId = String(input.storeId || input.store_id || '').trim();
  const targetUser = users.find((user) => String(user.id) === userId);
  const store = stores.find((item) => item.id === storeId) || stores[0];
  if (!targetUser) throw httpError(400, 'Выберите сотрудника.');
  if (!store) throw httpError(400, 'Выберите рабочую точку.');
  const records = await readJsonArrayFile(attendanceRecordsPath);
  const openRecord = records.find((record) => record.userId === targetUser.id && record.status === 'open');
  if (openRecord) return enrichAttendanceRecord(openRecord, stores);
  const now = new Date().toISOString();
  const record = {
    id: randomUUID(),
    userId: targetUser.id,
    userName: targetUser.name || '',
    storeId: store.id,
    storeName: store.name,
    checkInTime: now,
    checkOutTime: '',
    checkInLatitude: null,
    checkInLongitude: null,
    checkOutLatitude: null,
    checkOutLongitude: null,
    checkInDistanceMeters: null,
    checkOutDistanceMeters: null,
    totalWorkMinutes: 0,
    status: 'open',
    source: 'admin',
    excludeFromWorkTime: true,
    openedByUserId: actor?.id || '',
    openedByUserName: actor?.name || actor?.login || '',
    deviceInfo: 'admin-open',
    ipAddress: '',
    createdAt: now,
    updatedAt: now
  };
  records.push(record);
  await writeJsonArrayFile(attendanceRecordsPath, records);
  return enrichAttendanceRecord(record, stores);
}

async function autoCloseAttendanceShifts() {
  const [records, stores] = await Promise.all([
    readJsonArrayFile(attendanceRecordsPath),
    getAttendanceStores()
  ]);
  let changed = false;
  const now = new Date();
  for (const record of records) {
    if (record.status !== 'open') continue;
    const store = stores.find((item) => item.id === record.storeId);
    const closeTime = getAttendanceAutoCloseTime(record.checkInTime, store);
    if (!closeTime || now.getTime() < closeTime.getTime()) continue;
    record.checkOutTime = closeTime.toISOString();
    record.checkOutLatitude = null;
    record.checkOutLongitude = null;
    record.checkOutDistanceMeters = null;
    record.totalWorkMinutes = record.excludeFromWorkTime ? 0 : calculateWorkMinutes(record.checkInTime, record.checkOutTime);
    record.status = 'closed';
    record.autoClosed = true;
    record.updatedAt = new Date().toISOString();
    changed = true;
  }
  if (changed) await writeJsonArrayFile(attendanceRecordsPath, records);
}

function getAttendanceAutoCloseTime(checkInTime, store) {
  const start = new Date(checkInTime);
  if (!Number.isFinite(start.getTime())) return null;
  const branch = store?.branch || '';
  const [hours, minutes] = branch === 'besh' ? [19, 30] : [18, 30];
  const date = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Bishkek',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(start);
  return new Date(`${date}T${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:00+06:00`);
}

async function getAttendanceReport(input, user) {
  const [records, events, stores, users] = await Promise.all([
    readJsonArrayFile(attendanceRecordsPath),
    readJsonArrayFile(attendanceEventsPath),
    getAttendanceStores(),
    getAttendanceReportUsers()
  ]);
  const dateFrom = normalizeAttendanceDate(input.dateFrom, 'from');
  const dateTo = normalizeAttendanceDate(input.dateTo, 'to');
  const allowedBranches = normalizeCrmBranches(user.branches);
  const canSeeAll = ['admin', 'owner'].includes(user.role);

  const canSeeRecord = (entry) => {
    const store = stores.find((item) => item.id === entry.storeId);
    if (!canSeeAll && store?.branch && allowedBranches.length && !allowedBranches.includes(store.branch)) return false;
    return canSeeAll || user.role === 'manager' || entry.userId === user.id;
  };

  const visibleRecords = records
    .filter((record) => {
      const time = new Date(record.checkInTime || record.createdAt).getTime();
      if (dateFrom && time < dateFrom) return false;
      if (dateTo && time > dateTo) return false;
      if (input.userId && record.userId !== input.userId) return false;
      if (input.storeId && record.storeId !== input.storeId) return false;
      return canSeeRecord(record);
    })
    .sort((left, right) => new Date(right.checkInTime) - new Date(left.checkInTime))
    .map((record) => enrichAttendanceRecord(record, stores));

  const visibleEvents = events
    .filter((event) => {
      const time = new Date(event.createdAt).getTime();
      if (dateFrom && time < dateFrom) return false;
      if (dateTo && time > dateTo) return false;
      if (input.userId && event.userId !== input.userId) return false;
      if (input.storeId && event.storeId !== input.storeId) return false;
      return canSeeRecord(event);
    })
    .sort((left, right) => new Date(right.createdAt) - new Date(left.createdAt))
    .slice(0, 300);

  const totalWorkMinutes = visibleRecords.reduce((sum, record) => sum + Number(record.totalWorkMinutes || 0), 0);
  const schedule = await getAttendanceSchedule();
  const lateMinutes = visibleRecords.reduce((sum, record) => sum + calculateLateMinutes(record.checkInTime, schedule.workStartsAt), 0);
  return {
    rows: visibleRecords,
    events: visibleEvents,
    stores: stores.map(sanitizeAttendanceStore),
    users: users.filter((entry) => canSeeAll || user.role === 'manager' || entry.id === user.id),
    totals: {
      records: visibleRecords.length,
      open: visibleRecords.filter((record) => record.status === 'open').length,
      failedAttempts: visibleEvents.filter((event) => !event.success).length,
      totalWorkMinutes,
      lateMinutes
    },
    schedule
  };
}

async function getAttendanceReportUsers() {
  try {
    const rows = await getManagedCrmUsers();
    return rows.map((user) => ({ id: user.id, name: user.name, role: user.role, branches: user.branches }));
  } catch {
    return getLegacyCrmUsers().map((user) => ({ id: `legacy:${user.login}`, name: user.name, role: user.role, branches: ['ayu', 'besh'] }));
  }
}

async function saveAttendanceEvent({ user, store = null, type, success, reason, latitude, longitude, distanceMeters = null, deviceInfo, ipAddress }) {
  const events = await readJsonArrayFile(attendanceEventsPath);
  const event = {
    id: randomUUID(),
    userId: user?.id || '',
    userName: user?.name || user?.login || '',
    storeId: store?.id || '',
    storeName: store?.name || '',
    type,
    latitude: Number.isFinite(Number(latitude)) ? Number(latitude) : null,
    longitude: Number.isFinite(Number(longitude)) ? Number(longitude) : null,
    distanceMeters: Number.isFinite(Number(distanceMeters)) ? Number(distanceMeters) : null,
    success: Boolean(success),
    reason: reason || '',
    deviceInfo: String(deviceInfo || '').slice(0, 500),
    ipAddress: String(ipAddress || '').slice(0, 120),
    createdAt: new Date().toISOString()
  };
  events.push(event);
  await writeJsonArrayFile(attendanceEventsPath, events.slice(-5000));
  return event;
}

function enrichAttendanceRecord(record, stores = []) {
  const store = stores.find((entry) => entry.id === record.storeId);
  return {
    ...record,
    storeName: record.storeName || store?.name || '',
    store: store ? sanitizeAttendanceStore(store) : null,
    currentWorkMinutes: record.excludeFromWorkTime ? 0 : record.status === 'open' ? calculateWorkMinutes(record.checkInTime, new Date().toISOString()) : Number(record.totalWorkMinutes || 0)
  };
}

function sanitizeAttendanceStore(store) {
  return {
    id: store.id,
    name: store.name,
    branch: store.branch,
    address: store.address,
    latitude: store.latitude,
    longitude: store.longitude,
    allowedRadiusMeters: store.allowedRadiusMeters,
    qrToken: store.qrToken,
    qrDisabled: Boolean(store.qrDisabled),
    qrTokenExpiresAt: store.qrTokenExpiresAt,
    qrUrl: store.qrToken ? `/attendance.html?token=${encodeURIComponent(store.qrToken)}` : ''
  };
}

function calculateLateMinutes(checkInTime, workStartsAt) {
  const checkedIn = new Date(checkInTime);
  if (!Number.isFinite(checkedIn.getTime())) return 0;
  const [hours, minutes] = String(workStartsAt || '09:00').split(':').map(Number);
  const planned = new Date(checkedIn);
  planned.setHours(Number.isFinite(hours) ? hours : 9, Number.isFinite(minutes) ? minutes : 0, 0, 0);
  return Math.max(0, Math.round((checkedIn.getTime() - planned.getTime()) / 60_000));
}

function calculateWorkMinutes(checkInTime, checkOutTime) {
  const start = new Date(checkInTime).getTime();
  const end = new Date(checkOutTime).getTime();
  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) return 0;
  return Math.round((end - start) / 60_000);
}

function haversineDistanceMeters(lat1, lon1, lat2, lon2) {
  const earthRadius = 6371000;
  const toRadians = (value) => Number(value) * Math.PI / 180;
  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2
    + Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) * Math.sin(dLon / 2) ** 2;
  return earthRadius * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function createAttendanceToken() {
  return randomBytes(24).toString('base64url');
}

function normalizeAttendanceDate(value, side) {
  const raw = String(value || '').trim();
  if (!raw) return 0;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) throw httpError(400, 'Дата должна быть в формате YYYY-MM-DD.');
  const time = side === 'to' ? '23:59:59.999' : '00:00:00.000';
  return new Date(`${raw}T${time}+06:00`).getTime();
}

function normalizeAttendanceBranchKey(value) {
  const normalized = String(value || '').trim().toLocaleLowerCase('ru');
  if (normalized === 'ayu' || normalized.includes('аю')) return 'ayu';
  if (normalized === 'besh' || normalized.includes('беш')) return 'besh';
  return normalized.slice(0, 40);
}

function getRequestIp(req) {
  return String(req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '').split(',')[0].trim();
}

async function readJsonArrayFile(filePath) {
  try {
    const content = await readFile(filePath, 'utf8');
    const rows = JSON.parse(content);
    return Array.isArray(rows) ? rows : [];
  } catch (error) {
    if (error.code === 'ENOENT') return [];
    throw error;
  }
}

async function writeJsonArrayFile(filePath, rows) {
  await mkdir(dataDir, { recursive: true });
  await writeFile(filePath, JSON.stringify(rows, null, 2), 'utf8');
}

function validateTelegramReceiptInput(receiptPhoto) {
  if (!process.env.TELEGRAM_BOT_TOKEN || !process.env.TELEGRAM_RECEIPT_CHAT_ID) {
    throw httpError(500, 'Заполните TELEGRAM_BOT_TOKEN и TELEGRAM_RECEIPT_CHAT_ID в .env.');
  }
  const data = String(receiptPhoto?.data || '');
  const mimeType = String(receiptPhoto?.mimeType || '');
  if (!data || !/^image\/(jpeg|png|webp)$/i.test(mimeType)) {
    throw httpError(400, 'Добавьте корректную фотографию чека.');
  }
  if (data.length > 7 * 1024 * 1024) throw httpError(413, 'Обработанное фото чека слишком большое.');
}

async function sendTelegramReceiptSafely(receiptPhoto, calculation, input, document) {
  try {
    const token = process.env.TELEGRAM_BOT_TOKEN;
    const buffer = Buffer.from(String(receiptPhoto.data), 'base64');
    const caption = buildTelegramReceiptCaption(calculation, input, document);
    let chatId = telegramReceiptChatId || process.env.TELEGRAM_RECEIPT_CHAT_ID;
    let { response, data } = await sendTelegramPhoto(token, chatId, buffer, receiptPhoto, caption);

    const migratedChatId = data?.parameters?.migrate_to_chat_id;
    if ((!response.ok || !data?.ok) && migratedChatId) {
      chatId = String(migratedChatId);
      telegramReceiptChatId = chatId;
      ({ response, data } = await sendTelegramPhoto(token, chatId, buffer, receiptPhoto, caption));
    }

    if (!response.ok || !data?.ok) throw new Error(data?.description || `Telegram вернул ${response.status}`);
    return { sent: true, messageId: data.result?.message_id || null };
  } catch (error) {
    return { sent: false, error: error.message || 'Не удалось отправить фото в Telegram.' };
  }
}

async function triggerRetailFiscalizationSafely(document, input = {}) {
  try {
    return await triggerRetailFiscalization(document, input);
  } catch (error) {
    return {
      attempted: true,
      success: false,
      error: error.message || 'Не удалось отправить документ на фискализацию.'
    };
  }
}

async function triggerRetailFiscalization(document, input = {}) {
  const mode = String(process.env.MOYSKLAD_FISCALIZE_MODE || '').trim().toLowerCase();
  if (mode === 'web-rpc') {
    return triggerRetailFiscalizationViaWebRpc(document, input);
  }

  const endpointTemplate = String(process.env.MOYSKLAD_FISCALIZE_ENDPOINT_TEMPLATE || '').trim();
  if (!endpointTemplate) {
    return {
      attempted: false,
      skipped: true,
      reason: 'Не настроен MOYSKLAD_FISCALIZE_ENDPOINT_TEMPLATE'
    };
  }

  const token = requiredEnv('MOYSKLAD_TOKEN');
  const documentId = String(document?.id || '').trim();
  if (!documentId) {
    return {
      attempted: false,
      skipped: true,
      reason: 'Нет document.id для фискализации'
    };
  }

  const method = String(process.env.MOYSKLAD_FISCALIZE_METHOD || 'POST').trim().toUpperCase();
  const endpoint = endpointTemplate
    .replaceAll('{documentId}', encodeURIComponent(documentId))
    .replaceAll('{retailStoreHref}', encodeURIComponent(String(input.retailStoreHref || '')))
    .replaceAll('{storeHref}', encodeURIComponent(String(input.storeHref || '')))
    .replaceAll('{retailShiftHref}', encodeURIComponent(String(input.retailShiftHref || '')));

  const bodyTemplate = String(process.env.MOYSKLAD_FISCALIZE_BODY || '').trim();
  const body = bodyTemplate
    ? bodyTemplate
      .replaceAll('{documentId}', documentId)
      .replaceAll('{retailStoreHref}', String(input.retailStoreHref || ''))
      .replaceAll('{storeHref}', String(input.storeHref || ''))
      .replaceAll('{retailShiftHref}', String(input.retailShiftHref || ''))
    : '';

  const response = await moySkladFetch(endpoint, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8',
      ...(body ? { 'Content-Type': 'application/json;charset=utf-8' } : {})
    },
    ...(body ? { body } : {})
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw httpError(response.status, 'МойСклад не принял запрос на автофискализацию.', data);
  }

  return {
    attempted: true,
    success: true,
    endpoint,
    method,
    response: data
  };
}

async function triggerRetailFiscalizationViaWebRpc(document, input = {}) {
  const documentId = String(document?.id || '').trim();
  if (!documentId) {
    return {
      attempted: false,
      skipped: true,
      reason: 'Нет document.id для фискализации'
    };
  }

  const serviceUrl = String(process.env.MOYSKLAD_WEB_FISCAL_SERVICE_URL || 'https://online.moysklad.ru/app/services/r1687/FiscalQueueService').trim();
  const moduleBase = String(process.env.MOYSKLAD_WEB_FISCAL_GWT_BASE || 'https://cdn-static.moysklad.ru/app/cdn/r1687/').trim();
  const strongName = String(process.env.MOYSKLAD_WEB_FISCAL_GWT_STRONG_NAME || '').trim();
  const branchKey = getMoySkladBranchKey(input) || getMoySkladBranchKey(document);
  const cookie = branchKey
    ? String(process.env[`MOYSKLAD_${branchKey.toUpperCase()}_WEB_COOKIE`] || '').trim() || String(process.env.MOYSKLAD_WEB_COOKIE || '').trim()
    : String(process.env.MOYSKLAD_WEB_COOKIE || '').trim();
  if (!strongName || !cookie) {
    return {
      attempted: false,
      skipped: true,
      reason: 'Заполните MOYSKLAD_WEB_COOKIE и MOYSKLAD_WEB_FISCAL_GWT_STRONG_NAME'
    };
  }

  const rpcBody = [
    '7', '0', '6',
    moduleBase,
    strongName,
    'com.lognex.sklad.face.common.client.module.fiscal.FiscalQueueService',
    'add',
    'java.util.UUID/2940008275',
    documentId,
    '1', '2', '3', '4', '1', '5', '5', '6'
  ].join('|') + '|';

  const response = await fetch(serviceUrl, {
    method: 'POST',
    headers: {
      Accept: '*/*',
      'Content-Type': 'text/x-gwt-rpc; charset=UTF-8',
      'X-GWT-Module-Base': moduleBase,
      'X-GWT-Permutation': strongName,
      Origin: 'https://online.moysklad.ru',
      Referer: `https://online.moysklad.ru/app/#retaildemand/edit?id=${encodeURIComponent(documentId)}`,
      Cookie: cookie
    },
    body: rpcBody
  });

  const text = await response.text().catch(() => '');
  if (!response.ok) {
    throw httpError(response.status, 'Web-RPC МойСклад не принял запрос на фискализацию.', {
      responseText: text.slice(0, 2000),
      serviceUrl
    });
  }
  if (!String(text).startsWith('//OK')) {
    throw httpError(502, 'МойСклад вернул ошибку web-RPC при фискализации.', {
      responseText: text.slice(0, 2000),
      serviceUrl
    });
  }

  return {
    attempted: true,
    success: true,
    mode: 'web-rpc',
    branchKey,
    serviceUrl,
    responseText: text.slice(0, 2000)
  };
}

async function getRetailDemandById(documentId, input = {}) {
  const token = getMoySkladTokenFor(input);
  const response = await moySkladFetch(`${MOYSKLAD_BASE_URL}/entity/retaildemand/${encodeURIComponent(documentId)}?expand=retailStore,retailShift,store,agent`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json;charset=utf-8'
    }
  });
  const data = await response.json().catch(() => null);
  if (!response.ok || !data) {
    throw httpError(response.status || 502, 'Не удалось загрузить розничную продажу для фискализации.', data);
  }
  return {
    type: 'retaildemand',
    id: data.id || documentId,
    name: data.name || '',
    sum: fromMoySkladPrice(data.sum),
    cashSum: fromMoySkladPrice(data.cashSum),
    noCashSum: fromMoySkladPrice(data.noCashSum),
    retailStoreHref: data.retailStore?.meta?.href || '',
    retailShiftHref: data.retailShift?.meta?.href || '',
    storeHref: data.store?.meta?.href || '',
    retailStoreName: data.retailStore?.name || '',
    retailShiftName: data.retailShift?.name || '',
    storeName: data.store?.name || '',
    customerName: data.agent?.name || '',
    moment: data.moment || '',
    webUrl: getMoySkladWebUrl('retaildemand', data.id || documentId),
    branchName: input.branchName || ''
  };
}

async function sendTelegramPhoto(token, chatId, buffer, receiptPhoto, caption) {
  const form = new FormData();
  form.set('chat_id', chatId);
  form.set('photo', new Blob([buffer], { type: receiptPhoto.mimeType }), receiptPhoto.name || 'receipt.jpg');
  form.set('caption', caption);
  const response = await fetch(`https://api.telegram.org/bot${token}/sendPhoto`, { method: 'POST', body: form });
  const data = await response.json().catch(() => null);
  return { response, data };
}

function buildTelegramReceiptCaption(calculation, input, document) {
  const products = (calculation.items || []).map((item) => `• ${item.productName || item.name || 'Товар'} × ${item.quantity || 1}${item.isGift ? ' — ПОДАРОК' : ''}`).join('\n');
  return [
    `Чек: ${document.type === 'retaildemand' ? 'Продажа' : 'Отгрузка'} №${document.name || ''}`,
    `Сумма: ${formatMoney(calculation.finalTotal || calculation.baseTotal || 0)} сом`,
    `Филиал: ${input.branchName || input.retailStoreName || '-'}`,
    `Сотрудник: ${input.employeeName || '-'}`,
    `Клиент: ${input.customerName || 'Розничный покупатель'}`,
    `Телефон: ${input.customerPhone || '-'}`,
    `Оплата: ${calculation.paymentLabel || input.paymentTypeName || '-'}`,
    '',
    products
  ].join('\n').slice(0, 1024);
}

const MOYSKLAD_RATE_LIMIT_PER_MINUTE = 120;
const MOYSKLAD_RATE_WINDOW_MS = 60 * 1000;
const MOYSKLAD_MIN_REQUEST_GAP_MS = 500;
let moySkladRequestTimeline = [];
let moySkladNextAllowedAt = 0;
let moySkladRateQueue = Promise.resolve();
let moySkladWaitingRequests = 0;
let moySkladActiveRequests = 0;

async function acquireMoySkladRequestSlot() {
  moySkladWaitingRequests += 1;
  const previous = moySkladRateQueue;
  let releaseQueue;
  moySkladRateQueue = new Promise((resolve) => {
    releaseQueue = resolve;
  });

  await previous;
  try {
    while (true) {
      const now = Date.now();
      moySkladRequestTimeline = moySkladRequestTimeline.filter((timestamp) => now - timestamp < MOYSKLAD_RATE_WINDOW_MS);

      const waitForGap = Math.max(0, moySkladNextAllowedAt - now);
      const waitForWindow = moySkladRequestTimeline.length >= MOYSKLAD_RATE_LIMIT_PER_MINUTE
        ? Math.max(0, moySkladRequestTimeline[0] + MOYSKLAD_RATE_WINDOW_MS - now)
        : 0;
      const waitTime = Math.max(waitForGap, waitForWindow);

      if (waitTime <= 0) {
        const startedAt = Date.now();
        moySkladRequestTimeline.push(startedAt);
        moySkladNextAllowedAt = startedAt + MOYSKLAD_MIN_REQUEST_GAP_MS;
        moySkladWaitingRequests = Math.max(0, moySkladWaitingRequests - 1);
        return;
      }

      await sleep(waitTime);
    }
  } finally {
    releaseQueue();
  }
}

function getMoySkladMonitorStats() {
  const now = Date.now();
  moySkladRequestTimeline = moySkladRequestTimeline.filter((timestamp) => now - timestamp < MOYSKLAD_RATE_WINDOW_MS);
  return {
    limitPerMinute: MOYSKLAD_RATE_LIMIT_PER_MINUTE,
    requestsLastMinute: moySkladRequestTimeline.length,
    waiting: moySkladWaitingRequests,
    active: moySkladActiveRequests,
    nextDelayMs: Math.max(0, moySkladNextAllowedAt - now)
  };
}

async function moySkladFetch(url, options = {}) {
  const method = String(options.method || 'GET').toUpperCase();
  const retryable = method === 'GET' || method === 'HEAD';
  for (let attempt = 0; attempt < 3; attempt += 1) {
    await acquireMoySkladRequestSlot();
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), MOYSKLAD_TIMEOUT_MS);
    moySkladActiveRequests += 1;
    try {
      const response = await fetch(url, { ...options, signal: controller.signal });
      if (response.status !== 429 || !retryable || attempt === 2) return response;

      await response.arrayBuffer().catch(() => null);
      const retryAfter = Number(response.headers.get('retry-after'));
      const delay = Number.isFinite(retryAfter) && retryAfter > 0
        ? Math.min(5000, retryAfter * 1000)
        : 500 * (attempt + 1);
      await sleep(delay);
    } catch (error) {
      if (error.name === 'AbortError') {
        throw httpError(504, 'МойСклад слишком долго отвечает. Попробуйте еще раз.');
      }
      if (!retryable || attempt === 2) {
        throw httpError(502, 'Не удалось подключиться к МойСклад. Проверьте интернет или попробуйте еще раз.', {
          cause: error.message || String(error)
        });
      }
      await sleep(300 * (attempt + 1));
    } finally {
      moySkladActiveRequests = Math.max(0, moySkladActiveRequests - 1);
      clearTimeout(timeout);
    }
  }
  throw httpError(502, 'Не удалось подключиться к МойСклад.');
}

function sleep(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

async function supabaseGet(apiPath, params = {}) {
  const url = new URL(`${getSupabaseUrl()}${apiPath}`);
  Object.entries(params).forEach(([key, value]) => url.searchParams.set(key, value));
  return supabaseFetch(url, { method: 'GET' });
}

const expenseCategories = new Set(['fixed', 'variable', 'one_time', 'operational', 'marketing', 'taxes', 'financial']);

async function getExpenses(input = {}) {
  const params = {
    select: 'id,expense_date,category,subcategory,amount,branch_name,payment_method,description,created_by,created_at,updated_at',
    order: 'expense_date.desc,created_at.desc',
    limit: '1000'
  };

  // PostgREST requires repeated filters for a date range, so build this URL explicitly.
  const url = new URL(`${getSupabaseUrl()}/rest/v1/business_expenses`);
  url.searchParams.set('select', params.select);
  url.searchParams.set('order', params.order);
  url.searchParams.set('limit', params.limit);
  if (isIsoDate(input.dateFrom)) url.searchParams.append('expense_date', `gte.${input.dateFrom}`);
  if (isIsoDate(input.dateTo)) url.searchParams.append('expense_date', `lte.${input.dateTo}`);
  if (expenseCategories.has(input.category)) url.searchParams.set('category', `eq.${input.category}`);
  return supabaseFetch(url, { method: 'GET' });
}

async function createExpense(input, user) {
  const payload = normalizeExpenseInput(input, user);
  const rows = await supabaseFetch(`${getSupabaseUrl()}/rest/v1/business_expenses?select=*`, {
    method: 'POST',
    headers: { Prefer: 'return=representation' },
    body: JSON.stringify(payload)
  });
  return rows[0];
}

async function updateExpense(id, input, user) {
  const payload = normalizeExpenseInput(input, user, true);
  const rows = await supabaseFetch(`${getSupabaseUrl()}/rest/v1/business_expenses?id=eq.${encodeURIComponent(id)}&select=*`, {
    method: 'PATCH',
    headers: { Prefer: 'return=representation' },
    body: JSON.stringify(payload)
  });
  if (!rows[0]) throw httpError(404, 'Расход не найден.');
  return rows[0];
}

async function deleteExpense(id) {
  await supabaseFetch(`${getSupabaseUrl()}/rest/v1/business_expenses?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: { Prefer: 'return=minimal' }
  });
}

function normalizeExpenseInput(input, user, updating = false) {
  const expenseDate = String(input.expenseDate || '').trim();
  const category = String(input.category || '').trim();
  const subcategory = String(input.subcategory || '').trim();
  const amount = roundMoney(toMoney(input.amount));
  if (!isIsoDate(expenseDate)) throw httpError(400, 'Укажите дату расхода.');
  if (!expenseCategories.has(category)) throw httpError(400, 'Выберите вид расхода.');
  if (!subcategory) throw httpError(400, 'Укажите статью расхода.');
  if (!Number.isFinite(amount) || amount <= 0) throw httpError(400, 'Сумма расхода должна быть больше нуля.');
  return {
    expense_date: expenseDate,
    category,
    subcategory: subcategory.slice(0, 120),
    amount,
    branch_name: String(input.branchName || '').trim().slice(0, 120),
    payment_method: String(input.paymentMethod || '').trim().slice(0, 80),
    description: String(input.description || '').trim().slice(0, 1000),
    ...(updating ? {} : { created_by: String(user?.name || user?.login || '').slice(0, 120) })
  };
}

const deliveryStatuses = new Set(['new', 'assigned', 'in_transit', 'delivered', 'cancelled']);

async function getDeliveries(input, user) {
  const url = new URL(`${getSupabaseUrl()}/rest/v1/business_deliveries`);
  url.searchParams.set('select', '*');
  url.searchParams.set('order', 'scheduled_at.asc,created_at.desc');
  url.searchParams.set('limit', '1000');
  if (isIsoDate(input.dateFrom)) url.searchParams.append('scheduled_at', `gte.${input.dateFrom}T00:00:00+06:00`);
  if (isIsoDate(input.dateTo)) url.searchParams.append('scheduled_at', `lte.${input.dateTo}T23:59:59+06:00`);
  if (deliveryStatuses.has(input.status)) url.searchParams.set('status', `eq.${input.status}`);
  const rows = await supabaseFetch(url, { method: 'GET' });
  const allowedNames = normalizeCrmBranches(user?.branches).map((branch) => branch === 'ayu' ? 'Аю-Гранд' : 'Беш-Сары');
  return rows.filter((row) => allowedNames.includes(row.branch_name));
}

async function createDeliveryRecord(input, document, user) {
  const delivery = input.delivery || {};
  const scheduledAt = new Date(delivery.scheduledAt || '');
  const items = Array.isArray(delivery.items) ? delivery.items.filter((item) => item?.name && Number(item.quantity) > 0) : [];
  if (!items.length) throw httpError(400, 'Выберите хотя бы один товар для доставки.');
  if (!Number.isFinite(scheduledAt.getTime())) throw httpError(400, 'Укажите дату и время доставки.');
  if (!String(delivery.address || '').trim()) throw httpError(400, 'Укажите адрес доставки.');
  if (!String(input.customerPhone || '').trim()) throw httpError(400, 'Для доставки укажите телефон клиента.');
  assertCrmBranchAccess(user, input.branchName);
  const payload = {
    document_id: String(document.id || ''),
    document_type: String(document.type || ''),
    document_name: String(document.name || ''),
    document_url: String(document.webUrl || getMoySkladWebUrl(document.type, document.id) || ''),
    branch_name: String(input.branchName || '').trim(),
    customer_name: String(input.customerName || 'Розничный покупатель').trim(),
    customer_phone: String(input.customerPhone || '').trim(),
    delivery_address: String(delivery.address || '').trim(),
    scheduled_at: scheduledAt.toISOString(),
    employee_name: String(input.employeeName || user?.name || '').trim(),
    items: items.map((item) => ({ name: String(item.name).slice(0, 300), quantity: Number(item.quantity), code: String(item.code || '').slice(0, 80) })),
    status: 'new',
    notes: String(delivery.notes || '').trim().slice(0, 1000),
    created_by: String(user?.name || user?.login || '').slice(0, 120)
  };
  const rows = await supabaseFetch(`${getSupabaseUrl()}/rest/v1/business_deliveries?select=*`, {
    method: 'POST',
    headers: { Prefer: 'return=representation' },
    body: JSON.stringify(payload)
  });
  return rows[0];
}

async function updateDelivery(id, input, user) {
  const status = String(input.status || '');
  if (!deliveryStatuses.has(status)) throw httpError(400, 'Некорректный статус доставки.');
  const existing = await supabaseGet('/rest/v1/business_deliveries', { id: `eq.${id}`, select: '*', limit: '1' });
  if (!existing[0]) throw httpError(404, 'Доставка не найдена.');
  assertCrmBranchAccess(user, existing[0].branch_name);
  const rows = await supabaseFetch(`${getSupabaseUrl()}/rest/v1/business_deliveries?id=eq.${encodeURIComponent(id)}&select=*`, {
    method: 'PATCH',
    headers: { Prefer: 'return=representation' },
    body: JSON.stringify({ status })
  });
  return rows[0];
}

function isIsoDate(value) {
  return /^\d{4}-\d{2}-\d{2}$/.test(String(value || ''));
}

async function supabaseRpc(name, body) {
  return supabaseFetch(`${getSupabaseUrl()}/rest/v1/rpc/${name}`, {
    method: 'POST',
    body: JSON.stringify(body)
  });
}

async function supabaseFetch(url, options = {}) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
  if (!getSupabaseUrl() || !key) {
    throw httpError(500, 'Не заполнены SUPABASE_URL и SUPABASE_SERVICE_ROLE_KEY.');
  }

  const response = await fetch(url, {
    ...options,
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
      ...(options.headers || {})
    }
  });

  const text = await response.text();
  const data = text ? JSON.parse(text) : null;
  if (!response.ok) {
    throw httpError(response.status, data?.message || data?.hint || 'Supabase вернул ошибку.', data);
  }
  return data || [];
}

function getSupabaseUrl() {
  return String(process.env.SUPABASE_URL || '').replace(/\/$/, '');
}

function meta(href, type) {
  return {
    meta: {
      href,
      type,
      mediaType: 'application/json'
    }
  };
}

function toMoney(value) {
  if (typeof value === 'string') {
    return Number(value.replace(/\s/g, '').replace(',', '.'));
  }
  return Number(value);
}

function normalizePhone(value) {
  return String(value || '').replace(/\D/g, '');
}

function roundMoney(value) {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

function toMoySkladPrice(value) {
  return Math.round(value * 100);
}

function formatMoney(value) {
  return new Intl.NumberFormat('ru-RU', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(value);
}

function formatNumber(value) {
  return new Intl.NumberFormat('ru-RU', {
    maximumFractionDigits: 0
  }).format(Number(value || 0));
}

function formatPercent(value) {
  return `${new Intl.NumberFormat('ru-RU', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(Number(value || 0))}%`;
}

function getCounterpartyDescriptionField(description, label) {
  const text = String(description || '');
  const match = text.match(new RegExp(`${label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*:\\s*(.+)`, 'i'));
  return match ? String(match[1] || '').trim() : '';
}

function getInvoiceSellerLine() {
  return process.env.WORD_INVOICE_SELLER_LINE
    || 'ИП Матаев Женишбек Камилович, ИНН 20305197500183, г.Бишкек, Ленинский район, 69 га ж/м, ул.20-я, дом №14, р/с 1280156055213894, Банк: ЗАО «Кыргызский Инвестиционно-Кредитный Банк», БИК 128015';
}

function getInvoiceDirectorName() {
  return process.env.WORD_INVOICE_DIRECTOR_NAME || 'Матаев Ж.К';
}

function escapeWordHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function numberToRussianSom(value) {
  const amount = Math.round(Number(value || 0) * 100);
  const soms = Math.floor(amount / 100);
  const tyiyn = amount % 100;
  const words = integerToRussianWords(soms);
  const result = `${words} ${pluralRu(soms, ['сом', 'сома', 'сомов'])} ${String(tyiyn).padStart(2, '0')} ${pluralRu(tyiyn, ['тыйын', 'тыйына', 'тыйынов'])}`;
  return result.charAt(0).toUpperCase() + result.slice(1);
}

function integerToRussianWords(number) {
  if (!number) return 'ноль';

  const units = [
    ['', 'один', 'два', 'три', 'четыре', 'пять', 'шесть', 'семь', 'восемь', 'девять'],
    ['', 'одна', 'две', 'три', 'четыре', 'пять', 'шесть', 'семь', 'восемь', 'девять']
  ];
  const teens = ['десять', 'одиннадцать', 'двенадцать', 'тринадцать', 'четырнадцать', 'пятнадцать', 'шестнадцать', 'семнадцать', 'восемнадцать', 'девятнадцать'];
  const tens = ['', '', 'двадцать', 'тридцать', 'сорок', 'пятьдесят', 'шестьдесят', 'семьдесят', 'восемьдесят', 'девяносто'];
  const hundreds = ['', 'сто', 'двести', 'триста', 'четыреста', 'пятьсот', 'шестьсот', 'семьсот', 'восемьсот', 'девятьсот'];
  const scales = [
    ['', '', '', 0],
    ['тысяча', 'тысячи', 'тысяч', 1],
    ['миллион', 'миллиона', 'миллионов', 0]
  ];

  const parts = [];
  let rest = Math.floor(number);
  let scaleIndex = 0;

  while (rest > 0) {
    const chunk = rest % 1000;
    if (chunk) {
      const gender = scales[scaleIndex]?.[3] || 0;
      const chunkWords = [];
      chunkWords.push(hundreds[Math.floor(chunk / 100)]);
      const lastTwo = chunk % 100;
      if (lastTwo >= 10 && lastTwo < 20) {
        chunkWords.push(teens[lastTwo - 10]);
      } else {
        chunkWords.push(tens[Math.floor(lastTwo / 10)]);
        chunkWords.push(units[gender][lastTwo % 10]);
      }
      const scale = scales[scaleIndex];
      if (scaleIndex > 0) {
        chunkWords.push(pluralRu(chunk, scale.slice(0, 3)));
      }
      parts.unshift(chunkWords.filter(Boolean).join(' '));
    }
    rest = Math.floor(rest / 1000);
    scaleIndex += 1;
  }

  return parts.join(' ').replace(/\s+/g, ' ').trim();
}

function pluralRu(number, forms) {
  const abs = Math.abs(Number(number || 0)) % 100;
  const last = abs % 10;
  if (abs > 10 && abs < 20) return forms[2];
  if (last > 1 && last < 5) return forms[1];
  if (last === 1) return forms[0];
  return forms[2];
}

function requiredEnv(name) {
  const value = typeof process.env[name] === 'string' ? process.env[name].trim() : process.env[name];
  if (!value || value.includes('00000000-0000-0000-0000-000000000000')) {
    throw httpError(500, `Заполните ${name} в .env.`);
  }
  return value;
}

function requiredReportEnv(name) {
  const value = process.env[name];
  if (!value) {
    throw httpError(500, `Заполните ${name} в .env для доступа к отчетам.`);
  }
  return value;
}

async function loginReportUser(req, res, body) {
  const login = String(body.login || '').trim();
  const password = String(body.password || '');
  const crmUser = await authenticateCrmUser(login, password);
  const legacyMatch = safeEqual(login, requiredReportEnv('REPORT_LOGIN'))
    && safeEqual(password, requiredReportEnv('REPORT_PASSWORD'));
  const user = crmUser || (legacyMatch ? { login, name: 'Владелец', role: 'owner' } : null);

  if (!user || !['admin', 'owner', 'accountant'].includes(user.role)) {
    throw httpError(401, 'Неверный логин или пароль.');
  }

  setReportSession(res, login);
  setCrmSession(res, user, { append: true });
  sendJson(res, 200, { ok: true, user });
}

function requireReportAuth(req) {
  const user = getCrmUser(req);
  if (user && hasCrmPermission(user, 'reports')) return user;
  if (user) throw httpError(403, 'Отчетность недоступна для вашей роли.');
  if (!isReportAuthenticated(req)) {
    throw httpError(401, 'Войдите в отчетность.');
  }
  return { login: 'legacy-report', name: 'Владелец', role: 'owner' };
}

function canViewReportProfit(user) {
  return ['admin', 'owner', 'accountant'].includes(user?.role)
    || (user?.role === 'manager' && hasCrmPermission(user, 'reportProfit'));
}

function sanitizeSalesReportForUser(report, user) {
  const canViewProfit = canViewReportProfit(user);
  if (canViewProfit) {
    return { ...report, canViewProfit: true };
  }

  const totals = { ...(report?.totals || {}) };
  delete totals.netProfit;
  const rows = (Array.isArray(report?.rows) ? report.rows : []).map((row) => {
    const sanitized = { ...row };
    delete sanitized.netProfit;
    return sanitized;
  });

  return { ...report, totals, rows, canViewProfit: false };
}

function buildBankCommissionExcelBuffer(analytics) {
  return Buffer.from(`\ufeff${buildBankCommissionExportHtml(analytics)}`, 'utf8');
}

function buildBankCommissionExportHtml(analytics) {
  const rows = Array.isArray(analytics?.rows) ? analytics.rows : [];
  const totals = analytics?.totals || {};
  const period = `${escapeWordHtml(formatDateOnlyRu(analytics?.filters?.dateFrom || ''))} - ${escapeWordHtml(formatDateOnlyRu(analytics?.filters?.dateTo || ''))}`;
  return `<!doctype html>
  <html lang="ru">
    <head>
      <meta charset="utf-8">
      <title>Банковские комиссии</title>
      <style>
        body { font-family: Inter, Arial, sans-serif; color: #172033; padding: 24px; }
        h1, h2, p { margin: 0; }
        .meta { margin: 8px 0 20px; color: #526075; }
        .cards { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 20px; }
        .card { border: 1px solid #d8dee8; border-radius: 10px; padding: 14px; }
        .card span { display: block; color: #667085; font-size: 12px; margin-bottom: 6px; }
        .card strong { font-size: 24px; }
        table { width: 100%; border-collapse: collapse; margin-top: 16px; }
        th, td { border: 1px solid #d8dee8; padding: 8px 10px; text-align: left; font-size: 12px; }
        th { background: #edf2f7; }
        .num { text-align: right; white-space: nowrap; }
      </style>
    </head>
    <body>
      <h1>Банковские комиссии</h1>
      <p class="meta">Период: ${period}</p>
      <section class="cards">
        <div class="card"><span>Общая комиссия</span><strong>${escapeWordHtml(formatMoney(totals.commission || 0))} сом</strong></div>
        <div class="card"><span>Оборот через банки</span><strong>${escapeWordHtml(formatMoney(totals.turnover || 0))} сом</strong></div>
        <div class="card"><span>Чистая сумма</span><strong>${escapeWordHtml(formatMoney(totals.netAmount || 0))} сом</strong></div>
      </section>
      <h2>Сводка по банкам</h2>
      <table>
        <thead>
          <tr>
            <th>Банк / тип оплаты</th>
            <th>Сумма продаж</th>
            <th>Комиссия</th>
            <th>Чистая сумма</th>
            <th>Кол-во платежей</th>
            <th>Средний %</th>
            <th>Доля от общей комиссии</th>
          </tr>
        </thead>
        <tbody>
          ${rows.length ? rows.map((row) => `
            <tr>
              <td>${escapeWordHtml(row.paymentType)}</td>
              <td class="num">${escapeWordHtml(formatMoney(row.turnover))}</td>
              <td class="num">${escapeWordHtml(formatMoney(row.commission))}</td>
              <td class="num">${escapeWordHtml(formatMoney(row.netAmount))}</td>
              <td class="num">${escapeWordHtml(formatNumber(row.paymentCount))}</td>
              <td class="num">${escapeWordHtml(formatPercent(row.averageRate))}</td>
              <td class="num">${escapeWordHtml(formatPercent(row.shareOfTotalCommission))}</td>
            </tr>
          `).join('') : '<tr><td colspan="7">Нет данных за выбранный период.</td></tr>'}
        </tbody>
      </table>
    </body>
  </html>`;
}

function formatDateOnlyRu(value) {
  if (!value) return '';
  const date = new Date(`${value}T00:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(date);
}

function requireAccountingAuth(req) {
  const user = getCrmUser(req);
  if (user && (hasCrmPermission(user, 'priceFormula') || hasCrmPermission(user, 'customsCalculator'))) return user;
  if (user) throw httpError(403, 'Бухгалтерия недоступна для вашей роли.');
  if (isReportAuthenticated(req)) return { login: 'legacy-report', name: 'Бухгалтер', role: 'accountant' };
  throw httpError(401, 'Войдите в бухгалтерию.');
}

function isReportAuthenticated(req) {
  const token = parseCookies(req.headers.cookie || '')[reportCookieName];
  if (!token) {
    return false;
  }

  const [payloadPart, signature] = token.split('.');
  if (!payloadPart || !signature) {
    return false;
  }

  const expectedSignature = signReportPayload(payloadPart);
  if (!safeEqual(signature, expectedSignature)) {
    return false;
  }

  try {
    const payload = JSON.parse(Buffer.from(payloadPart, 'base64url').toString('utf8'));
    return payload.exp > Date.now();
  } catch {
    return false;
  }
}

function setReportSession(res, login) {
  const payload = Buffer.from(JSON.stringify({
    login,
    exp: Date.now() + 12 * 60 * 60 * 1000
  })).toString('base64url');
  const token = `${payload}.${signReportPayload(payload)}`;
  res.setHeader('Set-Cookie', `${reportCookieName}=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=43200`);
}

const crmPermissionNames = ['sales', 'debtSale', 'deliveries', 'attendance', 'reports', 'reportProfit', 'expenses', 'payroll', 'commercialDocuments', 'reconciliation', 'whatsappBroadcast', 'priceFormula', 'customsCalculator', 'bankCommissions', 'audit', 'users', 'about'];
const crmRolePermissions = {
  admin: [...crmPermissionNames],
  owner: [...crmPermissionNames],
  manager: ['sales', 'debtSale', 'deliveries', 'attendance', 'reports', 'reportProfit', 'expenses', 'payroll', 'commercialDocuments', 'reconciliation', 'whatsappBroadcast', 'customsCalculator', 'bankCommissions', 'about'],
  seller: ['sales', 'debtSale', 'deliveries', 'attendance', 'reports', 'commercialDocuments', 'about'],
  logistics: ['sales', 'debtSale', 'deliveries', 'attendance', 'commercialDocuments', 'about'],
  accountant: ['attendance', 'reports', 'expenses', 'payroll', 'reconciliation', 'priceFormula', 'customsCalculator', 'bankCommissions', 'about'],
  employee: ['attendance', 'about']
};

function getLegacyCrmUsers() {
  return [
    { role: 'admin', login: process.env.CRM_ADMIN_LOGIN || 'admin', password: process.env.CRM_ADMIN_PASSWORD || 'admin2026', name: process.env.CRM_ADMIN_NAME || 'Администратор' },
    { role: 'owner', login: process.env.CRM_OWNER_LOGIN || process.env.REPORT_LOGIN || 'owner', password: process.env.CRM_OWNER_PASSWORD || process.env.REPORT_PASSWORD || 'owner2026', name: process.env.CRM_OWNER_NAME || 'Владелец' },
    { role: 'accountant', login: process.env.CRM_ACCOUNTANT_LOGIN || 'accountant', password: process.env.CRM_ACCOUNTANT_PASSWORD || 'accountant2026', name: process.env.CRM_ACCOUNTANT_NAME || 'Бухгалтер' },
    { role: 'employee', login: process.env.CRM_EMPLOYEE_LOGIN || 'employee', password: process.env.CRM_EMPLOYEE_PASSWORD || 'employee2026', name: process.env.CRM_EMPLOYEE_NAME || 'Сотрудник' }
  ];
}

async function getCrmLoginUsers() {
  try {
    const rows = await supabaseGet('/rest/v1/crm_users', {
      select: 'id,login,name,position,role,branches,password_hash',
      active: 'eq.true',
      order: 'name.asc'
    });
    const users = rows.map((row) => ({
      id: row.id,
      name: row.name,
      position: row.position || getCrmRoleLabel(row.role),
      role: row.role,
      branches: normalizeCrmBranches(row.branches),
      passwordSet: Boolean(row.password_hash)
    }));
    if (!users.some((user) => user.passwordSet && (user.role === 'admin' || user.role === 'owner'))) {
      const setupAdmin = getLegacyCrmUsers().find((user) => user.role === 'admin');
      users.unshift({ id: `legacy:${setupAdmin.login}`, name: setupAdmin.name, position: 'Первичная настройка доступа', branches: ['ayu', 'besh'], passwordSet: true });
    }
    return users;
  } catch (error) {
    return getLegacyCrmUsers().map((user) => ({ id: `legacy:${user.login}`, name: user.name, position: getCrmRoleLabel(user.role), branches: ['ayu', 'besh'], passwordSet: true }));
  }
}

async function getManagedCrmUsers() {
  await syncMoySkladEmployeesToCrmUsers().catch(() => {});
  let rows;
  try {
    rows = await supabaseGet('/rest/v1/crm_users', {
      select: 'id,login,name,position,salary,role,branches,permissions,active,password_hash,created_at,updated_at',
      active: 'eq.true',
      order: 'name.asc'
    });
  } catch {
    rows = await supabaseGet('/rest/v1/crm_users', {
      select: 'id,login,name,position,role,branches,permissions,active,password_hash,created_at,updated_at',
      active: 'eq.true',
      order: 'name.asc'
    });
  }
  return rows.map(sanitizeManagedCrmUser);
}

async function syncMoySkladEmployeesToCrmUsers() {
  const employees = await getMoySkladEmployees().catch(() => []);
  if (!employees.length) return;

  let currentRows = [];
  try {
    currentRows = await supabaseGet('/rest/v1/crm_users', {
      select: 'id,login,name,branches',
      order: 'name.asc'
    });
  } catch {
    return;
  }

  const existingKeys = new Set();
  const existingLogins = new Set();
  const existingByNameKey = new Map();
  for (const row of currentRows) {
    existingLogins.add(String(row.login || '').trim().toLowerCase());
    for (const key of getEmployeeLookupKeys(row.name)) {
      if (!existingByNameKey.has(key)) {
        existingByNameKey.set(key, row);
      }
    }
    for (const branch of normalizeCrmBranches(row.branches)) {
      for (const key of getEmployeeLookupKeys(row.name)) {
        existingKeys.add(`${branch}|${key}`);
      }
    }
  }

  const payload = [];
  const updates = [];
  for (const employee of employees) {
    const branchKey = employee.branchKey || 'ayu';
    const keys = getEmployeeLookupKeys(employee.name);
    const exists = keys.some((key) => existingKeys.has(`${branchKey}|${key}`));
    if (exists) continue;

    const existingRow = keys.map((key) => existingByNameKey.get(key)).find(Boolean);
    if (existingRow) {
      const mergedBranches = [...new Set([...normalizeCrmBranches(existingRow.branches), branchKey])];
      updates.push({ id: existingRow.id, branches: mergedBranches });
      keys.forEach((key) => existingKeys.add(`${branchKey}|${key}`));
      continue;
    }

    let loginBase = `emp-${branchKey}-${String(employee.id || randomUUID()).slice(0, 8)}`.toLowerCase();
    let login = loginBase;
    let seq = 1;
    while (existingLogins.has(login)) {
      seq += 1;
      login = `${loginBase}-${seq}`;
    }
    existingLogins.add(login);
    keys.forEach((key) => existingKeys.add(`${branchKey}|${key}`));

    payload.push({
      login,
      name: String(employee.name || '').trim().slice(0, 120) || 'Сотрудник',
      position: 'Сотрудник МойСклад',
      salary: 0,
      role: 'seller',
      branches: [branchKey],
      permissions: normalizeCrmPermissions('seller', []),
      active: true
    });
  }

  for (const update of updates) {
    await supabaseFetch(`${getSupabaseUrl()}/rest/v1/crm_users?id=eq.${encodeURIComponent(update.id)}`, {
      method: 'PATCH',
      headers: { Prefer: 'return=minimal' },
      body: JSON.stringify({ branches: update.branches })
    });
  }

  if (!payload.length) return;
  await supabaseFetch(`${getSupabaseUrl()}/rest/v1/crm_users`, {
    method: 'POST',
    headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
    body: JSON.stringify(payload)
  });
}

async function getCrmPayrollUsers() {
  let rows;
  try {
    rows = await supabaseGet('/rest/v1/crm_users', {
      select: 'id,login,name,position,salary,role,active',
      active: 'eq.true',
      order: 'name.asc'
    });
  } catch {
    try {
      rows = await supabaseGet('/rest/v1/crm_users', {
        select: 'id,login,name,position,role,active',
        active: 'eq.true',
        order: 'name.asc'
      });
    } catch {
      return [];
    }
  }

  return rows.map((row) => ({
    id: row.id,
    login: row.login || '',
    name: row.name || '',
    position: row.position || getCrmRoleLabel(row.role),
    salary: clampPayrollNumber(row.salary, 0, 10000000)
  }));
}

async function authenticateCrmUser(login, password) {
  const normalizedLogin = String(login || '').trim();
  const normalizedPassword = String(password || '');
  if (/^[0-9a-f-]{36}$/i.test(normalizedLogin)) {
    try {
      const rows = await supabaseGet('/rest/v1/crm_users', {
        id: `eq.${normalizedLogin}`,
        active: 'eq.true',
        select: 'id,login,name,position,role,branches,permissions,password_hash',
        limit: '1'
      });
      const found = rows[0];
      if (!found?.password_hash || !verifyCrmPassword(normalizedPassword, found.password_hash)) return null;
      return toSessionCrmUser(found);
    } catch {
      return null;
    }
  }

  const legacyLogin = normalizedLogin.replace(/^legacy:/, '');
  const found = getLegacyCrmUsers().find((user) => safeEqual(legacyLogin, user.login) && safeEqual(normalizedPassword, user.password));
  return found ? toSessionCrmUser({ ...found, id: `legacy:${found.login}`, branches: ['ayu', 'besh'] }) : null;
}

async function updateManagedCrmUser(id, input, actor) {
  const currentRows = await supabaseGet('/rest/v1/crm_users', {
    id: `eq.${id}`,
    select: 'id,name,role,permissions',
    limit: '1'
  });
  const current = currentRows[0];
  if (!current) throw httpError(404, 'Сотрудник не найден.');
  if (actor?.role !== 'admin' && current.role === 'admin') {
    throw httpError(403, 'Только главный администратор может изменять главного администратора.');
  }
  if (actor?.role !== 'admin' && input.role === 'admin') {
    throw httpError(403, 'Только главный администратор может назначать эту роль.');
  }
  const role = ['admin', 'owner', 'manager', 'seller', 'logistics', 'accountant', 'employee'].includes(input.role) ? input.role : 'seller';
  let permissions = role === 'admin' || role === 'owner'
    ? [...crmPermissionNames]
    : [...new Set((Array.isArray(input.permissions) ? input.permissions : crmRolePermissions[role] || []).filter((value) => crmPermissionNames.includes(value)))];
  if (actor?.role !== 'admin' && role !== 'admin' && role !== 'owner') {
    const currentCanViewProfit = normalizeCrmPermissions(current.role, current.permissions).includes('reportProfit');
    permissions = permissions.filter((permission) => permission !== 'reportProfit');
    if (currentCanViewProfit) permissions.push('reportProfit');
  }
  if (!['admin', 'owner', 'manager', 'accountant'].includes(role)) {
    permissions = permissions.filter((permission) => permission !== 'reportProfit');
  }
  const branches = normalizeCrmBranches(input.branches);
  if (!branches.length) throw httpError(400, 'Выберите хотя бы один филиал.');
  const payload = {
    name: String(input.name || '').trim().slice(0, 120),
    login: String(input.login || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '').slice(0, 60),
    position: String(input.position || '').trim().slice(0, 120),
    salary: clampPayrollNumber(input.salary, 0, 10000000),
    role,
    branches,
    permissions,
    active: input.active !== false
  };
  if (!payload.name || !payload.login) throw httpError(400, 'Заполните имя и логин сотрудника.');
  const password = String(input.password || '');
  if (password) {
    if (password.length < 6) throw httpError(400, 'Пароль должен содержать минимум 6 символов.');
    payload.password_hash = hashCrmPassword(password);
  }
  const rows = await supabaseFetch(`${getSupabaseUrl()}/rest/v1/crm_users?id=eq.${encodeURIComponent(id)}&select=*`, {
    method: 'PATCH',
    headers: { Prefer: 'return=representation' },
    body: JSON.stringify(payload)
  });
  if (!rows[0]) throw httpError(404, 'Сотрудник не найден.');
  payrollReportCache.clear();
  return sanitizeManagedCrmUser(rows[0]);
}

async function deleteManagedCrmUser(id, actor) {
  const currentRows = await supabaseGet('/rest/v1/crm_users', {
    id: `eq.${id}`,
    select: 'id,name,role,active',
    limit: '1'
  });
  const current = currentRows[0];
  if (!current) throw httpError(404, 'Сотрудник не найден.');
  if (String(actor?.id || '') === String(current.id || '')) {
    throw httpError(400, 'Нельзя удалить свою учетную запись.');
  }
  if (['admin', 'owner'].includes(current.role)) {
    throw httpError(403, 'Администраторов и владельцев можно только отключить вручную через активность.');
  }
  if (actor?.role !== 'admin' && current.role === 'manager') {
    throw httpError(403, 'Менеджера может удалить только главный администратор.');
  }

  const moySkladRemoval = await removeMoySkladEmployeeForCrmUser(current);

  const rows = await supabaseFetch(`${getSupabaseUrl()}/rest/v1/crm_users?id=eq.${encodeURIComponent(id)}&select=*`, {
    method: 'PATCH',
    headers: { Prefer: 'return=representation' },
    body: JSON.stringify({ active: false })
  });
  if (!rows[0]) throw httpError(404, 'Сотрудник не найден.');
  payrollReportCache.clear();
  return { ...sanitizeManagedCrmUser(rows[0]), moySkladRemoval };
}

async function removeMoySkladEmployeeForCrmUser(user) {
  const nameKey = normalizeEmployeeKey(user?.name);
  if (!nameKey) return { status: 'skipped', reason: 'empty_name' };

  const employees = await getMoySkladEmployees();
  const matches = employees.filter((employee) => normalizeEmployeeKey(employee.name) === nameKey);
  if (!matches.length) {
    return { status: 'not_found', reason: 'moysklad_employee_not_found' };
  }
  if (matches.length > 1) {
    throw httpError(409, `В МойСклад найдено несколько сотрудников с именем «${user.name}». Удалите вручную или переименуйте дубли.`);
  }

  const employee = matches[0];
  const token = getMoySkladTokenFor({ branchKey: employee.branchKey || '' });
  const headers = {
    Authorization: `Bearer ${token}`,
    Accept: 'application/json;charset=utf-8'
  };

  const deleteResponse = await moySkladFetch(employee.href, { method: 'DELETE', headers });
  if (deleteResponse.ok) {
    return { status: 'deleted', name: employee.name, href: employee.href };
  }

  const deleteData = await deleteResponse.json().catch(() => null);
  const currentResponse = await moySkladFetch(employee.href, { headers });
  const currentData = await currentResponse.json().catch(() => null);
  const archiveResponse = await moySkladFetch(employee.href, {
    method: 'PUT',
    headers: {
      ...headers,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      archived: true,
      description: appendDeletionMarker(currentData?.description || '', user.name)
    })
  });
  if (archiveResponse.ok) {
    return { status: 'archived', name: employee.name, href: employee.href, deleteError: extractMoySkladError(deleteData) };
  }

  const archiveData = await archiveResponse.json().catch(() => null);
  throw httpError(
    deleteResponse.status,
    `МойСклад не дал удалить сотрудника «${employee.name}»: ${extractMoySkladError(deleteData) || 'есть связанные объекты'}. Архивация тоже не прошла: ${extractMoySkladError(archiveData) || archiveResponse.status}.`,
    { deleteData, archiveData }
  );
}

function appendDeletionMarker(description, name) {
  const marker = `[ORDO_DELETED_EMPLOYEE ${new Date().toISOString()}] ${name || ''}`.trim();
  return [String(description || '').trim(), marker].filter(Boolean).join('\n');
}

function extractMoySkladError(data) {
  if (!data) return '';
  if (typeof data === 'string') return data;
  if (Array.isArray(data.errors) && data.errors.length) {
    return data.errors.map((error) => error.error || error.message || '').filter(Boolean).join('; ');
  }
  return data.error || data.message || '';
}

const defaultCrmUiSettings = Object.freeze({
  theme: 'blue',
  mode: 'light',
  density: 'comfortable',
  accentColor: '#2563eb'
});

async function getCrmUiSettings(user) {
  if (!user?.id || String(user.id).startsWith('legacy:')) {
    return { ...defaultCrmUiSettings };
  }
  try {
    const rows = await supabaseGet('/rest/v1/crm_users', {
      id: `eq.${user.id}`,
      select: 'ui_settings',
      limit: '1'
    });
    return normalizeCrmUiSettings(rows[0]?.ui_settings);
  } catch {
    return { ...defaultCrmUiSettings };
  }
}

async function updateCrmUiSettings(user, input) {
  const settings = normalizeCrmUiSettings(input);
  if (!user?.id || String(user.id).startsWith('legacy:')) {
    return settings;
  }
  try {
    const rows = await supabaseFetch(`${getSupabaseUrl()}/rest/v1/crm_users?id=eq.${encodeURIComponent(user.id)}&select=ui_settings`, {
      method: 'PATCH',
      headers: { Prefer: 'return=representation' },
      body: JSON.stringify({ ui_settings: settings })
    });
    return normalizeCrmUiSettings(rows[0]?.ui_settings);
  } catch {
    return settings;
  }
}

async function getCustomsCalculatorHistory(user) {
  if (!user?.id || String(user.id).startsWith('legacy:')) return [];
  try {
    const canSeeAll = user.role === 'owner' || user.role === 'admin';
    const rows = await supabaseGet('/rest/v1/customs_calculator_history', {
      select: 'id,title,payload,created_at,updated_at,user_id',
      ...(canSeeAll ? {} : { user_id: `eq.${user.id}` }),
      order: 'updated_at.desc,created_at.desc',
      limit: '30'
    });
    return await decorateCustomsHistoryRows(rows);
  } catch {
    return [];
  }
}

async function getCustomsCalculatorHistoryItem(id, user) {
  if (!user?.id || String(user.id).startsWith('legacy:')) throw httpError(403, 'Для этого пользователя история недоступна.');
  const canSeeAll = user.role === 'owner' || user.role === 'admin';
  const rows = await supabaseGet('/rest/v1/customs_calculator_history', {
    select: 'id,title,payload,created_at,updated_at,user_id',
    id: `eq.${id}`,
    ...(canSeeAll ? {} : { user_id: `eq.${user.id}` }),
    limit: '1'
  });
  if (!rows[0]) throw httpError(404, 'Запись истории не найдена.');
  return (await decorateCustomsHistoryRows(rows))[0];
}

async function saveCustomsCalculatorHistory(user, input) {
  if (!user?.id || String(user.id).startsWith('legacy:')) throw httpError(403, 'Для этого пользователя история недоступна.');
  const payload = normalizeCustomsCalculatorHistoryInput(input, user);
  const rows = await supabaseFetch(`${getSupabaseUrl()}/rest/v1/customs_calculator_history?select=id,title,payload,created_at,updated_at,user_id`, {
    method: 'POST',
    headers: { Prefer: 'return=representation' },
    body: JSON.stringify(payload)
  });
  return (await decorateCustomsHistoryRows(rows))[0];
}

async function deleteCustomsCalculatorHistory(user) {
  if (!user?.id || String(user.id).startsWith('legacy:')) throw httpError(403, 'Для этого пользователя история недоступна.');
  const canDeleteAll = user.role === 'owner' || user.role === 'admin';
  const params = canDeleteAll
    ? 'id=not.is.null'
    : `user_id=eq.${encodeURIComponent(user.id)}`;
  const rows = await supabaseFetch(`${getSupabaseUrl()}/rest/v1/customs_calculator_history?${params}&select=id`, {
    method: 'DELETE',
    headers: { Prefer: 'return=representation' }
  });
  return Array.isArray(rows) ? rows.length : 0;
}

async function deleteCustomsCalculatorHistoryItem(id, user) {
  if (!user?.id || String(user.id).startsWith('legacy:')) throw httpError(403, 'Для этого пользователя история недоступна.');
  const canDeleteAll = user.role === 'owner' || user.role === 'admin';
  const params = [
    `id=eq.${encodeURIComponent(id)}`,
    canDeleteAll ? '' : `user_id=eq.${encodeURIComponent(user.id)}`,
    'select=id'
  ].filter(Boolean).join('&');
  const rows = await supabaseFetch(`${getSupabaseUrl()}/rest/v1/customs_calculator_history?${params}`, {
    method: 'DELETE',
    headers: { Prefer: 'return=representation' }
  });
  if (!Array.isArray(rows) || !rows.length) throw httpError(404, 'Запись истории не найдена.');
  return rows.length;
}

function normalizeCustomsCalculatorHistoryInput(input, user) {
  const title = String(input?.title || '').trim().slice(0, 160) || `Расчет ${new Intl.DateTimeFormat('ru-RU', { dateStyle: 'short', timeStyle: 'short', timeZone: 'Asia/Bishkek' }).format(new Date())}`;
  const draft = input?.draft && typeof input.draft === 'object' ? input.draft : null;
  if (!draft) throw httpError(400, 'Нет данных для сохранения.');
  const rows = Array.isArray(draft.rows) ? draft.rows.slice(0, 500) : [];
  const rowSeq = Number(draft.rowSeq || 1);
  const partyExpenses = draft.partyExpenses && typeof draft.partyExpenses === 'object' ? draft.partyExpenses : {};
  return {
    user_id: user.id,
    title,
    payload: {
      rows,
      rowSeq,
      partyExpenses
    }
  };
}

async function decorateCustomsHistoryRows(rows) {
  const historyRows = Array.isArray(rows) ? rows : [];
  const userIds = [...new Set(historyRows.map((row) => String(row.user_id || '')).filter(Boolean))];
  if (!userIds.length) {
    return historyRows.map((row) => ({ ...row, owner_name: '' }));
  }
  try {
    const users = await supabaseGet('/rest/v1/crm_users', {
      select: 'id,name,login',
      id: `in.(${userIds.map((id) => `"${id}"`).join(',')})`
    });
    const byId = new Map((users || []).map((row) => [row.id, row.name || row.login || '']));
    return historyRows.map((row) => ({
      ...row,
      owner_name: byId.get(row.user_id) || ''
    }));
  } catch {
    return historyRows.map((row) => ({ ...row, owner_name: '' }));
  }
}

function normalizeCrmUiSettings(input) {
  const raw = input && typeof input === 'object' ? input : {};
  return {
    theme: ['blue', 'green', 'violet', 'red'].includes(raw.theme) ? raw.theme : defaultCrmUiSettings.theme,
    mode: raw.mode === 'dark' ? 'dark' : 'light',
    density: raw.density === 'compact' ? 'compact' : 'comfortable',
    accentColor: normalizeHexColor(raw.accentColor, defaultCrmUiSettings.accentColor)
  };
}

function normalizeHexColor(value, fallback = '#2563eb') {
  const normalized = String(value || '').trim().match(/^#?([0-9a-f]{6})$/i)?.[1];
  return normalized ? `#${normalized.toLowerCase()}` : fallback;
}

function sanitizeManagedCrmUser(row) {
  return {
    id: row.id,
    login: row.login,
    name: row.name,
    position: row.position || '',
    salary: clampPayrollNumber(row.salary, 0, 10000000),
    role: row.role,
    branches: normalizeCrmBranches(row.branches),
    permissions: normalizeCrmPermissions(row.role, row.permissions),
    active: row.active !== false,
    passwordSet: Boolean(row.password_hash),
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

function toSessionCrmUser(row) {
  return {
    id: row.id || '',
    login: row.login,
    name: row.name,
    position: row.position || getCrmRoleLabel(row.role),
    role: row.role,
    branches: normalizeCrmBranches(row.branches).length ? normalizeCrmBranches(row.branches) : ['ayu', 'besh'],
    permissions: normalizeCrmPermissions(row.role, row.permissions)
  };
}

function normalizeCrmBranches(branches) {
  return [...new Set((Array.isArray(branches) ? branches : []).filter((value) => value === 'ayu' || value === 'besh'))];
}

function normalizeBranchKey(branchName) {
  const normalized = String(branchName || '').trim().toLocaleLowerCase('ru');
  if (normalized.includes('аю')) return 'ayu';
  if (normalized.includes('беш')) return 'besh';
  return '';
}

function getMoySkladBranchKey(input = {}) {
  const direct = normalizeBranchKey(input.branchName || input.branch || '');
  if (direct) return direct;
  const retailStoreHref = String(input.retailStoreHref || '').trim();
  const storeHref = String(input.storeHref || '').trim();
  for (const branchKey of ['ayu', 'besh']) {
    const retailEnv = process.env[`MOYSKLAD_${branchKey.toUpperCase()}_RETAIL_STORE_HREF`] || '';
    const storeEnv = process.env[`MOYSKLAD_${branchKey.toUpperCase()}_STORE_HREF`] || '';
    if (retailStoreHref && retailEnv && retailStoreHref === retailEnv) return branchKey;
    if (storeHref && storeEnv && storeHref === storeEnv) return branchKey;
  }
  return '';
}

function getMoySkladEnvValue(key, input = {}, fallback = '') {
  const branchKey = getMoySkladBranchKey(input);
  if (branchKey) {
    const scoped = String(process.env[`MOYSKLAD_${branchKey.toUpperCase()}_${key}`] || '').trim();
    if (scoped) return scoped;
  }
  return String(process.env[`MOYSKLAD_${key}`] || fallback).trim();
}

function getMoySkladTokenFor(input = {}) {
  const token = getMoySkladEnvValue('TOKEN', input);
  if (!token) throw httpError(500, `Не найден токен МойСклад для филиала ${moySkladBranchLabels[getMoySkladBranchKey(input)] || 'по умолчанию'}.`);
  return token;
}

function getMoySkladBranchConfigs() {
  const configs = [];
  for (const branchKey of ['ayu', 'besh']) {
    const token = String(process.env[`MOYSKLAD_${branchKey.toUpperCase()}_TOKEN`] || '').trim();
    if (!token) continue;
    configs.push({
      branchKey,
      token,
      organizationHref: String(process.env[`MOYSKLAD_${branchKey.toUpperCase()}_ORGANIZATION_HREF`] || '').trim(),
      agentHref: String(process.env[`MOYSKLAD_${branchKey.toUpperCase()}_AGENT_HREF`] || '').trim(),
      storeHref: String(process.env[`MOYSKLAD_${branchKey.toUpperCase()}_STORE_HREF`] || '').trim(),
      retailStoreHref: String(process.env[`MOYSKLAD_${branchKey.toUpperCase()}_RETAIL_STORE_HREF`] || '').trim(),
      webCookie: String(process.env[`MOYSKLAD_${branchKey.toUpperCase()}_WEB_COOKIE`] || '').trim()
    });
  }
  const defaultToken = String(process.env.MOYSKLAD_TOKEN || '').trim();
  if (defaultToken) {
    configs.push({
      branchKey: '',
      token: defaultToken,
      organizationHref: String(process.env.MOYSKLAD_ORGANIZATION_HREF || '').trim(),
      agentHref: String(process.env.MOYSKLAD_AGENT_HREF || '').trim(),
      storeHref: String(process.env.MOYSKLAD_STORE_HREF || '').trim(),
      retailStoreHref: String(process.env.MOYSKLAD_RETAIL_STORE_HREF || '').trim(),
      webCookie: String(process.env.MOYSKLAD_WEB_COOKIE || '').trim()
    });
  }
  return configs;
}

function normalizeCrmPermissions(role, permissions) {
  if (role === 'admin' || role === 'owner') return [...crmPermissionNames];
  const values = [...(Array.isArray(permissions) && permissions.length ? permissions : crmRolePermissions[role] || [])];
  if (role === 'seller' && !values.includes('reports')) values.push('reports');
  if (isAttendanceRequiredForUser({ role }) && !values.includes('attendance')) values.push('attendance');
  return [...new Set(values.filter((value) => crmPermissionNames.includes(value)))];
}

function getCrmRoleLabel(role) {
  return ({ admin: 'Администратор', owner: 'Владелец', manager: 'Менеджер', seller: 'Продавец', logistics: 'Логистика', accountant: 'Бухгалтер', employee: 'Сотрудник' })[role] || role;
}

function hashCrmPassword(password) {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(String(password), salt, 64).toString('hex');
  return `scrypt$${salt}$${hash}`;
}

function verifyCrmPassword(password, stored) {
  const [algorithm, salt, expectedHex] = String(stored || '').split('$');
  if (algorithm !== 'scrypt' || !salt || !expectedHex) return false;
  const actual = scryptSync(String(password), salt, 64);
  const expected = Buffer.from(expectedHex, 'hex');
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

function requireAnyAuthenticatedUser(req) {
  const user = getCrmUser(req);
  if (user || isReportAuthenticated(req)) return user || { login: 'legacy-report', name: 'Владелец', role: 'owner' };
  throw httpError(401, 'Войдите в систему.');
}

function requireBotApiKey(req) {
  const expected = String(process.env.BOT_API_KEY || '').trim();
  if (!expected) throw httpError(500, 'BOT_API_KEY не настроен.');
  const provided = String(req.headers['x-bot-key'] || '').trim();
  if (!provided || provided !== expected) throw httpError(401, 'Invalid bot API key.');
}

function requireCrmRole(req, roles) {
  const user = getCrmUser(req);
  if (!user) throw httpError(401, 'Войдите в систему.');
  if (!roles.includes(user.role)) throw httpError(403, 'У вашей роли нет доступа к этому разделу.');
  return user;
}

function requireCrmPermission(req, permission) {
  const user = getCrmUser(req);
  if (!user) throw httpError(401, 'Войдите в систему.');
  if (!hasCrmPermission(user, permission)) throw httpError(403, 'У вас нет доступа к этому разделу.');
  return user;
}

function requireAnyCrmPermission(req, permissions) {
  const user = getCrmUser(req);
  if (!user) throw httpError(401, 'Войдите в систему.');
  const allowed = Array.isArray(permissions) ? permissions : [permissions];
  if (!allowed.some((permission) => hasCrmPermission(user, permission))) {
    throw httpError(403, 'У вас нет доступа к этому разделу.');
  }
  return user;
}

function hasCrmPermission(user, permission) {
  return normalizeCrmPermissions(user?.role, user?.permissions).includes(permission);
}

function assertCrmBranchAccess(user, branchName) {
  const normalized = String(branchName || '').trim().toLocaleLowerCase('ru');
  const branchKey = normalized.includes('аю') ? 'ayu' : normalized.includes('беш') ? 'besh' : '';
  if (!branchKey) throw httpError(400, 'Не удалось определить филиал документа.');
  if (!normalizeCrmBranches(user?.branches).includes(branchKey)) {
    throw httpError(403, 'У сотрудника нет доступа к выбранному филиалу.');
  }
}

function getEffectiveUser(req, fallbackRole) {
  return getCrmUser(req) || { login: 'legacy-report', name: fallbackRole === 'accountant' ? 'Бухгалтер' : 'Владелец', role: fallbackRole };
}

function getCrmUser(req) {
  const token = parseCookies(req.headers.cookie || '')[crmCookieName];
  if (!token) return null;
  const [payloadPart, signature] = token.split('.');
  if (!payloadPart || !signature || !safeEqual(signature, signCrmPayload(payloadPart))) return null;
  try {
    const payload = JSON.parse(Buffer.from(payloadPart, 'base64url').toString('utf8'));
    if (!payload.exp || payload.exp <= Date.now()) return null;
    return toSessionCrmUser(payload);
  } catch {
    return null;
  }
}

function setCrmSession(res, user, options = {}) {
  const payload = Buffer.from(JSON.stringify({ ...user, exp: Date.now() + 12 * 60 * 60 * 1000 })).toString('base64url');
  const cookie = `${crmCookieName}=${payload}.${signCrmPayload(payload)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=43200`;
  if (options.append) {
    const existing = res.getHeader('Set-Cookie');
    res.setHeader('Set-Cookie', [...(Array.isArray(existing) ? existing : existing ? [existing] : []), cookie]);
  } else {
    res.setHeader('Set-Cookie', cookie);
  }
}

function clearCrmSession(res) {
  res.setHeader('Set-Cookie', [
    `${crmCookieName}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0`,
    `${reportCookieName}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0`
  ]);
}

function signCrmPayload(payload) {
  const secret = process.env.CRM_SESSION_SECRET || process.env.REPORT_SESSION_SECRET || process.env.MOYSKLAD_TOKEN || 'local-crm-secret';
  return createHmac('sha256', secret).update(payload).digest('base64url');
}

async function writeAudit(entry) {
  try {
    await mkdir(dataDir, { recursive: true });
    const row = {
      id: randomUUID(),
      createdAt: new Date().toISOString(),
      userLogin: entry.user?.login || 'system',
      userName: entry.user?.name || 'Система',
      role: entry.user?.role || 'system',
      action: entry.action || 'unknown',
      entity: entry.entity || '',
      entityId: entry.entityId || '',
      description: entry.description || '',
      details: entry.details || {}
    };
    await appendFile(auditLogPath, `${JSON.stringify(row)}\n`, 'utf8');
  } catch (error) {
    console.error('Audit log error:', error.message);
  }
}

async function readAuditLog(limit) {
  try {
    const content = await readFile(auditLogPath, 'utf8');
    return content.split('\n').filter(Boolean).slice(-limit).reverse().map((line) => JSON.parse(line));
  } catch (error) {
    if (error.code === 'ENOENT') return [];
    throw error;
  }
}

function clearReportSession(res) {
  res.setHeader('Set-Cookie', `${reportCookieName}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0`);
}

function signReportPayload(payload) {
  const secret = process.env.REPORT_SESSION_SECRET || process.env.MOYSKLAD_TOKEN || 'local-report-secret';
  return createHmac('sha256', secret).update(payload).digest('base64url');
}

function parseCookies(cookieHeader) {
  return Object.fromEntries(String(cookieHeader || '').split(';').map((cookie) => {
    const index = cookie.indexOf('=');
    if (index === -1) {
      return ['', ''];
    }
    return [cookie.slice(0, index).trim(), cookie.slice(index + 1).trim()];
  }).filter(([key]) => key));
}

function safeEqual(left, right) {
  const leftBuffer = Buffer.from(String(left || ''));
  const rightBuffer = Buffer.from(String(right || ''));
  if (leftBuffer.length !== rightBuffer.length) {
    return false;
  }
  return timingSafeEqual(leftBuffer, rightBuffer);
}

function sendJson(res, status, payload) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(payload));
}

function httpError(status, message, details) {
  const error = new Error(message);
  error.status = status;
  error.details = details;
  return error;
}

function loadDotEnv(envPath = join(__dirname, '.env')) {
  try {
    const content = process.env.NODE_ENV === 'test' ? '' : readFileSync(envPath, 'utf8');
    for (const line of content.split('\n')) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#') || !trimmed.includes('=')) continue;
      const [key, ...valueParts] = trimmed.split('=');
      if (!process.env[key]) {
        process.env[key] = valueParts.join('=').trim();
      }
    }
  } catch {
    // .env is optional; .env.example documents the required keys.
  }
}
